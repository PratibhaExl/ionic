AutoMeetingInviteFromCSV_Scheduled Package

This ZIP contains:
- FLOW_DEFINITION/definition.json     => a skeleton flow definition showing actions and connectors (needs manual creation/import)
- Automation/MeetingData.csv          => sample CSV to upload to OneDrive at /Automation/
- Automation/Templates/*.txt         => email templates to upload to OneDrive at /Automation/Templates/

IMPORTANT:
- The definition.json is a skeleton to guide building the flow in Power Automate. Power Automate does not support direct import of this simple JSON via the web UI.
- To set up the flow in Power Automate, follow the steps below.

Setup Steps:

1. Upload the folder "Automation" to your OneDrive root so the path is:
   /Automation/MeetingData.csv
   /Automation/Templates/ClientEmail.txt
   /Automation/Templates/UserEmail.txt
   /Automation/Templates/Default.txt

2. In Power Automate (https://make.powerautomate.com):
   - Create a new Scheduled cloud flow.
   - Name it: AutoMeetingInviteFromCSV_Scheduled
   - Set the recurrence to every 1 hour, Time zone: Eastern Standard Time.

3. Add action: OneDrive for Business -> Get file content -> File: /Automation/MeetingData.csv
   - Use the file content output as input into a "Compose" or "Parse CSV" action.
   - Because Power Automate doesn't have a native robust CSV parser, you can:
     a) Use "Data Operations - Parse CSV" from Power Automate community connectors, or
     b) Use an expression: split(outputs('Get_file_content'),'
') and then split rows by comma.

4. Add "Apply to each" over rows (skipping header). For each row:
   - Parse CSV row into columns: ClientEmail, UserEmail, TemplateType, Subject, StartTime, Duration
   - Add action: OneDrive for Business -> Get file content -> File: /Automation/Templates/{TemplateType}.txt
   - Add action: Office 365 Outlook -> Create event (V4)
       * Subject: parsed Subject
       * Start: parsed StartTime (set timezone to Eastern Standard Time)
       * End: add Duration minutes to StartTime (use addMinutes expression)
       * Attendees: ClientEmail and UserEmail
       * Body: template content (you can replace placeholders using replace() function)
   - Add action: Office 365 Outlook -> Send an email (V2)
       * To: ClientEmail;UserEmail
       * Subject: Meeting Invitation: parsed Subject
       * Body: template content with placeholders replaced
       * IsHtml: Yes

5. Save flow. On first run, you'll be prompted to sign in and authorize OneDrive and Office 365 Outlook connectors.

6. Testing:
   - Update Automation/MeetingData.csv with a test row (use real emails you can access).
   - Manually trigger the flow once or wait for the scheduled run.

Notes:
- The included definition.json in FLOW_DEFINITION is a guideline -- adjusting expressions, connection names, and actions in Power Automate UI is required.
- If you'd like, I can provide an exported Power Automate package (.zip) created from within your tenant. That requires access to your Power Automate tenant which I don't have.

If you want, I can now:
A) Provide this package as a downloadable ZIP here (you can save it), OR
B) Walk you step-by-step in Power Automate UI to recreate the flow using this package as the source.

Reply 'A' to get the ZIP download link or 'B' to get step-by-step UI instructions now.
