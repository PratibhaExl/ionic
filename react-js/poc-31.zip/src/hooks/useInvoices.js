import { useDatabase } from './useDatabase'

export function useInvoices() {
  return useDatabase('invoices')
}
