import { useDatabase } from './useDatabase'

export function useSales() {
  return useDatabase('sales')
}
