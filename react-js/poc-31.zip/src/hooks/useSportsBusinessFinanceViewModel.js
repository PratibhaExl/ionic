import { useMemo } from 'react'
import { useAppStore } from '../context/AppStore'
import { useOrganization } from '../context/OrganizationContext'
import {
  getDashboardPaymentMetrics,
  getTalentRevenueShareRollup,
} from '../repositories/sportsBusinessRepository'
import { getOrganizationRevenueShareContext } from '../utils/revenueShareEngine'

/**
 * View-model style hook: org-scoped payment + revenue-share metrics, refreshes when `dataRevision` bumps.
 */
export function useSportsBusinessFinanceViewModel() {
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()

  return useMemo(() => {
    const orgId = currentOrganizationId
    if (!orgId) {
      return {
        metrics: null,
        revenueContext: null,
        revenueRollup: null,
        revision: dataRevision,
      }
    }
    return {
      metrics: getDashboardPaymentMetrics(orgId),
      revenueContext: getOrganizationRevenueShareContext(orgId),
      revenueRollup: getTalentRevenueShareRollup(orgId),
      revision: dataRevision,
    }
  }, [currentOrganizationId, dataRevision])
}
