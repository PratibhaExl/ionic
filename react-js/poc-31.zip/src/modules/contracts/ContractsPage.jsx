import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useOrganizationData } from '../../hooks/useOrganizationData'
import { getAllByOrganization } from '../../database/dbService'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { downloadContractPDF } from '../../utils/pdfGenerator'
import { ContractAIValidatorList } from '../../components/ContractAIValidator'
import toast from 'react-hot-toast'
import { ContractViewer } from '../../components/forms/ContractViewer'
import { ContractPDFViewer } from '../../components/forms/ContractPDFViewer'
import { ContractDetailsViewer } from '../../components/forms/ContractDetailsViewer'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { Plus, Pencil, Trash2, FileText, FileSpreadsheet, Filter, UserCircle } from 'lucide-react'
import { Loader } from '../../components/ui/Loader'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

const FILTER_ALL = '__all__'
const CONTRACTS_PATH = '/sponsorship/talents/contracts'

/** Club policy: talent revenue share on net sales (entered as whole % in forms). */
const TALENT_RS_MIN_PCT = 3
const TALENT_RS_MAX_PCT = 6

function linkedBasicContractDisplay(linkedId, allContracts) {
  if (!linkedId) return '—'
  const c = (allContracts || []).find((x) => x.id === linkedId)
  return c?.contractID ? `${c.contractID} (${linkedId})` : linkedId
}

export function ContractsPage() {
  const { currentOrganizationId } = useOrganization()
  const location = useLocation()
  const navigate = useNavigate()
  const { dataRevision, bumpDataRevision } = useAppStore()
  const { loading: pageLoading, loadMessage } = usePageLoadAuto('Loading contracts...', 'Contracts loaded')
  const { data: contracts, loading: contractsLoading, create, update, remove } = useOrganizationData('contracts')
  const { data: revenueShareContracts, loading: rsLoading } = useOrganizationData('revenueShareContracts')

  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const sponsorshipCompanies = useMemo(
    () => getAllByOrganization('sponsorshipCompanies', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )

  const [filterTalentId, setFilterTalentId] = useState(FILTER_ALL)
  const [filterStatus, setFilterStatus] = useState(FILTER_ALL)
  const prevPathnameRef = useRef(null)

  /** Entering Contracts from another route defaults to "All talents" unless talent profile passed focusTalentId. */
  useEffect(() => {
    const pathname = location.pathname
    const prev = prevPathnameRef.current
    prevPathnameRef.current = pathname

    if (pathname !== CONTRACTS_PATH) return

    const tid = location.state?.focusTalentId
    if (typeof tid === 'string' && tid) {
      setFilterTalentId(tid)
      navigate(CONTRACTS_PATH, { replace: true, state: {} })
      return
    }

    const enteredContracts = prev !== CONTRACTS_PATH
    if (enteredContracts) {
      setFilterTalentId(FILTER_ALL)
    }
  }, [location.pathname, location.state, navigate])
  const [editing, setEditing] = useState(null)
  const [open, setOpen] = useState(false)
  const [viewContract, setViewContract] = useState(null)
  const [viewPdfContract, setViewPdfContract] = useState(null)
  const [viewDetailsContract, setViewDetailsContract] = useState(null)
  const [form, setForm] = useState({
    contractID: '',
    talentId: '',
    licenseeId: '',
    sponsorId: '',
    basicSalary2026_27: '',
    basicSalary2027_28: '',
    signingBonus: '',
    royaltyPercent: '',
    startDate: '',
    endDate: '',
    status: 'active',
  })

  const filteredBaseContracts = useMemo(() => {
    let rows = [...(contracts || [])]
    if (filterTalentId !== FILTER_ALL) rows = rows.filter((c) => c.talentId === filterTalentId)
    if (filterStatus !== FILTER_ALL) rows = rows.filter((c) => (c.status || 'active') === filterStatus)
    return rows
  }, [contracts, filterTalentId, filterStatus])

  const filteredRevenueShare = useMemo(() => {
    let rows = [...(revenueShareContracts || [])]
    if (filterTalentId !== FILTER_ALL) rows = rows.filter((r) => r.talentId === filterTalentId)
    if (filterStatus !== FILTER_ALL) rows = rows.filter((r) => (r.status || 'active') === filterStatus)
    return rows
  }, [revenueShareContracts, filterTalentId, filterStatus])

  const isTalentFocused =
    filterTalentId !== FILTER_ALL && talents.some((t) => t.id === filterTalentId)
  const focusedTalent = useMemo(() => talents.find((t) => t.id === filterTalentId), [talents, filterTalentId])

  useEffect(() => {
    if (filterTalentId === FILTER_ALL || talents.length === 0) return
    if (!talents.some((t) => t.id === filterTalentId)) {
      setFilterTalentId(FILTER_ALL)
    }
  }, [filterTalentId, talents])

  const talentsOrderedForGroups = useMemo(() => {
    const sorted = [...talents].sort((a, b) => (a.name || '').localeCompare(b.name || ''))
    if (filterTalentId === FILTER_ALL) return sorted
    return sorted.filter((t) => t.id === filterTalentId)
  }, [talents, filterTalentId])

  const resetForm = () => {
    setForm({
      contractID: '',
      talentId: '',
      licenseeId: '',
      sponsorId: '',
      basicSalary2026_27: '',
      basicSalary2027_28: '',
      signingBonus: '',
      royaltyPercent: '',
      startDate: '',
      endDate: '',
      status: 'active',
    })
    setEditing(null)
    setOpen(false)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const pctWhole = Number(form.royaltyPercent)
    if (Number.isFinite(pctWhole) && (pctWhole < TALENT_RS_MIN_PCT || pctWhole > TALENT_RS_MAX_PCT)) {
      toast.error(`Talent revenue share must be between ${TALENT_RS_MIN_PCT}% and ${TALENT_RS_MAX_PCT}% (club policy).`)
      return
    }
    const talent = talents.find((t) => t.id === form.talentId)
    const licenseeBiz = sportsBusinesses.find((b) => b.id === form.licenseeId)
    const annualSalary = Number(form.basicSalary2026_27) || 0
    const payload = {
      contractID: form.contractID || `CNT-${Date.now()}`,
      talentId: form.talentId,
      talentName: talent?.name || '',
      licenseeId: form.licenseeId,
      licensee: licenseeBiz?.businessName || '',
      sponsorId: form.sponsorId,
      organizationId: currentOrganizationId,
      annualSalary,
      basicSalary2026_27: Number(form.basicSalary2026_27) || 0,
      basicSalary2027_28: Number(form.basicSalary2027_28) || 0,
      signingBonus: Number(form.signingBonus) || 0,
      royaltyPercent: Number(form.royaltyPercent) / 100 || 0,
      startDate: form.startDate,
      endDate: form.endDate,
      status: form.status,
    }
    if (editing) {
      update(editing.id, payload)
      toast.success('Contract updated')
    } else {
      create(payload)
      toast.success('Contract created')
    }
    bumpDataRevision()
    resetForm()
  }

  const handleRemove = (id) => {
    remove(id)
    bumpDataRevision()
    toast.success('Contract removed')
  }

  const openEdit = (row) => {
    setEditing(row)
    setForm({
      contractID: row.contractID || '',
      talentId: row.talentId || '',
      licenseeId: row.licenseeId || '',
      sponsorId: row.sponsorId || '',
      basicSalary2026_27: String(row.basicSalary2026_27 ?? row.annualSalary ?? ''),
      basicSalary2027_28: String(row.basicSalary2027_28 ?? row.annualSalary ?? ''),
      signingBonus: String(row.signingBonus ?? ''),
      royaltyPercent: String((row.royaltyPercent ?? 0) * 100),
      startDate: row.startDate || '',
      endDate: row.endDate || '',
      status: row.status || 'active',
    })
    setOpen(true)
  }

  const contractActions = (row) => (
    <div className="flex flex-wrap gap-1">
      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setViewContract(row)} title="View details">
        <FileText className="h-4 w-4" />
      </Button>
      <Button size="sm" className="h-8 bg-primary px-2 text-xs text-white hover:bg-primary/90" onClick={() => setViewPdfContract(row)} title="View PDF">
        PDF
      </Button>
      <Button variant="outline" size="sm" className="h-8 px-2 text-xs" onClick={() => setViewDetailsContract(row)} title="Details">
        <FileSpreadsheet className="h-3.5 w-3.5" />
      </Button>
      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(row)}>
        <Pencil className="h-4 w-4" />
      </Button>
      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleRemove(row.id)}>
        <Trash2 className="h-4 w-4 text-red-600" />
      </Button>
    </div>
  )

  const columns = [
    { id: 'contractID', header: 'Contract ID', accessorKey: 'contractID' },
    { id: 'talentName', header: 'Talent Name', accessorKey: 'talentName' },
    { id: 'startDate', header: 'Contract Start', accessorKey: 'startDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'endDate', header: 'Contract End', accessorKey: 'endDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'basicSalary2026_27', header: 'Basic Salary 2026-27', accessorKey: 'basicSalary2026_27', cell: (info) => (info.getValue() != null ? formatINRDisplay(info.getValue()) : '—') },
    { id: 'basicSalary2027_28', header: 'Basic Salary 2027-28', accessorKey: 'basicSalary2027_28', cell: (info) => (info.getValue() != null ? formatINRDisplay(info.getValue()) : '—') },
    {
      id: 'royaltyPercent',
      header: 'Revenue share %',
      accessorKey: 'royaltyPercent',
      cell: (info) => (info.getValue() != null ? `${(info.getValue() * 100).toFixed(2)}%` : '—'),
    },
    { id: 'signingBonus', header: 'Performance Bonus', accessorKey: 'signingBonus', cell: (info) => (info.getValue() != null ? formatINRDisplay(info.getValue()) : '—') },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'active' ? 'success' : 'secondary'}>{info.getValue()}</Badge> },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => contractActions(row.original),
    },
  ]

  const compactBasicColumns = [
    { id: 'contractID', header: 'Contract ID', accessorKey: 'contractID' },
    { id: 'licensee', header: 'Club line', accessorKey: 'licensee' },
    {
      id: 'royaltyPercent',
      header: 'Rev. share',
      accessorKey: 'royaltyPercent',
      cell: (info) => (info.getValue() != null ? `${(info.getValue() * 100).toFixed(2)}%` : '—'),
    },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'active' ? 'success' : 'secondary'}>{info.getValue()}</Badge> },
    { id: 'actions', header: 'Actions', cell: ({ row }) => contractActions(row.original) },
  ]

  const withoutTalentNameCols = columns.filter((c) => c.id !== 'talentName')
  const _startIdx = withoutTalentNameCols.findIndex((c) => c.id === 'startDate')
  const productTypeCol = {
    id: 'productType',
    header: 'Product / type',
    accessorKey: 'productType',
    cell: (info) => info.getValue() || '—',
  }
  const focusedBasicColumns =
    _startIdx === -1
      ? [...withoutTalentNameCols, productTypeCol]
      : [...withoutTalentNameCols.slice(0, _startIdx), productTypeCol, ...withoutTalentNameCols.slice(_startIdx)]

  if (pageLoading) return <PageLoaderWithSkeleton message={loadMessage} />
  if (contractsLoading || rsLoading) return <Loader />

  return (
    <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
      <div className="min-w-0 flex-1 space-y-6">
        <ContractAIValidatorList contracts={filteredBaseContracts} />
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0 space-y-1">
            <h2 className="text-xl font-semibold text-primary-800">Talent &amp; sports contracts</h2>
            <p className="text-sm text-neutral">
              Basic agreements link each talent to a club line and sport partner for payroll, <span className="font-medium text-primary-800">talent revenue share</span>{' '}
              (policy band <span className="font-semibold">{TALENT_RS_MIN_PCT}%–{TALENT_RS_MAX_PCT}%</span> of net sales), and vendor sale matching. After the club approves a vendor file,
              dashboards and payment views refresh automatically.
            </p>
            <Link
              to="/sponsorship/talents"
              className="inline-block text-sm font-semibold text-primary underline-offset-4 hover:underline"
            >
              ← Back to Talents roster
            </Link>
          </div>
          <Button
            className="shrink-0 bg-primary text-white hover:bg-primary/90"
            onClick={() => {
              setEditing(null)
              setForm({
                contractID: '',
                talentId: filterTalentId !== FILTER_ALL ? filterTalentId : '',
                licenseeId: '',
                sponsorId: '',
                basicSalary2026_27: '',
                basicSalary2027_28: '',
                signingBonus: '',
                royaltyPercent: '',
                startDate: '',
                endDate: '',
                status: 'active',
              })
              setOpen(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" /> Create Contract
          </Button>
        </div>

        {isTalentFocused && focusedTalent && (
          <div className="space-y-4">
            <div className="flex flex-col gap-2 rounded-xl border border-primary/20 bg-primary/[0.04] p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-white text-primary shadow-sm">
                  <UserCircle className="h-6 w-6" aria-hidden />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-primary-900">{focusedTalent.name}</h3>
                  <p className="mt-1 text-2xs leading-relaxed text-neutral">
                    Two sections mirror the talent profile: <span className="font-medium">Basic contracts</span> and{' '}
                    <span className="font-medium">Talent revenue share (review)</span>. Edits here or on the talent detail page use the same data (
                    <span className="font-medium">Talent &amp; sports contracts</span> bumps refresh both).
                  </p>
                </div>
              </div>
              <Button asChild variant="outline" size="sm" className="shrink-0 border-primary/25">
                <Link to={`/sponsorship/talents/${filterTalentId}`}>Open talent detail</Link>
              </Button>
            </div>

            <div className="grid gap-6 lg:grid-cols-2 lg:items-start">
              <Card className="border-primary/15 shadow-sm">
                <CardHeader className="border-b border-slate-100 bg-slate-50/90 py-3">
                  <CardTitle className="text-sm font-semibold text-primary-900">Basic contracts</CardTitle>
                  <p className="mt-1 text-2xs text-neutral">Salary, club line, product type, revenue share % — same rows as on the talent profile.</p>
                </CardHeader>
                <CardContent className="pt-4">
                  {filteredBaseContracts.length === 0 ? (
                    <p className="text-sm text-neutral">No basic contracts for this talent with the current status filter.</p>
                  ) : (
                    <DataTable
                      columns={focusedBasicColumns}
                      data={filteredBaseContracts}
                      searchKey="contractID"
                      searchPlaceholder="Search contract ID…"
                      pageSize={10}
                    />
                  )}
                </CardContent>
              </Card>

              <Card className="border-accent/25 shadow-sm">
                <CardHeader className="border-b border-accent/15 bg-accent/[0.06] py-3">
                  <CardTitle className="text-sm font-semibold text-primary-900">Talent revenue share (review)</CardTitle>
                  <p className="mt-1 text-2xs text-neutral">Product-level agreements linked to basic contracts — same list as revenue share on the talent profile.</p>
                </CardHeader>
                <CardContent className="pt-4">
                  {filteredRevenueShare.length === 0 ? (
                    <p className="text-sm text-neutral">No revenue share rows for this talent with the current status filter.</p>
                  ) : (
                    <div className="overflow-x-auto rounded-md border border-slate-200">
                      <table className="w-full min-w-[560px] text-left text-sm">
                        <thead className="border-b border-slate-200 bg-slate-50/90 text-2xs font-semibold uppercase tracking-wide text-slate-600">
                          <tr>
                            <th className="px-3 py-2">Title</th>
                            <th className="px-3 py-2">Product</th>
                            <th className="px-3 py-2">Linked basic</th>
                            <th className="px-3 py-2">%</th>
                            <th className="px-3 py-2">Term</th>
                            <th className="px-3 py-2">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredRevenueShare.map((r) => (
                            <tr key={r.id} className="border-b border-slate-100 last:border-0">
                              <td className="px-3 py-2 font-medium text-slate-900">{r.title || '—'}</td>
                              <td className="max-w-[120px] truncate px-3 py-2 text-2xs text-slate-700">{r.productType || '—'}</td>
                              <td className="max-w-[160px] px-3 py-2 font-mono text-2xs text-slate-700">
                                {linkedBasicContractDisplay(r.linkedContractId, contracts)}
                              </td>
                              <td className="px-3 py-2 tabular-nums">
                                {r.revenueSharePercent != null ? `${(Number(r.revenueSharePercent) * 100).toFixed(2)}%` : '—'}
                              </td>
                              <td className="px-3 py-2 text-2xs text-slate-600">
                                {formatDisplayDate(r.startDate)} → {formatDisplayDate(r.endDate)}
                              </td>
                              <td className="px-3 py-2">
                                <Badge variant={(r.status || 'active') === 'active' ? 'success' : 'secondary'}>{r.status || 'active'}</Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {!isTalentFocused && (
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-primary-900">By talent</h3>
          <p className="text-2xs text-neutral">
            Each roster member shows their basic (salary / royalty) agreements and matching revenue-share review rows. Select one talent in the filter to open the two side-by-side sections only for that player.
          </p>
          {talentsOrderedForGroups.map((t) => {
            const basic = filteredBaseContracts.filter((c) => c.talentId === t.id)
            const rs = filteredRevenueShare.filter((r) => r.talentId === t.id)
            if (basic.length === 0 && rs.length === 0) {
              return (
                <Card key={t.id} className="border-dashed border-slate-200/90">
                  <CardHeader className="py-3">
                    <CardTitle className="text-base font-semibold text-slate-800">{t.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="pb-4 pt-0">
                    <p className="text-sm text-neutral">No contracts in the current filter.</p>
                  </CardContent>
                </Card>
              )
            }
            return (
              <Card key={t.id} className="overflow-hidden border-slate-200/90 shadow-sm">
                <CardHeader className="border-b border-slate-100 bg-slate-50/80 py-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <CardTitle className="text-base font-semibold text-primary-900">{t.name}</CardTitle>
                    <Badge variant="secondary" className="text-2xs">
                      {basic.length} basic · {rs.length} revenue share
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-5 pt-4">
                  <div>
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Basic contracts</p>
                    {basic.length === 0 ? (
                      <p className="text-sm text-neutral">None for this filter.</p>
                    ) : (
                      <DataTable columns={compactBasicColumns} data={basic} searchKey="contractID" searchPlaceholder="Search ID…" pageSize={8} />
                    )}
                  </div>
                  <div>
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-600">Talent revenue share (review)</p>
                    {rs.length === 0 ? (
                      <p className="text-sm text-neutral">None for this filter.</p>
                    ) : (
                      <div className="overflow-x-auto rounded-md border border-slate-200">
                        <table className="w-full min-w-[520px] text-left text-sm">
                          <thead className="border-b border-slate-200 bg-slate-50/90 text-2xs font-semibold uppercase tracking-wide text-slate-600">
                            <tr>
                              <th className="px-3 py-2">Title</th>
                              <th className="px-3 py-2">Linked basic</th>
                              <th className="px-3 py-2">%</th>
                              <th className="px-3 py-2">Term</th>
                              <th className="px-3 py-2">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {rs.map((r) => (
                              <tr key={r.id} className="border-b border-slate-100 last:border-0">
                                <td className="px-3 py-2 font-medium text-slate-900">{r.title || '—'}</td>
                                <td className="max-w-[140px] truncate px-3 py-2 font-mono text-2xs text-slate-700">{r.linkedContractId || '—'}</td>
                                <td className="px-3 py-2 tabular-nums">
                                  {r.revenueSharePercent != null ? `${(Number(r.revenueSharePercent) * 100).toFixed(2)}%` : '—'}
                                </td>
                                <td className="px-3 py-2 text-2xs text-slate-600">
                                  {formatDisplayDate(r.startDate)} → {formatDisplayDate(r.endDate)}
                                </td>
                                <td className="px-3 py-2">
                                  <Badge variant={(r.status || 'active') === 'active' ? 'success' : 'secondary'}>{r.status || 'active'}</Badge>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
        )}

        {!isTalentFocused && (
        <div className="space-y-2">
          <h3 className="text-sm font-semibold text-primary-900">Full table (filtered)</h3>
          <DataTable columns={columns} data={filteredBaseContracts} searchKey="contractID" searchPlaceholder="Search contracts..." />
        </div>
        )}
      </div>

      <aside className="w-full shrink-0 space-y-4 lg:sticky lg:top-4 lg:w-72 xl:w-80">
        <Card className="border-primary/15 shadow-md shadow-slate-200/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold text-primary-900">
              <Filter className="h-4 w-4 text-accent" aria-hidden />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs">Talent</Label>
              <Select value={filterTalentId} onValueChange={setFilterTalentId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All talents" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={FILTER_ALL}>All talents</SelectItem>
                  {talents.map((tal) => (
                    <SelectItem key={tal.id} value={tal.id}>
                      {tal.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Contract status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={FILTER_ALL}>All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-lg border border-accent/20 bg-accent/[0.06] p-3 text-2xs leading-relaxed text-slate-700">
              <p className="font-semibold text-primary-900">Talent revenue share band</p>
              <p className="mt-1">
                Enter <span className="font-semibold">{TALENT_RS_MIN_PCT}%–{TALENT_RS_MAX_PCT}%</span> on basic contracts. Vendor uploads stay pending until the club approves them; then Sport Business, talent, and vendor
                revenue views update together.
              </p>
              {isTalentFocused && focusedTalent && (
                <p className="mt-2 border-t border-accent/20 pt-2 text-slate-600">
                  Showing <span className="font-semibold text-primary-900">{focusedTalent.name}</span> only. Basic and revenue-share lists match the talent detail page; save on either screen updates both after refresh.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </aside>

      <Dialog open={open} onOpenChange={(v) => !v && resetForm()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Contract' : 'Create Contract'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Contract ID</Label>
              <Input value={form.contractID} onChange={(e) => setForm((f) => ({ ...f, contractID: e.target.value }))} placeholder="CNT-2024-001" />
            </div>
            <div className="space-y-2">
              <Label>Talent</Label>
              <Select value={form.talentId} onValueChange={(v) => setForm((f) => ({ ...f, talentId: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select talent" />
                </SelectTrigger>
                <SelectContent>
                  {talents.map((tal) => (
                    <SelectItem key={tal.id} value={tal.id}>
                      {tal.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sports Business (Club)</Label>
              <Select value={form.licenseeId} onValueChange={(v) => setForm((f) => ({ ...f, licenseeId: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sports business (club)" />
                </SelectTrigger>
                <SelectContent>
                  {sportsBusinesses.map((b) => (
                    <SelectItem key={b.id} value={b.id}>
                      {b.businessName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sport partner</Label>
              <Select value={form.sponsorId} onValueChange={(v) => setForm((f) => ({ ...f, sponsorId: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sport partner" />
                </SelectTrigger>
                <SelectContent>
                  {sponsorshipCompanies.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.companyName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Basic Salary 2026-27 ($)</Label>
                <Input type="number" value={form.basicSalary2026_27} onChange={(e) => setForm((f) => ({ ...f, basicSalary2026_27: e.target.value }))} placeholder="e.g. 18000000" />
              </div>
              <div className="space-y-2">
                <Label>Basic Salary 2027-28 ($)</Label>
                <Input type="number" value={form.basicSalary2027_28} onChange={(e) => setForm((f) => ({ ...f, basicSalary2027_28: e.target.value }))} placeholder="e.g. 20000000" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Performance Bonus ($) — per month</Label>
              <Input type="number" value={form.signingBonus} onChange={(e) => setForm((f) => ({ ...f, signingBonus: e.target.value }))} placeholder="e.g. 2160000 (12 × $180k/mo pool)" />
            </div>
            <div className="space-y-2">
              <Label>Revenue share % ({TALENT_RS_MIN_PCT}–{TALENT_RS_MAX_PCT})</Label>
              <Input
                type="number"
                step="0.01"
                min={TALENT_RS_MIN_PCT}
                max={TALENT_RS_MAX_PCT}
                value={form.royaltyPercent}
                onChange={(e) => setForm((f) => ({ ...f, royaltyPercent: e.target.value }))}
              />
              <p className="text-2xs text-neutral">Whole percent of net sales (e.g. 5 for 5%). Stored as a decimal on save.</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Input type="date" value={form.startDate} onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>End Date</Label>
                <Input type="date" value={form.endDate} onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetForm}>
                Cancel
              </Button>
              <Button type="submit">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ContractViewer
        open={!!viewContract}
        onOpenChange={(v) => !v && setViewContract(null)}
        contract={viewContract}
        onGeneratePDF={(c) => downloadContractPDF(c, c.talentName, c.licensee)}
      />
      <ContractPDFViewer
        open={!!viewPdfContract}
        onOpenChange={(v) => !v && setViewPdfContract(null)}
        contract={viewPdfContract}
        onDownloadPDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)}
      />
      <ContractDetailsViewer
        open={!!viewDetailsContract}
        onOpenChange={(v) => !v && setViewDetailsContract(null)}
        contract={viewDetailsContract}
      />
    </div>
  )
}
