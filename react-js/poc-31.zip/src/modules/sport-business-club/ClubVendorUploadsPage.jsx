import React, { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { format } from 'date-fns'
import { Info, FileSpreadsheet, Bell, ChevronDown, ChevronRight } from 'lucide-react'
import toast from 'react-hot-toast'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization, update } from '../../database/dbService'
import { rebuildTalentMonthPaymentSnapshotsForOrganization } from '../../repositories/talentMonthPaymentSnapshots'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import {
  BATCH_APPROVAL_APPROVED,
  BATCH_APPROVAL_PENDING,
  summarizeSalesEconomicsForBatch,
} from '../../utils/clubReportingSales'
import { formatINRDisplay } from '../../utils/currencyFormat'

function salesForBatch(allSales, batchId) {
  return (allSales || []).filter((s) => s.vendorImportBatchId === batchId)
}

function talentBreakdownForBatch(batchSales, contracts, talents, sportsBusinesses) {
  const ledger = buildRoyaltyLedger(batchSales, contracts, talents, sportsBusinesses)
  const map = new Map()
  for (const r of ledger) {
    const id = r.talentId
    const prev = map.get(id) || {
      talentId: id,
      talentName: r.talentName,
      royaltyEarned: 0,
      royaltyPercent: r.royaltyPercent,
    }
    prev.royaltyEarned = (Number(prev.royaltyEarned) || 0) + (Number(r.royaltyEarned) || 0)
    prev.royaltyPercent = r.royaltyPercent
    map.set(id, prev)
  }
  return [...map.values()].sort((a, b) => b.royaltyEarned - a.royaltyEarned)
}

/**
 * Sport Business / Club: vendor upload batches (multiple partners), uploader details, economics, and approval
 * before sales flow into dashboards / talents / payment snapshots.
 */
export function ClubVendorUploadsPage() {
  const { loading, loadMessage } = usePageLoadAuto('Loading partner uploads...', 'Partner uploads loaded')
  const { currentOrganizationId } = useOrganization()
  const { bumpDataRevision, dataRevision } = useAppStore()
  const [expandedId, setExpandedId] = useState(null)

  const importBatches = useMemo(() => {
    const list = getAllByOrganization('vendorImportBatches', currentOrganizationId) || []
    return [...list].sort((a, b) => String(b.uploadedAt || '').localeCompare(String(a.uploadedAt || '')))
  }, [currentOrganizationId, dataRevision])

  const allSales = useMemo(
    () => getAllByOrganization('sales', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )

  const pendingCount = useMemo(
    () => importBatches.filter((b) => (b.approvalStatus || BATCH_APPROVAL_APPROVED) === BATCH_APPROVAL_PENDING).length,
    [importBatches]
  )

  const vendorsListed = useMemo(() => {
    const m = new Map()
    for (const b of importBatches) {
      const key = b.vendorCompanyName || b.uploadedByName || b.uploadedByEmail || 'Unknown vendor'
      m.set(key, (m.get(key) || 0) + 1)
    }
    return [...m.entries()].map(([name, batches]) => ({ name, batches }))
  }, [importBatches])

  const approveBatch = (batchId) => {
    if (!currentOrganizationId) return
    const updated = update('vendorImportBatches', batchId, {
      approvalStatus: BATCH_APPROVAL_APPROVED,
      approvedAt: new Date().toISOString(),
    })
    if (!updated) {
      toast.error('Could not update batch')
      return
    }
    try {
      rebuildTalentMonthPaymentSnapshotsForOrganization(currentOrganizationId)
    } catch (e) {
      console.warn('Snapshot rebuild after approval failed', e)
    }
    bumpDataRevision()
    toast.success('Sales approved — talent revenue share and club figures now include this file.')
  }

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          
          <p className="mt-1 text-sm text-neutral">
            All sales files from sponsorship / vendor partners for your organization. Each vendor appears separately with who uploaded the
            file. Approve a batch to roll its revenue share into the Sport Business dashboard, talents, talent detail, and payment
            snapshots.
          </p>
        </div>
        {pendingCount > 0 && (
          <div className="flex items-center gap-2 rounded-lg border border-amber-300/80 bg-amber-50 px-3 py-2 text-sm text-amber-950 shadow-sm">
            <Bell className="h-5 w-5 shrink-0 text-amber-700" aria-hidden />
            <span>
              <span className="font-semibold">{pendingCount}</span> new file{pendingCount === 1 ? '' : 's'} awaiting approval
            </span>
          </div>
        )}
      </div>

      {vendorsListed.length > 0 && (
        <Card className="border-primary/15 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Vendors with uploads</CardTitle>
            <p className="text-2xs text-neutral">Distinct partner labels (company or user) that have submitted at least one batch.</p>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {vendorsListed.map(({ name, batches }) => (
              <Badge key={name} variant="secondary" className="font-normal">
                {name}{' '}
                <span className="ml-1 tabular-nums text-neutral">({batches})</span>
              </Badge>
            ))}
          </CardContent>
        </Card>
      )}

      <div
        className="flex gap-3 rounded-lg border border-amber-200/90 bg-amber-50/90 px-4 py-3 text-sm text-amber-950 shadow-sm"
        role="status"
      >
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" aria-hidden />
        <div>
          <p className="font-medium text-amber-900">Uploads stay pending until you approve</p>
          <p className="mt-1 text-amber-900/90">
            Vendors submit files from Sponsorship / Vendor Portal → Upload Sales. Until you approve here, those rows do not affect club
            dashboards, talent revenue share, or payment summaries.
          </p>
        </div>
      </div>

      <Card className="border-primary/15 shadow-sm">
        <CardHeader className="flex flex-col gap-2 border-b border-slate-200/90 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2">
            <FileSpreadsheet className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden />
            <div>
              <CardTitle className="text-base">Uploaded sales files</CardTitle>
              <p className="text-2xs text-neutral">Expand a row for economics (vendor, club, talent) from contracts in this org.</p>
            </div>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link to="/partner/upload-sales" className="inline-flex items-center gap-1.5">
              Open vendor upload (demo)
            </Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {importBatches.length === 0 ? (
            <p className="p-4 text-sm text-neutral">No partner uploads yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {importBatches.map((b) => {
                const batchSales = salesForBatch(allSales, b.id)
                const econ = summarizeSalesEconomicsForBatch(batchSales, contracts, talents, sportsBusinesses)
                const talentRows = talentBreakdownForBatch(batchSales, contracts, talents, sportsBusinesses)
                const isPending = (b.approvalStatus || BATCH_APPROVAL_APPROVED) === BATCH_APPROVAL_PENDING
                const open = expandedId === b.id
                return (
                  <div key={b.id} className="bg-white">
                    <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setExpandedId(open ? null : b.id)}
                            className="flex items-center gap-1 text-left font-medium text-primary-900 hover:text-primary"
                          >
                            {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                            {b.fileName || '—'}
                          </button>
                          {isPending ? (
                            <Badge className="bg-amber-100 text-amber-900 hover:bg-amber-100">Awaiting approval</Badge>
                          ) : (
                            <Badge variant="success">Approved</Badge>
                          )}
                        </div>
                        <p className="mt-1 text-2xs text-neutral">
                          <span className="font-semibold text-slate-700">{b.vendorCompanyName || b.uploadedByName || 'Vendor'}</span>
                          {b.uploadedByEmail ? <span className="text-neutral"> · {b.uploadedByEmail}</span> : null}
                          {b.uploadedAt ? (
                            <span className="ml-2 font-mono">{format(new Date(b.uploadedAt), 'yyyy-MM-dd HH:mm')}</span>
                          ) : null}
                          <span className="ml-2 tabular-nums">
                            Rows {b.processedCount ?? 0}/{b.rowCount ?? 0}
                          </span>
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        {isPending ? (
                          <Button type="button" size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => approveBatch(b.id)}>
                            Approve sales
                          </Button>
                        ) : null}
                      </div>
                    </div>
                    {open && (
                      <div className="space-y-4 border-t border-slate-100 bg-slate-50/50 px-4 py-4">
                        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                          <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
                            <p className="text-2xs font-medium uppercase tracking-wide text-neutral">Net sales (file)</p>
                            <p className="mt-1 text-lg font-semibold tabular-nums text-primary-900">
                              {formatINRDisplay(econ.totalNet)}
                            </p>
                          </div>
                          <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
                            <p className="text-2xs font-medium uppercase tracking-wide text-neutral">Vendor total (remainder)</p>
                            <p className="mt-1 text-lg font-semibold tabular-nums text-accent-800">
                              {formatINRDisplay(econ.vendorEarned)}
                            </p>
                          </div>
                          <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
                            <p className="text-2xs font-medium uppercase tracking-wide text-neutral">Sports business share</p>
                            <p className="mt-1 text-lg font-semibold tabular-nums text-slate-800">
                              {formatINRDisplay(econ.clubShare)}
                            </p>
                          </div>
                          <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
                            <p className="text-2xs font-medium uppercase tracking-wide text-neutral">Talent revenue share (total)</p>
                            <p className="mt-1 text-lg font-semibold tabular-nums text-emerald-900">
                              {formatINRDisplay(econ.talentRoyalty)}
                            </p>
                          </div>
                        </div>
                        <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                          <table className="w-full min-w-[520px] text-2xs sm:text-xs">
                            <thead>
                              <tr className="border-b bg-slate-50 text-left">
                                <th className="px-3 py-2 font-semibold">Talent</th>
                                <th className="px-3 py-2 text-right font-semibold">Contract rev. %</th>
                                <th className="px-3 py-2 text-right font-semibold">Rev. share amount</th>
                              </tr>
                            </thead>
                            <tbody>
                              {talentRows.length === 0 ? (
                                <tr>
                                  <td colSpan={3} className="px-3 py-3 text-neutral">
                                    No ledger lines (check talent names and licensee vs contracts).
                                  </td>
                                </tr>
                              ) : (
                                talentRows.map((t) => (
                                  <tr key={t.talentId} className="border-b border-slate-100">
                                    <td className="px-3 py-2">{t.talentName}</td>
                                    <td className="px-3 py-2 text-right tabular-nums">
                                      {t.royaltyPercent != null ? `${(Number(t.royaltyPercent) * 100).toFixed(2)}%` : '—'}
                                    </td>
                                    <td className="px-3 py-2 text-right tabular-nums font-medium">
                                      {formatINRDisplay(Number(t.royaltyEarned) || 0)}
                                    </td>
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
