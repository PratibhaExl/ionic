import React, { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { getTalentRosterYearTotals } from '../../repositories/sportsBusinessRepository'
import { resolveDefaultPaymentReportYear } from '../../utils/paymentSummaryYears'
import { Card, CardContent } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Checkbox } from '../../components/ui/checkbox'
import { Badge } from '../../components/ui/badge'
import { StatCard } from '../../components/cards/StatCard'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import {
  Filter,
  Search,
  ChevronDown,
  ChevronRight,
  Users,
  LayoutList,
  DollarSign,
  CheckCircle2,
  Clock,
  Gift,
  TrendingUp,
  Wallet,
  FileText,
} from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { cn } from '../../utils/cn'
import { getTalentEmployeeIdDisplay, talentMatchesSearch } from '../../utils/talentEmployeeId'

const PAGE_SIZE = 6

function talentPaymentStatus(totals) {
  const paid = Number(totals?.grand?.paid) || 0
  const out = Number(totals?.grand?.outstanding) || 0
  if (out <= 0 && paid > 0) return { key: 'completed', label: 'Completed' }
  if (out > 0 && paid > 0) return { key: 'in_progress', label: 'In progress' }
  if (out > 0) return { key: 'pending', label: 'Pending' }
  return { key: 'none', label: '—' }
}

function ReadOnlyCategoryCard({ title, icon: Icon, payable, paid, outstanding }) {
  return (
    <Card className="overflow-hidden rounded-xl border border-primary/15 bg-white shadow-md">
      <div className="flex min-h-[1px] min-w-0">
        <div
          className="w-1.5 shrink-0 bg-gradient-to-b from-accent-300 via-accent-500 to-accent-700 sm:w-2"
          aria-hidden
        />
        <CardContent className="min-w-0 flex-1 space-y-2 bg-gradient-to-r from-accent/[0.04] to-white p-4 sm:p-5">
          <div className="flex items-start justify-between gap-2">
            <p className="text-2xs font-bold uppercase tracking-wide text-primary-900">{title}</p>
            {Icon && (
              <div className="rounded-lg border border-accent/35 bg-accent/12 p-2 shadow-sm">
                <Icon className="h-4 w-4 text-accent-700" />
              </div>
            )}
          </div>
          <div className="space-y-0 divide-y divide-primary/10 rounded-md border border-primary/12 bg-white/95 px-3 py-0.5 shadow-inner">
            <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2 text-2xs sm:text-xs">
              <span className="text-primary-800/90">Payable</span>
              <span className="font-bold tabular-nums text-primary-900">{formatINRDisplay(payable)}</span>
            </div>
            <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2 text-2xs sm:text-xs">
              <span className="text-primary-800/90">Paid (completed)</span>
              <span className="font-bold tabular-nums text-primary-600">{formatINRDisplay(paid)}</span>
            </div>
            <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2 text-2xs sm:text-xs">
              <span className="text-primary-800/90">Outstanding (pending)</span>
              <span className="font-bold tabular-nums text-accent-700">{formatINRDisplay(outstanding)}</span>
            </div>
          </div>
        </CardContent>
      </div>
    </Card>
  )
}

function talentInitials(name) {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function ClubTalentsListPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const { loading, loadMessage } = usePageLoadAuto('Loading talents...', 'Talents loaded')
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId, dataRevision])
  const reportYear = useMemo(
    () => resolveDefaultPaymentReportYear(currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )

  const [search, setSearch] = useState('')
  const [selectedTalentIds, setSelectedTalentIds] = useState([])
  const [page, setPage] = useState(0)
  const [paymentSummaryExpandedId, setPaymentSummaryExpandedId] = useState(null)
  const [rosterPanelOpen, setRosterPanelOpen] = useState(true)
  const [talentWiseOpen, setTalentWiseOpen] = useState(true)

  const filteredTalents = useMemo(() => {
    let list = [...(talents || [])]
    const q = (search || '').toLowerCase().trim()
    if (q) list = list.filter((t) => talentMatchesSearch(t, q))
    if (selectedTalentIds.length > 0) list = list.filter((t) => selectedTalentIds.includes(t.id))
    return list.sort((a, b) => (a.name || '').localeCompare(b.name || ''))
  }, [talents, search, selectedTalentIds])

  const paginatedTalents = useMemo(() => {
    const start = page * PAGE_SIZE
    return filteredTalents.slice(start, start + PAGE_SIZE)
  }, [filteredTalents, page])

  const totalPages = Math.ceil(filteredTalents.length / PAGE_SIZE) || 1
  const talentOptions = useMemo(
    () => (talents || []).map((t) => ({ id: t.id, name: t.name, employeeId: t.employeeId })),
    [talents]
  )

  const { totalsById, rosterAggregate } = useMemo(() => {
    const map = new Map()
    let grandPay = 0
    let grandPaid = 0
    let grandOut = 0
    let sPay = 0
    let sPaid = 0
    let sOut = 0
    let bPay = 0
    let bPaid = 0
    let bOut = 0
    let rPay = 0
    let rPaid = 0
    let rOut = 0
    let mPay = 0
    let mPaid = 0
    let mOut = 0
    let completedTalents = 0
    let inProgressTalents = 0
    let pendingTalents = 0
    for (const t of filteredTalents) {
      const tot = getTalentRosterYearTotals(t.id, currentOrganizationId, reportYear)
      map.set(t.id, tot)
      grandPay += Number(tot.grand.payable) || 0
      grandPaid += Number(tot.grand.paid) || 0
      grandOut += Number(tot.grand.outstanding) || 0
      sPay += Number(tot.salary.payable) || 0
      sPaid += Number(tot.salary.paid) || 0
      sOut += Number(tot.salary.outstanding) || 0
      bPay += Number(tot.bonus.payable) || 0
      bPaid += Number(tot.bonus.paid) || 0
      bOut += Number(tot.bonus.outstanding) || 0
      rPay += Number(tot.royalty.payable) || 0
      rPaid += Number(tot.royalty.paid) || 0
      rOut += Number(tot.royalty.outstanding) || 0
      const misc = tot.miscellaneous || { payable: 0, paid: 0, outstanding: 0 }
      mPay += Number(misc.payable) || 0
      mPaid += Number(misc.paid) || 0
      mOut += Number(misc.outstanding) || 0
      const st = talentPaymentStatus(tot)
      if (st.key === 'completed') completedTalents += 1
      else if (st.key === 'in_progress') inProgressTalents += 1
      else if (st.key === 'pending') pendingTalents += 1
    }
    return {
      totalsById: map,
      rosterAggregate: {
        grandPay,
        grandPaid,
        grandOut,
        salary: { payable: sPay, paid: sPaid, outstanding: sOut },
        bonus: { payable: bPay, paid: bPaid, outstanding: bOut },
        royalty: { payable: rPay, paid: rPaid, outstanding: rOut },
        miscellaneous: { payable: mPay, paid: mPaid, outstanding: mOut },
        completedTalents,
        inProgressTalents,
        pendingTalents,
      },
    }
  }, [filteredTalents, currentOrganizationId, reportYear, dataRevision])

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  const hasActiveFilters = Boolean((search || '').trim()) || selectedTalentIds.length > 0

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold text-primary-800">Talents</h2>
          <p className="mt-1 text-sm text-neutral">
            Roster payment snapshot for <span className="font-semibold text-primary-900">{reportYear}</span> (same engine as Payment
            summary). Summary cards follow your filters; open a talent for detail. Manage basic agreements between each talent and your
            sports business lines from <strong className="font-semibold text-primary-900">Talent &amp; sports contracts</strong>.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" className="shrink-0 border-primary/25 text-primary" asChild>
            <Link to="/sponsorship/talents/contracts" className="inline-flex items-center gap-1.5">
              <FileText className="h-4 w-4" aria-hidden />
              Talent &amp; sports contracts
            </Link>
          </Button>
          <Button variant="outline" size="sm" className="shrink-0 border-primary/25 text-primary" asChild>
            <Link to="/sponsorship/payments">Payment summary</Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Talents in view"
          value={filteredTalents.length}
          icon={Users}
          accentIcon
          subtitle={hasActiveFilters ? 'Filtered roster' : 'Full roster'}
        />
        <StatCard
          title="Total payable"
          value={formatINRDisplay(rosterAggregate.grandPay)}
          icon={DollarSign}
          accentIcon
          subtitle="Salary + bonus + revenue share + misc"
        />
        <StatCard
          title="Paid (completed)"
          value={formatINRDisplay(rosterAggregate.grandPaid)}
          icon={CheckCircle2}
          accentIcon
          subtitle="Released / settled in period"
        />
        <StatCard
          title="Outstanding (pending)"
          value={formatINRDisplay(rosterAggregate.grandOut)}
          icon={Clock}
          accentIcon
          subtitle="Still due on roster in view"
        />
      </div>

      <p className="text-2xs text-neutral">
        <span className="font-semibold text-primary-800">Talent status:</span>{' '}
        <span className="text-emerald-800">{rosterAggregate.completedTalents} completed</span>
        {' · '}
        <span className="text-amber-800">{rosterAggregate.inProgressTalents} in progress</span>
        {' · '}
        <span className="text-slate-700">{rosterAggregate.pendingTalents} pending</span>
        <span className="text-neutral"> (by grand total paid vs outstanding)</span>
      </p>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ReadOnlyCategoryCard
          title="Salary"
          icon={DollarSign}
          payable={rosterAggregate.salary.payable}
          paid={rosterAggregate.salary.paid}
          outstanding={rosterAggregate.salary.outstanding}
        />
        <ReadOnlyCategoryCard
          title="Performance bonus"
          icon={Gift}
          payable={rosterAggregate.bonus.payable}
          paid={rosterAggregate.bonus.paid}
          outstanding={rosterAggregate.bonus.outstanding}
        />
        <ReadOnlyCategoryCard
          title="Revenue share"
          icon={TrendingUp}
          payable={rosterAggregate.royalty.payable}
          paid={rosterAggregate.royalty.paid}
          outstanding={rosterAggregate.royalty.outstanding}
        />
        <ReadOnlyCategoryCard
          title="Miscellaneous"
          icon={Wallet}
          payable={rosterAggregate.miscellaneous.payable}
          paid={rosterAggregate.miscellaneous.paid}
          outstanding={rosterAggregate.miscellaneous.outstanding}
        />
      </div>

      <div className="rounded-lg border border-primary/12 bg-white shadow-sm">
        <button
          type="button"
          onClick={() => setTalentWiseOpen((v) => !v)}
          className="flex w-full items-center gap-3 rounded-lg border border-primary/12 bg-primary/[0.05] p-1.5 pl-4 pr-3 text-left shadow-sm transition-colors hover:bg-primary/[0.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
          aria-expanded={talentWiseOpen}
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
            <LayoutList className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold tracking-tight text-primary-900">Talent-wise payment breakdown</p>
            <p className="mt-0.5 text-2xs leading-snug text-slate-600">
              Per talent: total payable, paid, outstanding, and status (completed / in progress / pending)
            </p>
          </div>
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
            <ChevronDown className={cn('h-5 w-5 transition-transform duration-200', talentWiseOpen && 'rotate-180')} />
          </span>
        </button>
        {talentWiseOpen && (
          <div className="border-t border-slate-200/90 p-4">
            {filteredTalents.length === 0 ? (
              <p className="text-sm text-neutral">No talents match the current filters.</p>
            ) : (
              <div className="overflow-x-auto rounded-lg border border-slate-200/90">
                <table className="w-full min-w-[720px] text-2xs sm:text-xs">
                  <thead>
                    <tr className="border-b bg-slate-50 text-left">
                      <th className="px-3 py-2 font-semibold">Talent</th>
                      <th className="px-3 py-2 font-semibold">Employee ID</th>
                      <th className="px-3 py-2 text-right font-semibold">Total payable</th>
                      <th className="px-3 py-2 text-right font-semibold">Paid</th>
                      <th className="px-3 py-2 text-right font-semibold">Outstanding</th>
                      <th className="px-3 py-2 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTalents.map((t) => {
                      const tot = totalsById.get(t.id)
                      if (!tot) return null
                      const st = talentPaymentStatus(tot)
                      return (
                        <tr key={t.id} className="border-b border-slate-100 hover:bg-slate-50/80">
                          <td className="px-3 py-2 font-medium text-primary-900">{t.name}</td>
                          <td className="px-3 py-2 font-mono text-neutral">{getTalentEmployeeIdDisplay(t)}</td>
                          <td className="px-3 py-2 text-right tabular-nums">{formatINRDisplay(tot.grand.payable)}</td>
                          <td className="px-3 py-2 text-right tabular-nums text-emerald-800">{formatINRDisplay(tot.grand.paid)}</td>
                          <td className="px-3 py-2 text-right tabular-nums text-amber-800">
                            {formatINRDisplay(tot.grand.outstanding)}
                          </td>
                          <td className="px-3 py-2">
                            <Badge
                              variant={
                                st.key === 'completed'
                                  ? 'success'
                                  : st.key === 'in_progress'
                                    ? 'warning'
                                    : st.key === 'pending'
                                      ? 'secondary'
                                      : 'outline'
                              }
                              className="font-normal"
                            >
                              {st.label}
                            </Badge>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
      {/* Left: tab first, then full-width listing */}
      <div className="min-w-0 flex-1">
        <div className="w-full">
          <button
            type="button"
            onClick={() => setRosterPanelOpen((v) => !v)}
            className="mb-4 flex w-full items-center gap-3 rounded-lg border border-primary/12 bg-primary/[0.05] p-1.5 pl-4 pr-3 text-left shadow-sm transition-colors hover:bg-primary/[0.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
            aria-expanded={rosterPanelOpen}
          >
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
              <LayoutList className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold tracking-tight text-primary-900">All Talents Information</p>
              <p className="mt-0.5 text-2xs leading-snug text-slate-600">
                Full-width roster · totals for {reportYear} (same as Payment summary) · expand a row for breakdown
              </p>
            </div>
            <Users className="hidden h-4 w-4 shrink-0 text-primary/40 sm:block" aria-hidden />
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
              <ChevronDown className={cn('h-5 w-5 transition-transform duration-200', rosterPanelOpen && 'rotate-180')} />
            </span>
          </button>

          {rosterPanelOpen && (
            <Card className="overflow-hidden rounded-lg border border-slate-200/90 bg-white shadow-sm">
              <div className="flex items-center justify-between gap-3 border-b border-primary/12 bg-primary/[0.05] px-4 py-2.5 shadow-sm">
                <p className="text-xs font-bold uppercase tracking-wider text-primary-900">All Talents Information</p>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-2xs font-semibold text-primary-800 ring-1 ring-primary/12">
                  {filteredTalents.length} total · {reportYear}
                </span>
              </div>
              <CardContent className="space-y-0 p-0">
                <div className="divide-y divide-slate-200/80 bg-slate-50/40">
                  {paginatedTalents.map((talent, rowIdx) => {
                    const totals = totalsById.get(talent.id)
                    if (!totals) return null
                    const rowStatus = talentPaymentStatus(totals)
                    const psOpen = paymentSummaryExpandedId === talent.id
                    return (
                      <div
                        key={talent.id}
                        className={cn(
                          'w-full transition-colors duration-200',
                          psOpen
                            ? 'bg-primary/[0.04]'
                            : rowIdx % 2 === 1
                              ? 'bg-white hover:bg-slate-50/90'
                              : 'bg-slate-50/30 hover:bg-slate-100/50'
                        )}
                      >
                        <div
                          className={cn(
                            'flex w-full min-w-0 flex-col border-l-[3px]',
                            psOpen ? 'border-l-primary' : 'border-l-transparent hover:border-l-slate-300'
                          )}
                        >
                          <button
                            type="button"
                            className={cn(
                              'flex w-full min-w-0 items-center gap-3 px-4 py-3 text-left outline-none transition-colors sm:gap-4 sm:py-3.5',
                              'focus-visible:bg-primary/[0.06] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary/25'
                            )}
                            onClick={() =>
                              setPaymentSummaryExpandedId((id) => (id === talent.id ? null : talent.id))
                            }
                            aria-expanded={psOpen}
                            aria-label={`${psOpen ? 'Collapse' : 'Expand'} payment summary for ${talent.name}`}
                          >
                            <div
                              className={cn(
                                'flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold shadow-inner sm:h-12 sm:w-12 sm:text-base',
                                psOpen
                                  ? 'bg-primary text-white ring-2 ring-primary/30'
                                  : 'border border-primary/15 bg-primary/[0.08] text-primary-900'
                              )}
                              aria-hidden
                            >
                              {talentInitials(talent.name)}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-bold text-primary-900">{talent.name}</p>
                              <p className="mt-0.5 text-2xs text-slate-600">
                                <span className="font-mono font-semibold text-primary-800">
                                  {getTalentEmployeeIdDisplay(talent)}
                                </span>
                                <span className="mx-1.5 text-slate-300">·</span>
                                <span className="text-slate-600">Signed</span>{' '}
                                <span className="font-medium text-primary-800">{talent.signingDate || '—'}</span>
                              </p>
                              {!psOpen && (
                                <>
                                  <div className="mt-2 flex flex-wrap gap-2">
                                    <Badge
                                      variant={
                                        rowStatus.key === 'completed'
                                          ? 'success'
                                          : rowStatus.key === 'in_progress'
                                            ? 'warning'
                                            : rowStatus.key === 'pending'
                                              ? 'secondary'
                                              : 'outline'
                                      }
                                      className="text-2xs font-medium"
                                    >
                                      {rowStatus.label}
                                    </Badge>
                                    <span className="inline-flex items-center rounded-full border border-primary/20 bg-primary/[0.08] px-2.5 py-0.5 text-2xs font-medium text-primary-900">
                                      Payable {formatINRDisplay(totals.grand.payable)}
                                    </span>
                                    <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-2.5 py-0.5 text-2xs font-medium text-slate-700">
                                      Outstanding {formatINRDisplay(totals.grand.outstanding)}
                                    </span>
                                    <span className="inline-flex items-center rounded-full border border-slate-200 bg-white px-2.5 py-0.5 text-2xs font-medium text-slate-700">
                                      Paid {formatINRDisplay(totals.grand.paid)}
                                    </span>
                                  </div>
                                  <p className="mt-1.5 text-[10px] font-medium uppercase tracking-wide text-primary/50">
                                    Tap for payment summary
                                  </p>
                                </>
                              )}
                            </div>
                            <span
                              className={cn(
                                'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border text-primary',
                                psOpen ? 'border-primary/25 bg-primary/10' : 'border-slate-200 bg-white shadow-sm'
                              )}
                              aria-hidden
                            >
                              <ChevronRight
                                className={cn(
                                  'h-4 w-4 transition-transform duration-200 ease-out sm:h-[18px] sm:w-[18px]',
                                  psOpen ? 'rotate-90' : 'rotate-0'
                                )}
                              />
                            </span>
                          </button>

                        </div>
                        {psOpen && (
                          <div className="border-t border-slate-200/90 bg-slate-50/50 px-4 pb-4 pt-3">
                            <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">
                              Payment summary · {reportYear}
                            </p>
                            <div className="overflow-x-auto rounded-lg border-2 border-primary/18 bg-white/95 shadow-inner shadow-primary/[0.08] ring-1 ring-primary/[0.05]">
                              <table className="w-full min-w-[520px] text-2xs">
                                <thead>
                                  <tr className="border-b border-primary/15 bg-primary/12 text-left text-primary-900">
                                    <th className="px-3 py-2 text-2xs font-bold">Type</th>
                                    <th className="px-3 py-2 text-right text-2xs font-bold">Payable</th>
                                    <th className="px-3 py-2 text-right text-2xs font-bold">Paid</th>
                                    <th className="px-3 py-2 text-right text-2xs font-bold">Outstanding</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {[
                                    { label: 'Salary', ...totals.salary },
                                    { label: 'Bonus', ...totals.bonus },
                                    { label: 'Revenue share', ...totals.royalty },
                                    {
                                      label: 'Miscellaneous',
                                      ...(totals.miscellaneous || { payable: 0, paid: 0, outstanding: 0 }),
                                    },
                                  ].map((row) => (
                                    <tr
                                      key={row.label}
                                      className="border-b border-primary/[0.08] last:border-0 odd:bg-primary/[0.02]"
                                    >
                                      <td className="px-3 py-2 text-2xs font-semibold text-primary-900">{row.label}</td>
                                      <td className="px-3 py-2 text-right text-2xs tabular-nums text-gray-800">
                                        {formatINRDisplay(row.payable)}
                                      </td>
                                      <td className="px-3 py-2 text-right text-2xs tabular-nums text-green-700">
                                        {formatINRDisplay(row.paid)}
                                      </td>
                                      <td className="px-3 py-2 text-right text-2xs tabular-nums text-amber-700">
                                        {formatINRDisplay(row.outstanding)}
                                      </td>
                                    </tr>
                                  ))}
                                  <tr className="bg-primary/15 text-xs font-bold text-primary-950">
                                    <td className="px-3 py-2">Total</td>
                                    <td className="px-3 py-2 text-right tabular-nums">
                                      {formatINRDisplay(totals.grand.payable)}
                                    </td>
                                    <td className="px-3 py-2 text-right tabular-nums text-green-900">
                                      {formatINRDisplay(totals.grand.paid)}
                                    </td>
                                    <td className="px-3 py-2 text-right tabular-nums text-amber-900">
                                      {formatINRDisplay(totals.grand.outstanding)}
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                            <div className="flex justify-end border-t border-slate-200/90 bg-slate-50/60 px-1 py-3">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                className="h-7 border-primary/30 px-2.5 text-2xs font-semibold text-primary hover:bg-primary/10"
                                onClick={() => navigate(`/sponsorship/talents/${talent.id}`)}
                              >
                                View more
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>

                <div className="space-y-3 border-t border-slate-200/90 bg-slate-50/50 px-4 py-4">
                  <p className="text-2xs text-neutral">
                    Showing {paginatedTalents.length} of {filteredTalents.length} talent
                    {filteredTalents.length !== 1 ? 's' : ''} · page {page + 1} of {totalPages}
                  </p>

                  {filteredTalents.length === 0 && (
                    <p className="text-2xs text-neutral">No talents match the current filters.</p>
                  )}

                  {totalPages > 1 && (
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                        disabled={page === 0}
                        onClick={() => setPage((p) => p - 1)}
                      >
                        Previous
                      </Button>
                      <span className="text-2xs font-medium text-primary-800">
                        Page {page + 1} of {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                        disabled={page >= totalPages - 1}
                        onClick={() => setPage((p) => p + 1)}
                      >
                        Next
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Right: filters */}
      <aside className="w-full shrink-0 overflow-hidden rounded-xl border-2 border-accent/35 bg-accent/[0.07] shadow-md shadow-primary/5 lg:w-80">
        <div className="border-b-2 border-accent/30 bg-primary px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/15 text-accent-200">
              <Filter className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white">Filters</p>
              <p className="text-2xs font-medium text-primary-100/90">Search & narrow the list</p>
            </div>
          </div>
        </div>

        <div className="space-y-4 bg-white/90 p-4">
          <div>
            <label className="mb-1.5 block text-2xs font-semibold uppercase tracking-wide text-primary-800">
              Search
            </label>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-accent-600" />
              <Input
                placeholder="Name…"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                className="h-8 border-accent/25 bg-white pl-8 text-2xs text-gray-800 placeholder:text-neutral focus-visible:border-accent/50 focus-visible:ring-accent/20"
              />
            </div>
          </div>

          <div>
            <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">Include only</p>
            <p className="mb-2 text-2xs leading-relaxed text-neutral">Check talents to restrict the list (none = all).</p>
            <div className="max-h-[46vh] space-y-1 overflow-y-auto rounded-lg border border-slate-200/90 bg-slate-50/80 p-2 scrollbar-thin">
              {talentOptions.length === 0 ? (
                <p className="px-2 py-2 text-2xs text-neutral">No talent data</p>
              ) : (
                talentOptions.map((t) => {
                  const checked = selectedTalentIds.includes(t.id)
                  return (
                    <label
                      key={t.id}
                      className={cn(
                        'flex cursor-pointer items-center gap-2 rounded-md px-2 py-2 text-2xs transition-colors',
                        checked
                          ? 'bg-primary/15 font-medium text-primary-900 ring-1 ring-primary/25'
                          : 'text-gray-800 hover:bg-white/90 hover:ring-1 hover:ring-accent/20'
                      )}
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={() =>
                          setSelectedTalentIds((prev) =>
                            prev.includes(t.id) ? prev.filter((id) => id !== t.id) : [...prev, t.id]
                          )
                        }
                        className="border-primary/40 data-[state=checked]:border-primary data-[state=checked]:bg-primary"
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate">{t.name}</span>
                        {t.employeeId ? (
                          <span className="mt-0.5 block truncate font-mono text-3xs text-primary-700">{t.employeeId}</span>
                        ) : null}
                      </span>
                    </label>
                  )
                })
              )}
            </div>
          </div>

          {(search || selectedTalentIds.length > 0) && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 w-full border-accent/40 text-2xs font-semibold text-accent-700 hover:bg-accent/10 hover:text-accent-800"
              onClick={() => {
                setSearch('')
                setSelectedTalentIds([])
                setPage(0)
              }}
            >
              Clear filters
            </Button>
          )}
        </div>
      </aside>
      </div>
    </div>
  )
}
