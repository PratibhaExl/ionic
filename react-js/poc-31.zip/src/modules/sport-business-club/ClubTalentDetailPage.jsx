import React, { useEffect, useMemo, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { useOrganizationData } from '../../hooks/useOrganizationData'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getReportingSalesForOrganization } from '../../utils/clubReportingSales'
import {
  enrichSalaryPayments,
  MONTHLY_PERFORMANCE_BONUS_AMOUNT,
  PERFORMANCE_BONUS_PAYROLL_LABEL,
} from '../../utils/salaryCalculator'
import { processSalaryPayment, processSigningBonusPayment, processRoyaltyPayment, recordPaymentLedgerEntry } from '../../utils/paymentProcessor'
import { downloadContractPDF } from '../../utils/pdfGenerator'
import { ContractViewer } from '../../components/forms/ContractViewer'
import { ContractPDFViewer } from '../../components/forms/ContractPDFViewer'
import { ContractDetailsViewer } from '../../components/forms/ContractDetailsViewer'
import { StatCard } from '../../components/cards/StatCard'
import { PaymentTypeDashboardCard } from '../../components/cards/PaymentTypeDashboardCard'
import { PaymentBucketsPieChart } from '../../components/charts/PaymentBucketsPieChart'
import { GroupedMonthlyPaymentChart } from '../../components/charts/GroupedMonthlyPaymentChart'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'
import { PaymentModal } from '../../components/PaymentModal'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import {
  User,
  FileText,
  DollarSign,
  Gift,
  TrendingUp,
  Wallet,
  ArrowLeft,
  Plus,
  Pencil,
  Trash2,
  FileSpreadsheet,
  ChevronRight,
  CalendarRange,
} from 'lucide-react'
import { getTalentYearPaymentBreakdown, getTalentMonthWisePaymentBreakdown } from '../../repositories/sportsBusinessRepository'
import { resolveDefaultPaymentReportYear, EXCLUDED_PAYMENT_REPORT_YEARS } from '../../utils/paymentSummaryYears'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { formatDisplayDate } from '../../utils/dateFormat'
import toast from 'react-hot-toast'
import Papa from 'papaparse'
import { Badge } from '../../components/ui/badge'
import { cn } from '../../utils/cn'
import { getTalentEmployeeIdDisplay } from '../../utils/talentEmployeeId'

const RS_LINK_NONE = '__none__'
const MIN_BASIC_CONTRACTS = 2

/** Deep-link to club Payment summary (tab, reporting year, optional roster talent). */
function clubPaymentSummaryHref(tab, { talentId, year, from } = {}) {
  const q = new URLSearchParams()
  q.set('tab', tab)
  if (year != null && String(year).trim() !== '') q.set('year', String(year))
  if (talentId) q.set('talentId', String(talentId))
  if (from) q.set('from', from)
  return `/sponsorship/payments?${q.toString()}`
}

/** Years that appear in this talent's payment sources (for default year picker). */
function inferPaymentYearsForTalent(mySalaryPayments, mySigningBonuses, myLedger, myInvoices) {
  const years = new Set()
  const addY = (y) => {
    const n = Number(y)
    if (Number.isFinite(n) && n >= 2000 && n <= 2100) years.add(n)
  }
  const addFromYm = (ym) => {
    if (ym && typeof ym === 'string' && /^\d{4}/.test(ym)) addY(ym.slice(0, 4))
  }
  const addFromDate = (d) => {
    if (!d) return
    if (typeof d === 'string' && /^\d{4}/.test(d)) addY(d.slice(0, 4))
    else {
      const t = new Date(d).getFullYear()
      if (!Number.isNaN(t)) addY(t)
    }
  }
  ;(mySalaryPayments || []).forEach((s) => addFromYm(s.month))
  ;(mySigningBonuses || []).forEach((b) => {
    addFromDate(b.signingDate)
    addFromDate(b.releaseDate)
  })
  ;(myLedger || []).forEach((r) => addFromDate(r.date))
  ;(myInvoices || []).forEach((inv) => {
    addFromDate(inv.issueDate || inv.invoiceDate || inv.date)
  })
  addY(new Date().getFullYear())
  return years
}

/** Main section header chevron — flat theme (→ / ↓). */
function RosterSectionChevron({ open }) {
  return (
    <span
      className={cn(
        'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10 transition-colors duration-200',
        open && 'border-primary/22 bg-primary/[0.08] text-primary-900'
      )}
      aria-hidden
    >
      <ChevronRight
        className={cn(
          'h-5 w-5 transition-transform duration-200 ease-out',
          open ? '-rotate-90' : 'rotate-90'
        )}
      />
    </span>
  )
}

/** Nested row chevron — same as dashboard talent row (→ / ↓). */
function RosterRowChevron({ open }) {
  return (
    <span
      className={cn(
        'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border text-primary',
        open ? 'border-primary/25 bg-primary/10' : 'border-slate-200 bg-white shadow-sm'
      )}
      aria-hidden
    >
      <ChevronRight
        className={cn(
          'h-4 w-4 transition-transform duration-200 ease-out sm:h-[18px] sm:w-[18px]',
          open ? 'rotate-90' : 'rotate-0'
        )}
      />
    </span>
  )
}

function contractInitials(c) {
  const id = String(c?.contractID || '').trim()
  if (id.length >= 2) return id.slice(0, 2).toUpperCase()
  return 'C'
}

export function ClubTalentDetailPage() {
  const { talentId } = useParams()
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { dataRevision, bumpDataRevision } = useAppStore()
  const { loading, loadMessage } = usePageLoadAuto('Loading talent details...', 'Loaded')

  const openPaymentSummaryTab = React.useCallback(
    (tab, year) => {
      navigate(
        clubPaymentSummaryHref(tab, {
          talentId,
          year: year ?? undefined,
          from: 'talent-detail',
        })
      )
    },
    [navigate, talentId]
  )

  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId, dataRevision])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId, dataRevision])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId, dataRevision])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId, dataRevision])
  const miscellaneousPayments = useMemo(
    () => getAllByOrganization('miscellaneousPayments', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sales = useMemo(
    () => getReportingSalesForOrganization(currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId, dataRevision])

  const { data: contractsData, create: createContract, update: updateContract, remove: removeContract } =
    useOrganizationData('contracts')
  const {
    data: revenueShareContractsData,
    create: createRevenueShareContract,
    update: updateRevenueShareContract,
    remove: removeRevenueShareContract,
  } = useOrganizationData('revenueShareContracts')
  const talent = useMemo(() => (talents || []).find((t) => t.id === talentId), [talents, talentId])
  const myContracts = useMemo(
    () =>
      (contractsData || [])
        .filter((c) => c.talentId === talentId)
        .sort((a, b) => (a.startDate || '').localeCompare(b.startDate || '')),
    [contractsData, talentId]
  )
  const myRevenueShareContracts = useMemo(
    () =>
      (revenueShareContractsData || [])
        .filter((c) => c.talentId === talentId)
        .sort((a, b) => (a.startDate || '').localeCompare(b.startDate || '')),
    [revenueShareContractsData, talentId]
  )
  const sponsorshipCompanies = useMemo(() => getAllByOrganization('sponsorshipCompanies', currentOrganizationId), [currentOrganizationId, dataRevision])

  const mySalaryPayments = useMemo(() => (salaryPayments || []).filter((s) => s.talentId === talentId), [salaryPayments, talentId])
  const mySigningBonuses = useMemo(() => (signingBonuses || []).filter((b) => b.talentId === talentId), [signingBonuses, talentId])
  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contractsData || [], talents, sportsBusinesses),
    [sales, contractsData, talents, sportsBusinesses, dataRevision]
  )
  const myLedger = useMemo(() => ledger.filter((r) => r.talentId === talentId), [ledger, talentId])
  const myInvoices = useMemo(() => (invoices || []).filter((inv) => inv.talentId === talentId), [invoices, talentId])
  const myMiscPayments = useMemo(
    () => (miscellaneousPayments || []).filter((r) => r.talentId === talentId),
    [miscellaneousPayments, talentId]
  )

  const enrichedSalaryPayments = useMemo(() => enrichSalaryPayments(mySalaryPayments, mySigningBonuses, myLedger), [mySalaryPayments, mySigningBonuses, myLedger])

  const pendingSalaryList = useMemo(() => enrichedSalaryPayments.filter((s) => s.paymentStatus === 'pending'), [enrichedSalaryPayments])
  const pendingBonusList = useMemo(() => mySigningBonuses.filter((b) => b.status === 'pending'), [mySigningBonuses])
  const pendingRoyaltyList = useMemo(() => myInvoices.filter((inv) => (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0) > 0), [myInvoices])

  const totalPendingAmount = useMemo(() => {
    let sum = pendingSalaryList.reduce((a, s) => a + (s.totalEarnings || 0), 0)
    sum += pendingBonusList.reduce((a, b) => a + (Number(b.amount) || 0), 0)
    pendingRoyaltyList.forEach((inv) => {
      sum += (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
    })
    return sum
  }, [pendingSalaryList, pendingBonusList, pendingRoyaltyList])

  const [paymentModal, setPaymentModal] = useState(null)
  const [viewContract, setViewContract] = useState(null)
  const [viewPdfContract, setViewPdfContract] = useState(null)
  const [viewDetailsContract, setViewDetailsContract] = useState(null)
  const [contractDialogOpen, setContractDialogOpen] = useState(false)
  const [editingContract, setEditingContract] = useState(null)
  const [expandedContractId, setExpandedContractId] = useState(null)
  const [expandedRsContractId, setExpandedRsContractId] = useState(null)
  /** Main section expand/collapse */
  const [openContractsSection, setOpenContractsSection] = useState(true)
  const [openRsContractsSection, setOpenRsContractsSection] = useState(true)
  const [openPaymentSection, setOpenPaymentSection] = useState(true)
  const [openMonthWiseSection, setOpenMonthWiseSection] = useState(true)
  const [openPaymentDistributionSection, setOpenPaymentDistributionSection] = useState(true)
  const [paymentYear, setPaymentYear] = useState(() => String(new Date().getFullYear()))

  // Default reporting year matches Payment summary / roster (not “max year in this talent’s rows”).
  useEffect(() => {
    setPaymentYear(resolveDefaultPaymentReportYear(currentOrganizationId))
  }, [talentId, currentOrganizationId])

  const [contractForm, setContractForm] = useState({
    contractID: '',
    talentId: '',
    licenseeId: '',
    sponsorId: '',
    productType: '',
    basicSalary2026_27: '',
    basicSalary2027_28: '',
    signingBonus: '',
    royaltyPercent: '',
    startDate: '',
    endDate: '',
    status: 'active',
    contractSummary: '',
    contractSigningDate: '',
  })

  const [rsContractDialogOpen, setRsContractDialogOpen] = useState(false)
  const [editingRsContract, setEditingRsContract] = useState(null)
  const [rsContractForm, setRsContractForm] = useState({
    title: '',
    summary: '',
    signingDate: '',
    startDate: '',
    endDate: '',
    productType: '',
    revenueSharePercent: '',
    linkedContractId: RS_LINK_NONE,
    status: 'active',
  })

  const yearPayment = useMemo(
    () => getTalentYearPaymentBreakdown(talentId, currentOrganizationId, paymentYear),
    [talentId, currentOrganizationId, paymentYear, dataRevision]
  )

  const yearPaymentMisc = useMemo(() => {
    const y = String(paymentYear)
    const rows = myMiscPayments.filter((r) => String(r.periodMonth || '').startsWith(`${y}-`))
    const payable = rows.reduce((a, r) => a + (Number(r.amount) || 0), 0)
    const paid = rows.filter((r) => r.paymentStatus === 'paid').reduce((a, r) => a + (Number(r.amount) || 0), 0)
    const outstanding = rows.filter((r) => r.paymentStatus === 'pending').reduce((a, r) => a + (Number(r.amount) || 0), 0)
    return { payable, paid, outstanding }
  }, [myMiscPayments, paymentYear])

  /** Sum of salary + performance bonus + royalty + misc for the year-wise table footer. */
  const yearPaymentCombinedTotals = useMemo(() => {
    const sum4 = (key) =>
      (Number(yearPayment.salary[key]) || 0) +
      (Number(yearPayment.bonus[key]) || 0) +
      (Number(yearPayment.royalty[key]) || 0) +
      (Number(yearPaymentMisc[key]) || 0)
    return {
      payable: sum4('payable'),
      paid: sum4('paid'),
      outstanding: sum4('outstanding'),
    }
  }, [yearPayment, yearPaymentMisc])

  const monthWisePayment = useMemo(
    () => getTalentMonthWisePaymentBreakdown(talentId, currentOrganizationId, paymentYear),
    [talentId, currentOrganizationId, paymentYear, dataRevision]
  )

  const monthWiseSorted = useMemo(
    () => [...monthWisePayment].sort((a, b) => String(a.month || '').localeCompare(String(b.month || ''))),
    [monthWisePayment]
  )

  /** One chart: salary / bonus / revenue share payable per month (grouped bars, distinct colors). */
  const monthWiseGroupedChartData = useMemo(
    () =>
      monthWiseSorted.map((m) => ({
        month: m.month,
        salary: Number(m.salary?.payable) || 0,
        bonus: Number(m.bonus?.payable) || 0,
        royalty: Number(m.royalty?.payable) || 0,
      })),
    [monthWiseSorted]
  )

  const paymentYearOptions = useMemo(() => {
    const set = new Set(['2028', '2027', '2026', '2025', '2024', '2023'])
    inferPaymentYearsForTalent(mySalaryPayments, mySigningBonuses, myLedger, myInvoices).forEach((y) =>
      set.add(String(y))
    )
    if (paymentYear) set.add(String(paymentYear))
    return [...set]
      .filter((y) => !EXCLUDED_PAYMENT_REPORT_YEARS.has(y))
      .sort((a, b) => Number(b) - Number(a))
  }, [mySalaryPayments, mySigningBonuses, myLedger, myInvoices, paymentYear, dataRevision])

  useEffect(() => {
    if (paymentYearOptions.length > 0 && !paymentYearOptions.includes(paymentYear)) {
      setPaymentYear(paymentYearOptions[0])
    }
  }, [paymentYear, paymentYearOptions])

  const resetContractForm = () => {
    setContractForm({
      contractID: '',
      talentId: talentId || '',
      licenseeId: '',
      sponsorId: '',
      productType: '',
      basicSalary2026_27: '',
      basicSalary2027_28: '',
      signingBonus: '',
      royaltyPercent: '',
      startDate: '',
      endDate: '',
      status: 'active',
      contractSummary: '',
      contractSigningDate: '',
    })
    setEditingContract(null)
    setContractDialogOpen(false)
  }

  const openEditContract = (row) => {
    setEditingContract(row)
    setContractForm({
      contractID: row.contractID || '',
      talentId: row.talentId || '',
      licenseeId: row.licenseeId || '',
      sponsorId: row.sponsorId || '',
      productType: row.productType || '',
      basicSalary2026_27: String(row.basicSalary2026_27 ?? row.annualSalary ?? ''),
      basicSalary2027_28: String(row.basicSalary2027_28 ?? row.annualSalary ?? ''),
      signingBonus: String(row.signingBonus ?? ''),
      royaltyPercent: String((row.royaltyPercent ?? 0) * 100),
      startDate: row.startDate || '',
      endDate: row.endDate || '',
      status: row.status || 'active',
      contractSummary: row.contractSummary || '',
      contractSigningDate: row.contractSigningDate || '',
    })
    setContractDialogOpen(true)
  }

  const openAddContract = () => {
    setEditingContract(null)
    setContractForm({
      contractID: '',
      talentId: talentId || '',
      licenseeId: '',
      sponsorId: '',
      productType: '',
      basicSalary2026_27: '',
      basicSalary2027_28: '',
      signingBonus: '',
      royaltyPercent: '',
      startDate: '',
      endDate: '',
      status: 'active',
      contractSummary: '',
      contractSigningDate: '',
    })
    setContractDialogOpen(true)
  }

  const handleContractSubmit = (e) => {
    e.preventDefault()
    const talentObj = talents.find((t) => t.id === contractForm.talentId)
    const licenseeBiz = sportsBusinesses.find((b) => b.id === contractForm.licenseeId)
    const annualSalary = Number(contractForm.basicSalary2026_27) || 0
    const payload = {
      contractID: contractForm.contractID || `CNT-${Date.now()}`,
      talentId: contractForm.talentId,
      talentName: talentObj?.name || '',
      licenseeId: contractForm.licenseeId,
      licensee: licenseeBiz?.businessName || '',
      sponsorId: contractForm.sponsorId,
      productType: contractForm.productType || '',
      organizationId: currentOrganizationId,
      annualSalary,
      basicSalary2026_27: Number(contractForm.basicSalary2026_27) || 0,
      basicSalary2027_28: Number(contractForm.basicSalary2027_28) || 0,
      signingBonus: Number(contractForm.signingBonus) || 0,
      royaltyPercent: Number(contractForm.royaltyPercent) / 100 || 0,
      startDate: contractForm.startDate,
      endDate: contractForm.endDate,
      status: contractForm.status,
      contractSummary: contractForm.contractSummary || '',
      contractSigningDate: contractForm.contractSigningDate || '',
    }
    if (editingContract) {
      updateContract(editingContract.id, payload)
      toast.success('Contract updated')
    } else {
      createContract(payload)
      toast.success('Contract created')
    }
    bumpDataRevision()
    resetContractForm()
  }

  const handleRemoveContract = (id) => {
    removeContract(id)
    bumpDataRevision()
    toast.success('Contract removed')
    resetContractForm()
  }

  const downloadContractCsv = (c) => {
    const pct = c.royaltyPercent != null ? (Number(c.royaltyPercent) * 100).toFixed(2) : '—'
    const rows = [
      { Label: 'Contract ID', Value: c.contractID || '—' },
      { Label: 'Contract summary', Value: c.contractSummary || '—' },
      { Label: 'Contract signing date', Value: c.contractSigningDate || '—' },
      { Label: 'Product / type', Value: c.productType || '—' },
      { Label: 'Revenue share %', Value: `${pct}%` },
      { Label: 'Contract start date', Value: c.startDate || '—' },
      { Label: 'Contract end date', Value: c.endDate || '—' },
      { Label: 'Licensee', Value: c.licensee || '—' },
      { Label: 'Status', Value: c.status || '—' },
      { Label: 'Salary 2026-27', Value: String(c.basicSalary2026_27 ?? c.annualSalary ?? '') },
      { Label: 'Performance bonus (contract)', Value: String(c.signingBonus ?? '') },
    ]
    const csv = Papa.unparse(rows)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `contract-${(c.contractID || c.id || 'export').replace(/[^\w.-]+/g, '_')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
    toast.success('Contract CSV downloaded')
  }

  const resetRsContractForm = () => {
    setRsContractForm({
      title: '',
      summary: '',
      signingDate: '',
      startDate: '',
      endDate: '',
      productType: '',
      revenueSharePercent: '',
      linkedContractId: RS_LINK_NONE,
      status: 'active',
    })
    setEditingRsContract(null)
    setRsContractDialogOpen(false)
  }

  const openAddRsContract = () => {
    setEditingRsContract(null)
    setRsContractForm({
      title: '',
      summary: '',
      signingDate: '',
      startDate: '',
      endDate: '',
      productType: '',
      revenueSharePercent: '',
      linkedContractId: (myContracts && myContracts[0]?.id) || RS_LINK_NONE,
      status: 'active',
    })
    setRsContractDialogOpen(true)
  }

  const openEditRsContract = (row) => {
    setEditingRsContract(row)
    setRsContractForm({
      title: row.title || '',
      summary: row.summary || '',
      signingDate: row.signingDate || '',
      startDate: row.startDate || '',
      endDate: row.endDate || '',
      productType: row.productType || '',
      revenueSharePercent: String((row.revenueSharePercent ?? 0) * 100),
      linkedContractId: row.linkedContractId || RS_LINK_NONE,
      status: row.status || 'active',
    })
    setRsContractDialogOpen(true)
  }

  const handleRsContractSubmit = (e) => {
    e.preventDefault()
    const payload = {
      organizationId: currentOrganizationId,
      talentId,
      talentName: talent?.name || '',
      title: rsContractForm.title || `RS — ${rsContractForm.productType || 'Agreement'}`,
      summary: rsContractForm.summary || '',
      signingDate: rsContractForm.signingDate,
      startDate: rsContractForm.startDate,
      endDate: rsContractForm.endDate,
      productType: rsContractForm.productType || '',
      revenueSharePercent: Number(rsContractForm.revenueSharePercent) / 100 || 0,
      linkedContractId: rsContractForm.linkedContractId === RS_LINK_NONE ? '' : rsContractForm.linkedContractId,
      status: rsContractForm.status,
    }
    if (editingRsContract) {
      updateRevenueShareContract(editingRsContract.id, payload)
      toast.success('Revenue share agreement updated')
    } else {
      createRevenueShareContract(payload)
      toast.success('Revenue share agreement added')
    }
    bumpDataRevision()
    resetRsContractForm()
  }

  const handleRemoveRsContract = (id) => {
    removeRevenueShareContract(id)
    bumpDataRevision()
    toast.success('Revenue share agreement removed')
    resetRsContractForm()
  }

  const handleReleasePayment = () => {
    if (totalPendingAmount <= 0) {
      toast.error('No pending amount to pay')
      return
    }
    setPaymentModal({
      amount: totalPendingAmount,
      title: `Release payment — ${talent?.name || 'Talent'}`,
    })
  }

  const handlePaymentSuccess = ({ amount, paymentMethod }) => {
    if (!talent) return
    try {
      pendingSalaryList.forEach((s) => processSalaryPayment(s, paymentMethod, currentOrganizationId))
      pendingBonusList.forEach((b) => processSigningBonusPayment(b, paymentMethod, currentOrganizationId))
      pendingRoyaltyList.forEach((inv) => {
        const due = (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
        if (due > 0) processRoyaltyPayment(inv, due, paymentMethod, currentOrganizationId)
      })
      recordPaymentLedgerEntry({
        organizationId: currentOrganizationId,
        talentId: talent.id,
        talentName: talent.name,
        paymentType: 'Release Payment',
        amount,
        paymentMethod,
        details: 'Single payment done',
      })
      toast.success('Release payment recorded')
      setPaymentModal(null)
      setTimeout(() => window.location.reload(), 600)
    } catch (e) {
      toast.error('Failed to record payment')
      setPaymentModal(null)
    }
  }

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />
  if (!talent) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/sponsorship/talents')}><ArrowLeft className="h-4 w-4 mr-1" /> Back to Talents</Button>
        <p className="text-neutral">Talent not found.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" onClick={() => navigate('/sponsorship/talents')}><ArrowLeft className="h-4 w-4 mr-1" /> Back to Talents</Button>

      {/* Talent info — year filter lives under Payment details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
            <div className="flex min-w-0 flex-wrap items-center gap-2">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <User className="h-5 w-5" />
              </div>
              <span className="text-lg font-semibold tracking-tight">{talent.name}</span>
              <Badge variant="secondary" className="border border-primary/20 bg-primary/[0.06] font-mono text-2xs font-semibold text-primary-800">
                Employee ID: {getTalentEmployeeIdDisplay(talent)}
              </Badge>
            </div>
          </CardTitle>
          <p className="text-sm text-neutral">
            Signing date: {talent.signingDate || '—'} · Performance bonus status:{' '}
            {talent.signingBonusStatus || '—'}
          </p>
        </CardHeader>
      </Card>

      {/* Contracts — same expandable pattern as dashboard talents roster */}
      <Card className="overflow-hidden border-2 border-slate-200/90 bg-white shadow-md shadow-slate-200/40">
        <div className="flex w-full flex-col border-b border-slate-200/95 sm:flex-row sm:items-stretch">
          <button
            type="button"
            className="flex min-w-0 flex-1 items-center gap-3 border-b border-primary/12 bg-primary/[0.05] px-4 py-3.5 text-left shadow-sm transition-colors hover:bg-primary/[0.08] sm:gap-4 sm:border-b-0 sm:border-r sm:border-primary/12 sm:px-5"
            aria-expanded={openContractsSection}
            aria-label={openContractsSection ? 'Collapse contracts' : 'Expand contracts'}
            onClick={() => setOpenContractsSection((v) => !v)}
          >
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10 sm:h-12 sm:w-12">
              <FileText className="h-5 w-5 sm:h-6 sm:w-6" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm font-bold tracking-tight text-primary-900">Contracts</p>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-2xs font-semibold tabular-nums text-primary-800 ring-1 ring-primary/12">
                  {myContracts.length} {myContracts.length === 1 ? 'contract' : 'contracts'}
                </span>
              </div>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600">
                Basic contracts (salary terms, product type &amp; dates) · aim for at least {MIN_BASIC_CONTRACTS} per talent for vendor
                / club demos · tap a row for actions ·{' '}
                <Link
                  to="/sponsorship/talents/contracts"
                  state={{ focusTalentId: talentId }}
                  className="font-semibold text-primary underline-offset-2 hover:underline"
                >
                  Open in Contracts hub
                </Link>{' '}
                (same data, filtered by this talent)
              </p>
            </div>
            <RosterSectionChevron open={openContractsSection} />
          </button>
          <div className="flex shrink-0 items-center justify-center border-t border-primary/12 bg-primary/[0.04] px-4 py-2.5 sm:border-t-0 sm:border-l sm:border-primary/12 sm:px-4">
            <Button type="button" variant="accent" size="sm" onClick={openAddContract}>
              <Plus className="h-4 w-4 mr-1" /> Add contract
            </Button>
          </div>
        </div>
        {openContractsSection && (
          <CardContent className="p-0">
            {myContracts.length > 0 && myContracts.length < MIN_BASIC_CONTRACTS && (
              <div className="border-t border-amber-200/90 bg-amber-50/90 px-4 py-2.5 text-2xs text-amber-950 sm:px-5">
                <span className="font-semibold">Tip:</span> Add at least {MIN_BASIC_CONTRACTS} basic contracts per talent (e.g. primary +
                secondary product line) for full sponsorship / vendor demos.
              </div>
            )}
            {myContracts.length === 0 ? (
              <p className="border-t border-primary/10 bg-slate-50/40 px-4 py-6 text-center text-sm text-neutral sm:px-5">
                No contracts yet. Add at least {MIN_BASIC_CONTRACTS} to define salary, product lines, and dates (recommended for
                sponsorship / vendor views).
              </p>
            ) : (
              <div className="divide-y divide-primary/10 bg-slate-50/40">
                {myContracts.map((c) => {
                  const open = expandedContractId === c.id
                  return (
                    <div
                      key={c.id}
                      className={cn(
                        'w-full transition-colors duration-200',
                        open ? 'bg-primary/[0.06]' : 'bg-white hover:bg-slate-50/80'
                      )}
                    >
                      <div
                        className={cn(
                          'flex min-w-0 flex-col border-l-[3px]',
                          open ? 'border-l-primary' : 'border-l-transparent hover:border-l-primary/40'
                        )}
                      >
                        <button
                          type="button"
                          className={cn(
                            'flex w-full min-w-0 items-center gap-3 px-4 py-3 text-left outline-none transition-colors sm:gap-4 sm:py-3.5',
                            'focus-visible:bg-primary/[0.06] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary/25'
                          )}
                          onClick={() => setExpandedContractId((id) => (id === c.id ? null : c.id))}
                          aria-expanded={open}
                          aria-label={`${open ? 'Collapse' : 'Expand'} contract ${c.contractID}`}
                        >
                          <div
                            className={cn(
                              'flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold shadow-inner sm:h-12 sm:w-12 sm:text-base',
                              open
                                ? 'bg-primary text-white ring-2 ring-primary/30'
                                : 'border border-primary/15 bg-primary/[0.08] text-primary-900'
                            )}
                            aria-hidden
                          >
                            {contractInitials(c)}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-bold text-primary-900">{c.contractID}</p>
                            <p className="mt-0.5 truncate text-2xs text-slate-600 sm:text-xs">
                              {c.productType || 'Product / type —'} · {formatDisplayDate(c.startDate)} –{' '}
                              {formatDisplayDate(c.endDate)}
                            </p>
                          </div>
                          <RosterRowChevron open={open} />
                        </button>
                        {open && (
                          <div className="space-y-3 border-t border-primary/15 bg-white px-4 pb-4 pt-3 text-sm sm:px-5">
                            <p className="text-2xs font-semibold uppercase tracking-wide text-primary/70">Contract summary</p>
                            <p className="text-sm leading-relaxed text-slate-700">{c.contractSummary || '—'}</p>
                            <dl className="grid grid-cols-1 gap-x-4 gap-y-2 rounded-lg border border-slate-200/90 bg-slate-50/50 p-3 sm:grid-cols-2">
                              {[
                                ['Contract signing date', c.contractSigningDate || '—'],
                                ['Contract start date', formatDisplayDate(c.startDate)],
                                ['Contract end date', formatDisplayDate(c.endDate)],
                                ['Product / type', c.productType || '—'],
                                [
                                  'Revenue share %',
                                  c.royaltyPercent != null ? `${(Number(c.royaltyPercent) * 100).toFixed(2)}%` : '—',
                                ],
                                ['Status', c.status],
                                ['Licensee', c.licensee || '—'],
                                ['Salary 2026-27', formatINRDisplay(c.basicSalary2026_27 ?? c.annualSalary)],
                                ['Perf. bonus (contract)', formatINRDisplay(c.signingBonus)],
                              ].map(([label, value]) => (
                                <div key={label} className="flex flex-col gap-0.5 border-b border-slate-200/60 pb-2 last:border-0 sm:border-0 sm:pb-0">
                                  <dt className="text-2xs font-bold uppercase tracking-wide text-slate-500">{label}</dt>
                                  <dd className="text-sm font-medium text-primary-900">{value}</dd>
                                </div>
                              ))}
                            </dl>
                            <div className="flex flex-wrap gap-2">
                              <Button size="sm" className="btn-view-pdf" variant="outline" onClick={() => setViewPdfContract(c)}>
                                View Contract in PDF
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => downloadContractCsv(c)}>
                                <FileSpreadsheet className="h-4 w-4 mr-1" /> View Contract in CSV
                              </Button>
                              <Button size="sm" className="btn-view-pdf" variant="outline" onClick={() => setViewDetailsContract(c)}>
                                <FileSpreadsheet className="h-4 w-4 mr-1" /> View detailed
                              </Button>
                              <Button type="button" variant="accent" size="sm" onClick={() => openEditContract(c)}>
                                <Pencil className="h-4 w-4 mr-1" /> Edit
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-red-200 text-red-600 hover:bg-red-50"
                                onClick={() => handleRemoveContract(c.id)}
                              >
                                <Trash2 className="h-4 w-4 mr-1" /> Delete
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        )}
      </Card>

      {/* Revenue share agreements — feed the calculation engine alongside primary contracts */}
      <Card className="overflow-hidden border-2 border-slate-200/90 bg-white shadow-md shadow-slate-200/40">
        <div className="flex w-full flex-col border-b border-slate-200/95 sm:flex-row sm:items-stretch">
          <button
            type="button"
            className="flex min-w-0 flex-1 items-center gap-3 border-b border-accent/20 bg-accent/[0.06] px-4 py-3.5 text-left shadow-sm transition-colors hover:bg-accent/[0.09] sm:gap-4 sm:border-b-0 sm:border-r sm:border-accent/20 sm:px-5"
            aria-expanded={openRsContractsSection}
            onClick={() => setOpenRsContractsSection((v) => !v)}
          >
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-accent/25 bg-white text-accent-700 shadow-sm ring-1 ring-accent/15 sm:h-12 sm:w-12">
              <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm font-bold tracking-tight text-primary-900">Revenue share contracts</p>
                <span className="rounded-md bg-accent/15 px-2 py-0.5 text-2xs font-semibold tabular-nums text-accent-900 ring-1 ring-accent/20">
                  {myRevenueShareContracts.length} {myRevenueShareContracts.length === 1 ? 'agreement' : 'agreements'}
                </span>
              </div>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600">
                Product-level % used with vendor sales to allocate club revenue to this talent.{' '}
                <Link
                  to="/sponsorship/talents/contracts"
                  state={{ focusTalentId: talentId }}
                  className="font-semibold text-primary underline-offset-2 hover:underline"
                >
                  Open in Contracts hub
                </Link>
              </p>
            </div>
            <RosterSectionChevron open={openRsContractsSection} />
          </button>
          <div className="flex shrink-0 items-center justify-center border-t border-accent/15 bg-accent/[0.05] px-4 py-2.5 sm:border-t-0 sm:border-l sm:border-accent/15 sm:px-4">
            <Button type="button" variant="accent" size="sm" onClick={openAddRsContract}>
              <Plus className="h-4 w-4 mr-1" /> Add agreement
            </Button>
          </div>
        </div>
        {openRsContractsSection && (
          <CardContent className="p-0">
            {myRevenueShareContracts.length === 0 ? (
              <p className="border-t border-accent/10 bg-slate-50/40 px-4 py-6 text-center text-sm text-neutral sm:px-5">
                No revenue share agreements yet. Add one to document the % used in calculations.
              </p>
            ) : (
              <div className="divide-y divide-accent/10 bg-slate-50/40">
                {myRevenueShareContracts.map((rsc) => {
                  const open = expandedRsContractId === rsc.id
                  return (
                    <div
                      key={rsc.id}
                      className={cn(
                        'w-full transition-colors duration-200',
                        open ? 'bg-accent/[0.07]' : 'bg-white hover:bg-slate-50/80'
                      )}
                    >
                      <div
                        className={cn(
                          'flex min-w-0 flex-col border-l-[3px]',
                          open ? 'border-l-accent' : 'border-l-transparent hover:border-l-accent/50'
                        )}
                      >
                        <button
                          type="button"
                          className="flex w-full min-w-0 items-center gap-3 px-4 py-3 text-left outline-none transition-colors sm:gap-4 sm:py-3.5"
                          onClick={() => setExpandedRsContractId((id) => (id === rsc.id ? null : rsc.id))}
                          aria-expanded={open}
                        >
                          <div
                            className={cn(
                              'flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold shadow-inner sm:h-12 sm:w-12 sm:text-base',
                              open
                                ? 'bg-accent text-white ring-2 ring-accent/30'
                                : 'border border-accent/20 bg-accent/[0.08] text-accent-900'
                            )}
                            aria-hidden
                          >
                            RS
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-bold text-primary-900">{rsc.title}</p>
                            <p className="mt-0.5 truncate text-2xs text-slate-600 sm:text-xs">
                              {rsc.productType || 'Product'} ·{' '}
                              {rsc.revenueSharePercent != null
                                ? `${(Number(rsc.revenueSharePercent) * 100).toFixed(2)}%`
                                : '—'}{' '}
                              · {formatDisplayDate(rsc.startDate)} – {formatDisplayDate(rsc.endDate)}
                            </p>
                          </div>
                          <RosterRowChevron open={open} />
                        </button>
                        {open && (
                          <div className="space-y-3 border-t border-accent/15 bg-white px-4 pb-4 pt-3 text-sm sm:px-5">
                            <p className="text-2xs font-semibold uppercase text-accent-800">Summary</p>
                            <p className="text-sm text-slate-700">{rsc.summary || '—'}</p>
                            <dl className="grid grid-cols-1 gap-2 rounded-lg border border-slate-200/90 bg-slate-50/50 p-3 sm:grid-cols-2">
                              {[
                                ['Signing date', rsc.signingDate || '—'],
                                ['Start date', formatDisplayDate(rsc.startDate)],
                                ['End date', formatDisplayDate(rsc.endDate)],
                                ['Linked contract id', rsc.linkedContractId || '—'],
                                ['Status', rsc.status || '—'],
                              ].map(([label, value]) => (
                                <div key={label}>
                                  <dt className="text-2xs font-bold uppercase text-slate-500">{label}</dt>
                                  <dd className="text-sm font-medium text-primary-900">{value}</dd>
                                </div>
                              ))}
                            </dl>
                            <div className="flex flex-wrap gap-2">
                              <Button type="button" variant="accent" size="sm" onClick={() => openEditRsContract(rsc)}>
                                <Pencil className="h-4 w-4 mr-1" /> Edit
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-red-200 text-red-600 hover:bg-red-50"
                                onClick={() => handleRemoveRsContract(rsc.id)}
                              >
                                <Trash2 className="h-4 w-4 mr-1" /> Delete
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        )}
      </Card>


      {/* Payment distribution — same pattern as club dashboard; scoped to this talent */}
      <Card className="overflow-hidden border-2 border-slate-200/90 bg-white shadow-md shadow-slate-200/40">
        <button
          type="button"
          className="flex w-full items-center gap-3 border-b border-primary/12 bg-primary/[0.05] px-4 py-3.5 text-left shadow-sm transition-colors hover:bg-primary/[0.08] sm:gap-4 sm:px-5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
          onClick={() => setOpenPaymentDistributionSection((v) => !v)}
          aria-expanded={openPaymentDistributionSection}
          aria-label={
            openPaymentDistributionSection
              ? `Collapse payment distribution for ${talent.name}`
              : `Expand payment distribution for ${talent.name}`
          }
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10 sm:h-12 sm:w-12">
            <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6" aria-hidden />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm font-bold tracking-tight text-primary-900">Payment summary & distribution</p>
              <span
                className="max-w-[min(100%,14rem)] truncate rounded-md bg-primary/12 px-2 py-0.5 text-2xs font-semibold text-primary-900 ring-1 ring-primary/15"
                title={talent.name}
              >
                {talent.name}
              </span>
              <Badge
                variant="secondary"
                className="border border-primary/20 bg-white font-mono text-2xs font-semibold text-primary-800"
              >
                ID {getTalentEmployeeIdDisplay(talent)}
              </Badge>
            </div>
            <p className="mt-1 text-2xs leading-relaxed text-slate-600">
              Salary, bonus, revenue share, and miscellaneous for the reporting year — same engine as Payment summary. Each card includes
              a payable / paid / outstanding mix chart; use View more for the full tab with this roster member pre-selected.
            </p>
          </div>
          <RosterSectionChevron open={openPaymentDistributionSection} />
        </button>
        {openPaymentDistributionSection && (
          <CardContent className="space-y-4 border-t border-primary/10 bg-slate-50/30 p-4 sm:p-5">
            <div className="flex flex-col gap-3 rounded-lg border border-primary/12 bg-white px-3 py-3 shadow-sm sm:flex-row sm:items-center sm:justify-between sm:px-4">
              <div>
                <p className="text-sm font-semibold text-primary-900">Reporting year</p>
                <p className="mt-0.5 text-2xs text-slate-600">Applies to all cards in this section</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="text-2xs font-semibold uppercase tracking-wide text-primary/70">Year</span>
                <Select value={paymentYear} onValueChange={setPaymentYear}>
                  <SelectTrigger className="h-9 w-[120px] border-primary/25 bg-white font-mono text-sm font-semibold text-primary">
                    <SelectValue placeholder="Year" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentYearOptions.map((y) => (
                      <SelectItem key={y} value={y}>
                        {y}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
              <PaymentTypeDashboardCard
                interactive={false}
                isSelected={false}
                onSelect={() => {}}
                title="Salary"
                icon={DollarSign}
                payableRowLabel="Total payable salary"
                paidRowLabel="Total paid salary"
                outstandingRowLabel="Total outstanding salary"
                payable={yearPayment.salary.payable}
                paid={yearPayment.salary.paid}
                outstanding={yearPayment.salary.outstanding}
                subtitle="Payable, paid, and outstanding mix · reporting year."
                onViewMore={() => openPaymentSummaryTab('salary', paymentYear)}
              >
                <PaymentBucketsPieChart
                  compact
                  payable={yearPayment.salary.payable}
                  paid={yearPayment.salary.paid}
                  outstanding={yearPayment.salary.outstanding}
                  payableLabel="Total payable salary"
                  paidLabel="Total paid salary"
                  outstandingLabel="Total outstanding salary"
                  title="Salary — mix"
                  description="Contract salary for this talent in the reporting year."
                />
              </PaymentTypeDashboardCard>
              <PaymentTypeDashboardCard
                interactive={false}
                isSelected={false}
                onSelect={() => {}}
                title="Bonus"
                icon={Gift}
                payableRowLabel="Total payable bonus"
                paidRowLabel="Total paid bonus"
                outstandingRowLabel="Total outstanding bonus"
                payable={yearPayment.bonus.payable}
                paid={yearPayment.bonus.paid}
                outstanding={yearPayment.bonus.outstanding}
                subtitle="Payable, paid, and outstanding mix · reporting year."
                onViewMore={() => openPaymentSummaryTab('bonus', paymentYear)}
              >
                <PaymentBucketsPieChart
                  compact
                  payable={yearPayment.bonus.payable}
                  paid={yearPayment.bonus.paid}
                  outstanding={yearPayment.bonus.outstanding}
                  payableLabel="Total payable bonus"
                  paidLabel="Total paid bonus"
                  outstandingLabel="Total outstanding bonus"
                  title="Bonus — mix"
                  description="Performance bonus for this talent in the reporting year."
                />
              </PaymentTypeDashboardCard>
              <PaymentTypeDashboardCard
                interactive={false}
                isSelected={false}
                onSelect={() => {}}
                title="Revenue share"
                icon={TrendingUp}
                payableRowLabel="Total payable revenue share"
                paidRowLabel="Total paid revenue share"
                outstandingRowLabel="Total outstanding revenue share"
                payable={yearPayment.royalty.payable}
                paid={yearPayment.royalty.paid}
                outstanding={yearPayment.royalty.outstanding}
                subtitle="Payable, paid, and outstanding mix · reporting year."
                onViewMore={() => openPaymentSummaryTab('revenue-share', paymentYear)}
              >
                <PaymentBucketsPieChart
                  compact
                  payable={yearPayment.royalty.payable}
                  paid={yearPayment.royalty.paid}
                  outstanding={yearPayment.royalty.outstanding}
                  payableLabel="Total payable revenue share"
                  paidLabel="Total paid revenue share"
                  outstandingLabel="Total outstanding revenue share"
                  title="Revenue share — mix"
                  description="Ledger position for this talent in the reporting year."
                />
              </PaymentTypeDashboardCard>
              <PaymentTypeDashboardCard
                interactive={false}
                isSelected={false}
                onSelect={() => {}}
                title="Miscellaneous"
                icon={Wallet}
                payableRowLabel="Total payable miscellaneous"
                paidRowLabel="Total paid miscellaneous"
                outstandingRowLabel="Total outstanding miscellaneous"
                payable={yearPaymentMisc.payable}
                paid={yearPaymentMisc.paid}
                outstanding={yearPaymentMisc.outstanding}
                subtitle="Payable, paid, and outstanding mix · reporting year."
                onViewMore={() => openPaymentSummaryTab('miscellaneous', paymentYear)}
              >
                <PaymentBucketsPieChart
                  compact
                  payable={yearPaymentMisc.payable}
                  paid={yearPaymentMisc.paid}
                  outstanding={yearPaymentMisc.outstanding}
                  payableLabel="Total payable miscellaneous"
                  paidLabel="Total paid miscellaneous"
                  outstandingLabel="Total outstanding miscellaneous"
                  title="Miscellaneous — mix"
                  description="Misc register rows in period months for this reporting year."
                />
              </PaymentTypeDashboardCard>
            </div>

            <p className="border-t border-primary/10 pt-3 text-right text-xs text-primary-700/70">
              Bonus rule of thumb: {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/mo ({PERFORMANCE_BONUS_PAYROLL_LABEL}) · revenue
              share for {(sportsBusinesses && sportsBusinesses[0]?.businessName) || 'this club'} · vendor uploads refresh the ledger.
            </p>

            <div className="flex flex-wrap justify-end gap-2 border-t border-primary/10 pt-4">
              <Button type="button" size="sm" className="h-8 gap-1 text-2xs" onClick={() => openPaymentSummaryTab('summary', paymentYear)}>
                <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                View more · Summary
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 gap-1 text-2xs"
                onClick={() => openPaymentSummaryTab('salary', paymentYear)}
              >
                <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                Salary
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 gap-1 text-2xs"
                onClick={() => openPaymentSummaryTab('bonus', paymentYear)}
              >
                <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                Bonus
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 gap-1 text-2xs"
                onClick={() => openPaymentSummaryTab('revenue-share', paymentYear)}
              >
                <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                Revenue share
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 gap-1 text-2xs"
                onClick={() => openPaymentSummaryTab('miscellaneous', paymentYear)}
              >
                <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                Misc
              </Button>
            </div>
          </CardContent>
        )}
      </Card>


      {/* Payment details (year-wise) + month-wise — roster-style header */}
      <Card className="overflow-hidden border-2 border-slate-200/90 bg-white shadow-md shadow-slate-200/40">
        <button
          type="button"
          className="flex w-full items-center gap-3 border-b border-primary/12 bg-primary/[0.05] px-4 py-3.5 text-left shadow-sm transition-colors hover:bg-primary/[0.08] sm:gap-4 sm:px-5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
          onClick={() => setOpenPaymentSection((v) => !v)}
          aria-expanded={openPaymentSection}
          aria-label={openPaymentSection ? 'Collapse payment details' : 'Expand payment details'}
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10 sm:h-12 sm:w-12">
            <CalendarRange className="h-5 w-5 sm:h-6 sm:w-6" aria-hidden />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold tracking-tight text-primary-900">Payment details</p>
            <p className="mt-1 text-2xs leading-relaxed text-slate-600">
              Year-wise totals and a single month-wise chart (salary, bonus, revenue share) · choose year when expanded
            </p>
          </div>
          <RosterSectionChevron open={openPaymentSection} />
        </button>
        {openPaymentSection && (
          <CardContent className="space-y-4 border-t border-primary/10 bg-slate-50/30 p-4 sm:p-5">
            <div className="flex flex-col gap-3 rounded-lg border border-primary/12 bg-white px-3 py-3 shadow-sm sm:flex-row sm:items-center sm:justify-between sm:px-4">
              <div>
                <p className="text-sm font-semibold text-primary-900">Reporting year</p>
                <p className="mt-0.5 text-2xs text-slate-600">
                  Applies to the year table and month-wise chart below
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="text-2xs font-semibold uppercase tracking-wide text-primary/70">Year</span>
                <Select value={paymentYear} onValueChange={setPaymentYear}>
                  <SelectTrigger className="h-9 w-[120px] border-primary/25 bg-white font-mono text-sm font-semibold text-primary">
                    <SelectValue placeholder="Year" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentYearOptions.map((y) => (
                      <SelectItem key={y} value={y}>
                        {y}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="overflow-x-auto rounded-lg border border-primary/10 bg-white shadow-sm">
              <table className="w-full min-w-[480px] text-sm">
                <thead>
                  <tr className="border-b border-primary/10 bg-primary/[0.04]">
                    <th className="py-2 px-3 text-left font-semibold">Category</th>
                    <th className="py-2 px-3 text-right font-semibold">Payable</th>
                    <th className="py-2 px-3 text-right font-semibold">Paid</th>
                    <th className="py-2 px-3 text-right font-semibold">Outstanding</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { label: 'Salary', ...yearPayment.salary },
                    { label: 'Performance bonus', ...yearPayment.bonus },
                    { label: 'Revenue share', ...yearPayment.royalty },
                    { label: 'Miscellaneous', ...yearPaymentMisc },
                  ].map((row) => (
                    <tr key={row.label} className="border-b border-gray-100">
                      <td className="py-2 px-3 font-medium">{row.label}</td>
                      <td className="py-2 px-3 text-right tabular-nums">{formatINRDisplay(row.payable)}</td>
                      <td className="py-2 px-3 text-right tabular-nums text-green-700">{formatINRDisplay(row.paid)}</td>
                      <td className="py-2 px-3 text-right tabular-nums text-amber-700">{formatINRDisplay(row.outstanding)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-primary/20 bg-primary/[0.06]">
                    <td className="py-2.5 px-3 font-bold text-primary-900">
                      Total <span className="font-normal text-slate-600">(salary + bonus + revenue share + misc)</span>
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-primary-900">
                      {formatINRDisplay(yearPaymentCombinedTotals.payable)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-green-800">
                      {formatINRDisplay(yearPaymentCombinedTotals.paid)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-amber-800">
                      {formatINRDisplay(yearPaymentCombinedTotals.outstanding)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div className="overflow-hidden rounded-xl border-2 border-slate-200/90 bg-white shadow-sm">
              <button
                type="button"
                className="flex w-full items-center gap-3 border-b border-primary/12 bg-primary/[0.05] px-3 py-3 text-left shadow-sm transition-colors hover:bg-primary/[0.08] sm:gap-4 sm:px-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
                onClick={() => setOpenMonthWiseSection((v) => !v)}
                aria-expanded={openMonthWiseSection}
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
                  <CalendarRange className="h-5 w-5" aria-hidden />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-primary-900">Month-wise</p>
                  <p className="mt-0.5 text-2xs text-slate-600">
                    One chart — salary, performance bonus, and revenue share (payable) by month for{' '}
                    <span className="font-mono font-semibold text-primary-800">{paymentYear}</span>
                  </p>
                </div>
                <RosterSectionChevron open={openMonthWiseSection} />
              </button>
              {openMonthWiseSection && (
                <div className="border-t border-primary/10 px-3 pb-4 pt-3 sm:px-4">
                  {monthWiseGroupedChartData.length === 0 ? (
                    <p className="rounded-lg border border-dashed border-primary/20 bg-white py-6 text-center text-sm text-neutral">
                      No payroll months for {paymentYear}. Select another year above.
                    </p>
                  ) : (
                    <GroupedMonthlyPaymentChart
                      data={monthWiseGroupedChartData}
                      year={paymentYear}
                      title={`Month-wise payable — ${paymentYear}`}
                      description={`Salary (navy), performance bonus (orange), revenue share (sky) — same scale as bar height; hover or bar labels for exact payable · ${talent?.name || 'Talent'} · ID ${getTalentEmployeeIdDisplay(talent)}. Bonus ${formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/mo (${PERFORMANCE_BONUS_PAYROLL_LABEL}); revenue share from ledger / invoices.`}
                      talentLabel={talent?.name || ''}
                      chartContentClassName="h-[340px] sm:h-[360px]"
                    />
                  )}
                </div>
              )}
            </div>

            <div className="rounded-lg border border-primary/12 bg-white px-3 py-3 shadow-sm sm:px-4">
              <p className="text-2xs font-bold uppercase tracking-wide text-primary-900">Organization payment summary</p>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600">
                Same rules as the club payment summary · jump to a tab with your reporting year
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  type="button"
                  size="sm"
                  className="h-8 gap-1 text-2xs"
                  onClick={() => openPaymentSummaryTab('summary', paymentYear)}
                >
                  <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                  View more · Summary
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-8 text-2xs"
                  onClick={() => openPaymentSummaryTab('salary', paymentYear)}
                >
                  Salary
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-8 text-2xs"
                  onClick={() => openPaymentSummaryTab('bonus', paymentYear)}
                >
                  Bonus
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-8 text-2xs"
                  onClick={() => openPaymentSummaryTab('revenue-share', paymentYear)}
                >
                  Revenue share
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-8 text-2xs"
                  onClick={() => openPaymentSummaryTab('miscellaneous', paymentYear)}
                >
                  Misc
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      

      {/* Create / Edit contract dialog */}
      <Dialog open={contractDialogOpen} onOpenChange={(v) => !v && resetContractForm()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingContract ? 'Edit Contract' : 'Add Contract'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleContractSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Contract ID</Label>
              <Input value={contractForm.contractID} onChange={(e) => setContractForm((f) => ({ ...f, contractID: e.target.value }))} placeholder="CNT-2024-001" />
            </div>
            <div className="space-y-2">
              <Label>Talent</Label>
              <Select value={contractForm.talentId} onValueChange={(v) => setContractForm((f) => ({ ...f, talentId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select talent" /></SelectTrigger>
                <SelectContent>
                  {(talents || []).map((t) => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sports Business (Club)</Label>
              <Select value={contractForm.licenseeId} onValueChange={(v) => setContractForm((f) => ({ ...f, licenseeId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select club" /></SelectTrigger>
                <SelectContent>
                  {(sportsBusinesses || []).map((b) => (<SelectItem key={b.id} value={b.id}>{b.businessName}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sport partner</Label>
              <Select value={contractForm.sponsorId} onValueChange={(v) => setContractForm((f) => ({ ...f, sponsorId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select sport partner" /></SelectTrigger>
                <SelectContent>
                  {(sponsorshipCompanies || []).map((c) => (<SelectItem key={c.id} value={c.id}>{c.companyName}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Product / type</Label>
              <Input value={contractForm.productType} onChange={(e) => setContractForm((f) => ({ ...f, productType: e.target.value }))} placeholder="e.g. Jersey endorsement, Equipment" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Basic Salary 2026-27 ($)</Label>
                <Input type="number" value={contractForm.basicSalary2026_27} onChange={(e) => setContractForm((f) => ({ ...f, basicSalary2026_27: e.target.value }))} placeholder="e.g. 18000000" />
              </div>
              <div className="space-y-2">
                <Label>Basic Salary 2027-28 ($)</Label>
                <Input type="number" value={contractForm.basicSalary2027_28} onChange={(e) => setContractForm((f) => ({ ...f, basicSalary2027_28: e.target.value }))} placeholder="e.g. 20000000" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Performance Bonus ($)</Label>
              <Input type="number" value={contractForm.signingBonus} onChange={(e) => setContractForm((f) => ({ ...f, signingBonus: e.target.value }))} placeholder="e.g. 2160000 (12 × $180k/mo pool)" />
            </div>
            <div className="space-y-2">
              <Label>Revenue share %</Label>
              <Input type="number" step="0.01" value={contractForm.royaltyPercent} onChange={(e) => setContractForm((f) => ({ ...f, royaltyPercent: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Input type="date" value={contractForm.startDate} onChange={(e) => setContractForm((f) => ({ ...f, startDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>End Date</Label>
                <Input type="date" value={contractForm.endDate} onChange={(e) => setContractForm((f) => ({ ...f, endDate: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Contract summary</Label>
              <Input
                value={contractForm.contractSummary}
                onChange={(e) => setContractForm((f) => ({ ...f, contractSummary: e.target.value }))}
                placeholder="Short description of rights and commercial scope"
              />
            </div>
            <div className="space-y-2">
              <Label>Contract signing date</Label>
              <Input
                type="date"
                value={contractForm.contractSigningDate}
                onChange={(e) => setContractForm((f) => ({ ...f, contractSigningDate: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={contractForm.status} onValueChange={(v) => setContractForm((f) => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" className="border-primary/25" onClick={resetContractForm}>
                Cancel
              </Button>
              <Button type="submit" variant="accent">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={rsContractDialogOpen} onOpenChange={(v) => !v && resetRsContractForm()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingRsContract ? 'Edit revenue share agreement' : 'Add revenue share agreement'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleRsContractSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input value={rsContractForm.title} onChange={(e) => setRsContractForm((f) => ({ ...f, title: e.target.value }))} placeholder="RS — Jersey program" />
            </div>
            <div className="space-y-2">
              <Label>Summary</Label>
              <Input
                value={rsContractForm.summary}
                onChange={(e) => setRsContractForm((f) => ({ ...f, summary: e.target.value }))}
                placeholder="How this % applies to vendor sales"
              />
            </div>
            <div className="space-y-2">
              <Label>Product / type</Label>
              <Input value={rsContractForm.productType} onChange={(e) => setRsContractForm((f) => ({ ...f, productType: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Revenue share %</Label>
              <Input
                type="number"
                step="0.01"
                value={rsContractForm.revenueSharePercent}
                onChange={(e) => setRsContractForm((f) => ({ ...f, revenueSharePercent: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Signing date</Label>
                <Input type="date" value={rsContractForm.signingDate} onChange={(e) => setRsContractForm((f) => ({ ...f, signingDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>Linked contract (internal id)</Label>
                <Select
                  value={rsContractForm.linkedContractId || RS_LINK_NONE}
                  onValueChange={(v) => setRsContractForm((f) => ({ ...f, linkedContractId: v }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Optional link" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={RS_LINK_NONE}>None</SelectItem>
                    {(myContracts || []).map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.contractID}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start date</Label>
                <Input type="date" value={rsContractForm.startDate} onChange={(e) => setRsContractForm((f) => ({ ...f, startDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>End date</Label>
                <Input type="date" value={rsContractForm.endDate} onChange={(e) => setRsContractForm((f) => ({ ...f, endDate: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={rsContractForm.status} onValueChange={(v) => setRsContractForm((f) => ({ ...f, status: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetRsContractForm}>
                Cancel
              </Button>
              <Button type="submit" variant="accent">
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ContractViewer open={!!viewContract} onOpenChange={(v) => !v && setViewContract(null)} contract={viewContract} onGeneratePDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)} />
      <ContractPDFViewer open={!!viewPdfContract} onOpenChange={(v) => !v && setViewPdfContract(null)} contract={viewPdfContract} onDownloadPDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)} />
      <ContractDetailsViewer open={!!viewDetailsContract} onOpenChange={(v) => !v && setViewDetailsContract(null)} contract={viewDetailsContract} />

      {/* Release payment for this talent */}
      <Card className="border-l-4 border-l-primary">
        <CardHeader>
          <CardTitle>Release Payment</CardTitle>
          <p className="text-sm text-neutral">
            Pay all pending compensation (salary + monthly performance bonus {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/mo, {PERFORMANCE_BONUS_PAYROLL_LABEL} + revenue share), performance bonus, and revenue share for this talent. One payment syncs to ledger with remark &quot;Single payment done&quot;.
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            {pendingSalaryList.length > 0 && (
              <p>Pending compensation (salary + monthly perf. bonus + revenue share): {pendingSalaryList.length} item(s) — {formatINRDisplay(pendingSalaryList.reduce((a, s) => a + (s.totalEarnings || 0), 0))}</p>
            )}
            {pendingBonusList.length > 0 && (
              <p>Pending performance bonus: {formatINRDisplay(pendingBonusList.reduce((a, b) => a + (Number(b.amount) || 0), 0))}</p>
            )}
            {pendingRoyaltyList.length > 0 && (
              <p>Pending revenue share: {formatINRDisplay(pendingRoyaltyList.reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0), 0))}</p>
            )}
          </div>
          <Button
            type="button"
            variant="accent"
            className="mt-4 font-semibold"
            disabled={totalPendingAmount <= 0}
            onClick={handleReleasePayment}
          >
            Pay now — {formatINRDisplay(totalPendingAmount)}
          </Button>
        </CardContent>
      </Card>

      {paymentModal && (
        <PaymentModal
          open
          onOpenChange={(v) => !v && setPaymentModal(null)}
          amount={paymentModal.amount}
          title={paymentModal.title}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}
