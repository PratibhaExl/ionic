-- Example warehouse / SAP staging table for exports from clubAccountingLogic.journalDocumentToSql()
-- Adjust types and constraints for your ERP.

CREATE TABLE IF NOT EXISTS journal_entry_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  document_number TEXT NOT NULL,
  document_type TEXT NOT NULL,
  line_no INTEGER NOT NULL,
  gl_account TEXT NOT NULL,
  account_name TEXT NOT NULL,
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  description TEXT,
  posted_at TEXT NOT NULL,
  UNIQUE (document_number, line_no)
);
