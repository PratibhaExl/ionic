# Sport Business / Club

Club-side screens live here. **File & component names** use a `Club*` prefix (e.g. `ClubDashboardPage`).

| File | Component | Route (prefix `/sponsorship`) |
|------|-----------|--------------------------------|
| `ClubDashboardPage.jsx` | `ClubDashboardPage` | `/dashboard` |
| `ClubTalentsListPage.jsx` | `ClubTalentsListPage` | `/talents` |
| `ClubTalentDetailPage.jsx` | `ClubTalentDetailPage` | `/talents/:talentId` |
| `ClubPaymentSummaryPage.jsx` | `ClubPaymentSummaryPage` | `/payments` |
| `ClubSalaryPage.jsx` | `ClubSalaryPage` | `/payments/salary` (also embedded under Payment summary) |
| `ClubReleasePaymentPage.jsx` | `ClubReleasePaymentPage` | `/payments/release-payment` |
| `ClubPaymentLedgerPage.jsx` | `ClubPaymentLedgerPage` | `/payments/ledger` |
| `ClubPerformanceBonusPage.jsx` | `ClubPerformanceBonusPage` | `/signing-bonus` |
| `ClubRoyaltiesPage.jsx` | `ClubRoyaltiesPage` | `/royalties` |
| `ClubAccountingPortalPage.jsx` | `ClubAccountingPortalPage` | `/journal-entry` (Journal entry — SAP-style + exports) |
| `accounting/clubAccountingLogic.js` | — | Pure COA + journal builders (CSV / JSON / SQL helpers) |
| `accounting/journal_entry_lines.example.sql` | — | Example DDL for SQL export integration |
| `ClubSportsBusinessesPage.jsx` | `ClubSportsBusinessesPage` | `/businesses` |
| `ClubSportPartnersPage.jsx` | `ClubSportPartnersPage` | `/companies` |

Legacy hub / overview / salary / flow pages were removed; `/payments/overview` and `/payments/salary` redirect to `/payments`.

Contracts and invoices for the club use shared modules: `contracts/ContractsPage`, `invoices/InvoicesPage`.
