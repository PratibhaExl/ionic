import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { getReportingSalesForOrganization, BATCH_APPROVAL_PENDING } from '../../utils/clubReportingSales'
import { useSportsBusinessFinanceViewModel } from '../../hooks/useSportsBusinessFinanceViewModel'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { StatCard } from '../../components/cards/StatCard'
import { PaymentTypeDashboardCard } from '../../components/cards/PaymentTypeDashboardCard'
import { PaymentBucketsPieChart } from '../../components/charts/PaymentBucketsPieChart'
import { Button } from '../../components/ui/button'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import {
  DollarSign,
  TrendingUp,
  Download,
  Gift,
  Users,
  FileText,
  Wallet,
  Building2,
  Store,
  CheckCircle2,
  Clock,
  Inbox,
} from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'
import { formatINRDisplay } from '../../utils/currencyFormat'

function paymentsDetailHref(tab) {
  const q = new URLSearchParams({ tab, from: 'dashboard' })
  return `/sponsorship/payments?${q.toString()}`
}

export function ClubDashboardPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const { metrics: dashboardMetrics } = useSportsBusinessFinanceViewModel()
  const { loading, loadMessage } = usePageLoadAuto('Calculating dashboard analytics...', 'Dashboard loaded')

  const sales = useMemo(
    () => getReportingSalesForOrganization(currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const salaryPayments = useMemo(
    () => getAllByOrganization('salaryPayments', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const signingBonuses = useMemo(
    () => getAllByOrganization('signingBonuses', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sponsorshipCompanies = useMemo(
    () => getAllByOrganization('sponsorshipCompanies', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const vendorImportBatches = useMemo(
    () => getAllByOrganization('vendorImportBatches', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const invoices = useMemo(
    () => getAllByOrganization('invoices', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const talentSummary = useMemo(() => {
    const allContracts = contracts || []
    const activeContracts = allContracts.filter((c) => String(c.status || '').toLowerCase() === 'active')
    const values = activeContracts.map((c) => Number(c.annualSalary) || 0)
    const totalContractValue = values.reduce((a, b) => a + b, 0)
    const avgContractValue = activeContracts.length ? totalContractValue / activeContracts.length : 0
    return {
      talentCount: (talents || []).length,
      totalContracts: allContracts.length,
      avgContractValue,
      totalContractValue,
    }
  }, [talents, contracts])

  const vendorSummary = useMemo(() => {
    const vendors = sponsorshipCompanies || []
    const batches = vendorImportBatches || []
    const inv = invoices || []
    const sponsorContracts = (contracts || []).filter((c) => c.sponsorId)
    const expectedFromVendors = vendors.reduce((a, v) => a + (Number(v.contractValue) || 0), 0)
    const totalPaidInvoices = inv.reduce((a, i) => a + (Number(i.paidAmount) || 0), 0)
    const totalPendingInvoices = inv.reduce((a, i) => {
      const due = Number(i.royaltyAmount) || 0
      const paid = Number(i.paidAmount) || 0
      return a + Math.max(0, due - paid)
    }, 0)
    const uploadsClosed = batches.filter((b) => (b.approvalStatus || 'approved') !== BATCH_APPROVAL_PENDING).length
    return {
      vendorCount: vendors.length,
      vendorLinkedContractCount: sponsorContracts.length,
      expectedFromVendors,
      totalPaidInvoices,
      totalPendingInvoices,
      uploadsClosed,
      uploadsTotal: batches.length,
    }
  }, [sponsorshipCompanies, vendorImportBatches, invoices, contracts])

  const salaryM = dashboardMetrics?.salary ?? { payable: 0, paid: 0, outstanding: 0 }
  const bonusM = dashboardMetrics?.bonus ?? { payable: 0, paid: 0, outstanding: 0 }
  const revM = dashboardMetrics?.revenueShare ?? { payable: 0, paid: 0, outstanding: 0 }
  const miscM = dashboardMetrics?.miscellaneous ?? { payable: 0, paid: 0, outstanding: 0 }

  const exportReport = () => {
    const salaryRows = (salaryPayments || []).map((s) => ({
      Type: 'Salary',
      Talent: s.talentName,
      Period: s.month,
      Amount: s.salaryAmount,
      Status: s.paymentStatus,
    }))
    const bonusRows = (signingBonuses || []).map((b) => ({
      Type: 'Performance Bonus',
      Talent: b.talentName,
      Amount: b.amount,
      SigningDate: b.signingDate,
      ReleaseDate: b.releaseDate,
      Status: b.status,
    }))
    const royaltyRows = ledger.map((r) => ({
      Type: 'Revenue share',
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      RevenueShareEarned: r.royaltyEarned,
      Date: r.date,
    }))
    const all = [...salaryRows, ...bonusRows, ...royaltyRows]
    const csv = Papa.unparse(all)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `report-salary-bonus-revenue-share-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="shrink-0 border-primary/25 text-primary hover:bg-primary/10 hover:border-primary/40 hover:text-primary-700"
          onClick={exportReport}
        >
          <Download className="mr-2 h-4 w-4" /> Export CSV
        </Button>
      </div>

      {/* Row 1: Talent summary | Vendor summary */}
      <div className="grid gap-8 lg:grid-cols-2">
        <section
          className="min-w-0 overflow-hidden rounded-lg border border-primary/12 bg-white shadow-sm transition-shadow duration-200 hover:border-primary/25 hover:shadow-lg"
          aria-labelledby="dashboard-talent-summary-heading"
        >
          <div className="border-b border-slate-200/90 bg-slate-50 px-4 py-3 sm:px-5">
            <h3
              id="dashboard-talent-summary-heading"
              className="text-sm font-bold uppercase tracking-wider text-primary-900"
            >
              Talent summary
            </h3>
            <p className="mt-1 text-2xs text-neutral">
              Roster and contract economics (active contracts for value averages).
            </p>
          </div>
          <div className="grid gap-3 p-4 sm:grid-cols-2 sm:p-5">
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
              title="Total talents"
              value={String(talentSummary.talentCount)}
              icon={Users}
              subtitle="On roster"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
              title="Total contracts"
              value={String(talentSummary.totalContracts)}
              icon={FileText}
              subtitle="All statuses"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
              title="Avg contract value"
              value={formatINRDisplay(talentSummary.avgContractValue)}
              icon={TrendingUp}
              subtitle="Active deals · annual salary"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
              title="Total contract value"
              value={formatINRDisplay(talentSummary.totalContractValue)}
              icon={DollarSign}
              subtitle="Sum of active annual salary"
            />
          </div>
        </section>

        <section
          className="min-w-0 overflow-hidden rounded-lg border border-primary/12 bg-white shadow-sm transition-shadow duration-200 hover:border-primary/25 hover:shadow-lg"
          aria-labelledby="dashboard-vendor-summary-heading"
        >
          <div className="border-b border-slate-200/90 bg-slate-50 px-4 py-3 sm:px-5">
            <h3
              id="dashboard-vendor-summary-heading"
              className="text-sm font-bold uppercase tracking-wider text-primary-900"
            >
              Sponsorship / Vendor summary
            </h3>
            <p className="mt-1 text-2xs text-neutral">
              Partner companies, linked agreements, expected sponsor contract values, invoice settlement, and vendor upload
              batches.
            </p>
          </div>
          <div className="grid gap-3 p-4 sm:grid-cols-2 sm:p-5">
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-amber-500/80 bg-gradient-to-r from-amber-50/80 to-white shadow-sm hover:border-amber-200/90 hover:border-l-amber-600 active:border-l-amber-700"
              title="Total vendors"
              value={String(vendorSummary.vendorCount)}
              icon={Store}
              subtitle="Sponsorship companies"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-amber-500/80 bg-gradient-to-r from-amber-50/80 to-white shadow-sm hover:border-amber-200/90 hover:border-l-amber-600 active:border-l-amber-700"
              title="Vendor-linked contracts"
              value={String(vendorSummary.vendorLinkedContractCount)}
              icon={FileText}
              subtitle="Contracts with sponsor"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-amber-500/80 bg-gradient-to-r from-amber-50/80 to-white shadow-sm hover:border-amber-200/90 hover:border-l-amber-600 active:border-l-amber-700"
              title="Total expected"
              value={formatINRDisplay(vendorSummary.expectedFromVendors)}
              icon={Building2}
              subtitle="Sum of sponsor contract values"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-amber-500/80 bg-gradient-to-r from-amber-50/80 to-white shadow-sm hover:border-amber-200/90 hover:border-l-amber-600 active:border-l-amber-700"
              title="Total paid"
              value={formatINRDisplay(vendorSummary.totalPaidInvoices)}
              icon={CheckCircle2}
              subtitle="Invoice paid amount (revenue share)"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-amber-500/80 bg-gradient-to-r from-amber-50/80 to-white shadow-sm hover:border-amber-200/90 hover:border-l-amber-600 active:border-l-amber-700"
              title="Total pending"
              value={formatINRDisplay(vendorSummary.totalPendingInvoices)}
              icon={Clock}
              subtitle="Invoice balance remaining"
            />
            <StatCard
              hoverable
              accentIcon
              className="border border-primary/12 border-l-4 border-l-amber-500/80 bg-gradient-to-r from-amber-50/80 to-white shadow-sm hover:border-amber-200/90 hover:border-l-amber-600 active:border-l-amber-700"
              title="Uploads settled"
              value={`${vendorSummary.uploadsClosed} / ${vendorSummary.uploadsTotal || 0}`}
              icon={Inbox}
              subtitle="Vendor files approved vs total batches"
            />
          </div>
        </section>
      </div>

      <section
        className="min-w-0 overflow-hidden rounded-lg border border-primary/12 bg-white shadow-sm transition-shadow duration-200 hover:border-primary/25 hover:shadow-lg"
        aria-labelledby="dashboard-payment-summary-heading"
      >
        <div className="border-b border-slate-200/90 bg-slate-50 px-4 py-3 sm:px-5">
          <h3
            id="dashboard-payment-summary-heading"
            className="text-sm font-bold uppercase tracking-wider text-primary-900"
          >
            Payment summary
          </h3>
          <p className="mt-1 text-2xs text-neutral">
            Salary, bonus, revenue share, and miscellaneous — payable, paid, outstanding, and status mix per card.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-3 p-4 sm:p-5 md:grid-cols-2 xl:grid-cols-4">
        <PaymentTypeDashboardCard
          interactive={false}
          isSelected={false}
          onSelect={() => {}}
          title="Salary"
          icon={DollarSign}
          payableRowLabel="Total payable salary"
          paidRowLabel="Total paid salary"
          outstandingRowLabel="Total outstanding salary"
          payable={salaryM.payable}
          paid={salaryM.paid}
          outstanding={salaryM.outstanding}
          subtitle="Payable, paid, and outstanding mix."
          onViewMore={() => navigate(paymentsDetailHref('salary'))}
        >
          <PaymentBucketsPieChart
            compact
            payable={salaryM.payable}
            paid={salaryM.paid}
            outstanding={salaryM.outstanding}
            payableLabel="Total payable salary"
            paidLabel="Total paid salary"
            outstandingLabel="Total outstanding salary"
            title="Salary — mix"
            description="Share of salary pool by status."
          />
        </PaymentTypeDashboardCard>
        <PaymentTypeDashboardCard
          interactive={false}
          isSelected={false}
          onSelect={() => {}}
          title="Bonus"
          icon={Gift}
          payableRowLabel="Total payable bonus"
          paidRowLabel="Total paid bonus"
          outstandingRowLabel="Total outstanding bonus"
          payable={bonusM.payable}
          paid={bonusM.paid}
          outstanding={bonusM.outstanding}
          subtitle="Payable, paid, and outstanding mix."
          onViewMore={() => navigate(paymentsDetailHref('bonus'))}
        >
          <PaymentBucketsPieChart
            compact
            payable={bonusM.payable}
            paid={bonusM.paid}
            outstanding={bonusM.outstanding}
            payableLabel="Total payable bonus"
            paidLabel="Total paid bonus"
            outstandingLabel="Total outstanding bonus"
            title="Bonus — mix"
            description="Performance bonus from payroll window."
          />
        </PaymentTypeDashboardCard>
        <PaymentTypeDashboardCard
          interactive={false}
          isSelected={false}
          onSelect={() => {}}
          title="Revenue share"
          icon={TrendingUp}
          payableRowLabel="Total payable revenue share"
          paidRowLabel="Total paid revenue share"
          outstandingRowLabel="Total outstanding revenue share"
          payable={revM.payable}
          paid={revM.paid}
          outstanding={revM.outstanding}
          subtitle="Payable, paid, and outstanding mix."
          onViewMore={() => navigate(paymentsDetailHref('revenue-share'))}
        >
          <PaymentBucketsPieChart
            compact
            payable={revM.payable}
            paid={revM.paid}
            outstanding={revM.outstanding}
            payableLabel="Total payable revenue share"
            paidLabel="Total paid revenue share"
            outstandingLabel="Total outstanding revenue share"
            title="Revenue share — mix"
            description="Ledger and invoice positions."
          />
        </PaymentTypeDashboardCard>
        <PaymentTypeDashboardCard
          interactive={false}
          isSelected={false}
          onSelect={() => {}}
          title="Miscellaneous"
          icon={Wallet}
          payableRowLabel="Total payable miscellaneous"
          paidRowLabel="Total paid miscellaneous"
          outstandingRowLabel="Total outstanding miscellaneous"
          payable={miscM.payable}
          paid={miscM.paid}
          outstanding={miscM.outstanding}
          subtitle="Payable, paid, and outstanding mix."
          onViewMore={() => navigate(paymentsDetailHref('miscellaneous'))}
        >
          <PaymentBucketsPieChart
            compact
            payable={miscM.payable}
            paid={miscM.paid}
            outstanding={miscM.outstanding}
            payableLabel="Total payable miscellaneous"
            paidLabel="Total paid miscellaneous"
            outstandingLabel="Total outstanding miscellaneous"
            title="Miscellaneous — mix"
            description="Other talent line items."
          />
        </PaymentTypeDashboardCard>
        </div>
      </section>
    </div>
  )
}
