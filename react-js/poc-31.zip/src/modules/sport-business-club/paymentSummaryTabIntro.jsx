import React from 'react'

export const PAYMENT_TAB_CHART_SHELL =
  'min-h-[300px] rounded-xl border border-primary/10 bg-gradient-to-br from-white via-white to-slate-100 p-2 shadow-inner'

const TAB_INTRO = {
  summary: {
    line1: 'Organization-wide payable, paid, and outstanding for the selected year—plus per-talent cards and a consolidated total.',
    line2: 'Salary, bonus, and revenue share follow calendar year; miscellaneous uses the full misc register.',
  },
  salary: {
    line1: 'Contract and payroll salary for the reporting year.',
    line2: 'Compare payable, paid, and outstanding below; salary by month uses base payroll amounts. The table lists full slip detail.',
  },
  bonus: {
    line1: 'Performance and signing bonus totals tied to payroll for the reporting year.',
    line2: 'Payable / paid / outstanding match the payment engine; the monthly chart follows signing-bonus booking months.',
  },
  'revenue-share': {
    line1: 'Revenue share from vendor sales × contract percentages—same ledger as talent and partner views.',
    line2: 'Totals align with invoices and ledger for the reporting year; the table lists period rows.',
  },
  miscellaneous: {
    line1: 'Fees, stipends, and other payments outside salary, bonus, and revenue-share ledgers.',
    line2: 'Amounts come from the miscellaneous register; filter by talent when you open this tab from the dashboard.',
  },
}

/** Summary strip for Payment summary detail tabs (rendered inside child pages). */
export function PaymentTabIntroStrip({ tabKey, year }) {
  const c = TAB_INTRO[tabKey]
  if (!c) return null
  const line1 =
    tabKey === 'salary'
      ? `Contract and payroll salary for ${year}.`
      : tabKey === 'bonus'
        ? `Performance and signing bonus tied to payroll for ${year}.`
        : c.line1
  return (
    <div className="mb-4 rounded-xl border border-primary/12 bg-gradient-to-r from-slate-100 via-white to-accent/[0.06] px-4 py-3 shadow-sm sm:px-5">
      <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-primary-800">Summary</p>
      <p className="mt-1.5 text-2xs font-medium leading-relaxed text-primary-950/95">{line1}</p>
      <p className="mt-1 text-2xs leading-relaxed text-primary-800/80">{c.line2}</p>
    </div>
  )
}
