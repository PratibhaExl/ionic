import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { v4 as uuidv4 } from 'uuid'
import Papa from 'papaparse'
import * as XLSX from 'xlsx'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatINRDisplay } from '../../utils/currencyFormat'
import {
  CHART_OF_ACCOUNTS,
  bumpDocSequence,
  buildExpenseRecognitionJournal,
  buildPaymentJournal,
  exportHistoryAsJson,
  journalDocumentToSql,
  journalLinesToCsvRows,
  parseMoney,
  playerRowTotal,
  validatePlayerRows,
} from './accounting/clubAccountingLogic'
import { Calculator, Download, FileSpreadsheet, Plus, Trash2, Users } from 'lucide-react'
import { cn } from '../../utils/cn'

const HISTORY_KEY = 'club-accounting-history-v1'

function downloadText(filename, content, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function normalizePlayersForJournal(rows) {
  return rows
    .map((r) => ({
      name: String(r.name || '').trim(),
      salary: round2(parseMoney(r.salary)),
      joiningBonus: round2(parseMoney(r.joiningBonus)),
      royalty: round2(parseMoney(r.royalty)),
    }))
    .filter((p) => p.name && p.salary + p.joiningBonus + p.royalty > 0)
}

function round2(n) {
  return Math.round(Number(n) * 100) / 100
}

function JournalLinesTable({ lines }) {
  if (!lines.length) {
    return <p className="text-sm text-neutral">No lines to display.</p>
  }
  return (
    <div className="overflow-x-auto rounded-lg border border-primary/10 bg-white shadow-sm">
      <table className="w-full min-w-[640px] text-sm">
        <thead>
          <tr className="border-b border-primary/10 bg-primary/[0.04]">
            <th className="py-2 px-3 text-left font-semibold">Line</th>
            <th className="py-2 px-3 text-left font-semibold">GL Account</th>
            <th className="py-2 px-3 text-left font-semibold">Account Name</th>
            <th className="py-2 px-3 text-right font-semibold">Debit</th>
            <th className="py-2 px-3 text-right font-semibold">Credit</th>
            <th className="py-2 px-3 text-left font-semibold">Description</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l) => (
            <tr key={l.line} className="border-b border-slate-100">
              <td className="py-2 px-3 tabular-nums">{l.line}</td>
              <td className="py-2 px-3 font-mono text-xs">{l.glAccount}</td>
              <td className="py-2 px-3">{l.accountName}</td>
              <td className="py-2 px-3 text-right tabular-nums">
                {l.debit > 0 ? formatINRDisplay(l.debit) : '—'}
              </td>
              <td className="py-2 px-3 text-right tabular-nums">
                {l.credit > 0 ? formatINRDisplay(l.credit) : '—'}
              </td>
              <td className="py-2 px-3 text-xs text-slate-600">{l.description}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function ClubAccountingPortalPage() {
  const { loading, loadMessage } = usePageLoadAuto('Loading journal entry…', 'Ready')
  const [players, setPlayers] = useState(() => [
    { id: uuidv4(), name: '', salary: '', joiningBonus: '', royalty: '' },
  ])
  const [paymentAmount, setPaymentAmount] = useState('')
  const [history, setHistory] = useState([])
  const [filterPlayer, setFilterPlayer] = useState('')
  const [filterDateFrom, setFilterDateFrom] = useState('')
  const [filterDateTo, setFilterDateTo] = useState('')
  const [filterKind, setFilterKind] = useState('all')

  useEffect(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (Array.isArray(parsed)) setHistory(parsed)
      }
    } catch {
      /* ignore */
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history))
    } catch {
      /* ignore */
    }
  }, [history])

  const validation = useMemo(() => validatePlayerRows(players), [players])
  const normalized = useMemo(() => normalizePlayersForJournal(players), [players])
  const expensePreview = useMemo(() => buildExpenseRecognitionJournal(normalized), [normalized])
  const payableTotal = expensePreview.totalDebit

  const paymentParsed = round2(parseMoney(paymentAmount))
  const paymentPreview = useMemo(() => {
    if (!Number.isFinite(paymentParsed) || paymentParsed <= 0) return { lines: [], balanced: true, error: null }
    const names = normalized.map((p) => p.name)
    return buildPaymentJournal(paymentParsed, names)
  }, [paymentParsed, normalized])

  const dashboard = useMemo(() => {
    let salary = 0
    let joiningBonus = 0
    let royalty = 0
    let n = 0
    for (const r of players) {
      const s = parseMoney(r.salary)
      const b = parseMoney(r.joiningBonus)
      const roy = parseMoney(r.royalty)
      if ([s, b, roy].some((x) => Number.isNaN(x))) continue
      if (playerRowTotal(r) <= 0 || !String(r.name || '').trim()) continue
      n += 1
      salary += s
      joiningBonus += b
      royalty += roy
    }
    return {
      count: n,
      salary: round2(salary),
      joiningBonus: round2(joiningBonus),
      royalty: round2(royalty),
      grand: round2(salary + joiningBonus + royalty),
    }
  }, [players])

  const filteredHistory = useMemo(() => {
    return history.filter((doc) => {
      if (filterKind !== 'all' && doc.kind !== filterKind) return false
      if (filterPlayer.trim()) {
        const q = filterPlayer.toLowerCase()
        if (!doc.playerNames.some((n) => n.toLowerCase().includes(q))) return false
      }
      const docDate = doc.postedAt.slice(0, 10)
      if (filterDateFrom && docDate < filterDateFrom) return false
      if (filterDateTo && docDate > filterDateTo) return false
      return true
    })
  }, [history, filterPlayer, filterDateFrom, filterDateTo, filterKind])

  const historyExpenseTotals = useMemo(() => {
    let salary = 0
    let bonus = 0
    let royalty = 0
    for (const doc of history) {
      if (doc.kind !== 'expense_recognition') continue
      for (const l of doc.lines) {
        if (l.glAccount === '61000') salary += l.debit
        if (l.glAccount === '61010') bonus += l.debit
        if (l.glAccount === '61020') royalty += l.debit
      }
    }
    return { salary: round2(salary), bonus: round2(bonus), royalty: round2(royalty) }
  }, [history])

  const addPlayerRow = useCallback(() => {
    setPlayers((p) => [...p, { id: uuidv4(), name: '', salary: '', joiningBonus: '', royalty: '' }])
  }, [])

  const removePlayerRow = useCallback((id) => {
    setPlayers((p) => (p.length <= 1 ? p : p.filter((row) => row.id !== id)))
  }, [])

  const updatePlayer = useCallback((id, field, value) => {
    setPlayers((p) => p.map((row) => (row.id === id ? { ...row, [field]: value } : row)))
  }, [])

  const fillPaymentFromPayable = useCallback(() => {
    if (payableTotal > 0) setPaymentAmount(String(payableTotal))
  }, [payableTotal])

  const postExpenseRecognition = useCallback(() => {
    if (!validation.ok) return
    const docNum = bumpDocSequence()
    const doc = {
      id: uuidv4(),
      kind: 'expense_recognition',
      documentNumber: docNum,
      postedAt: new Date().toISOString(),
      lines: expensePreview.lines,
      playerNames: normalized.map((p) => p.name),
    }
    setHistory((h) => [doc, ...h])
  }, [validation.ok, expensePreview.lines, normalized])

  const postPayment = useCallback(() => {
    if (!Number.isFinite(paymentParsed) || paymentParsed <= 0) return
    if (paymentPreview.error) return
    const docNum = bumpDocSequence()
    const doc = {
      id: uuidv4(),
      kind: 'payment',
      documentNumber: docNum,
      postedAt: new Date().toISOString(),
      lines: paymentPreview.lines,
      playerNames: normalized.map((p) => p.name),
      paymentAmount: paymentParsed,
    }
    setHistory((h) => [doc, ...h])
  }, [paymentParsed, paymentPreview.lines, paymentPreview.error, normalized])

  const exportCsv = useCallback(() => {
    const flat = []
    for (const doc of filteredHistory) {
      const base = { Document: doc.documentNumber, Kind: doc.kind, Posted: doc.postedAt }
      flat.push(...journalLinesToCsvRows(doc.lines, base))
    }
    if (flat.length === 0) {
      window.alert('No journal entry lines match the current filters.')
      return
    }
    const csv = Papa.unparse(flat)
    downloadText(`club-journal-entry-${Date.now()}.csv`, csv, 'text/csv;charset=utf-8')
  }, [filteredHistory])

  const exportJson = useCallback(() => {
    const body = exportHistoryAsJson(CHART_OF_ACCOUNTS, filteredHistory)
    downloadText(`club-journal-entry-export-${Date.now()}.json`, body, 'application/json;charset=utf-8')
  }, [filteredHistory])

  const exportSql = useCallback(() => {
    const parts = filteredHistory.map((doc) =>
      journalDocumentToSql({
        documentNumber: doc.documentNumber,
        kind: doc.kind,
        postedAt: doc.postedAt,
        lines: doc.lines,
      })
    )
    if (!parts.length) {
      window.alert('No journal entries match the current filters.')
      return
    }
    downloadText(`club-journal-entry-${Date.now()}.sql`, parts.join('\n\n'), 'text/plain;charset=utf-8')
  }, [filteredHistory])

  const exportExcel = useCallback(() => {
    const wb = XLSX.utils.book_new()
    const coaSheet = XLSX.utils.json_to_sheet(
      CHART_OF_ACCOUNTS.map((r) => ({
        'Payment component': r.paymentComponent,
        'GL account': r.glAccount,
        'Account name': r.accountName,
        Type: r.type,
      }))
    )
    XLSX.utils.book_append_sheet(wb, coaSheet, 'Chart of accounts')

    const lineRows = []
    for (const doc of filteredHistory) {
      for (const l of doc.lines) {
        lineRows.push({
          Document: doc.documentNumber,
          Kind: doc.kind,
          Posted: doc.postedAt,
          Line: l.line,
          'GL account': l.glAccount,
          'Account name': l.accountName,
          Debit: l.debit || '',
          Credit: l.credit || '',
          Description: l.description,
        })
      }
    }
    if (lineRows.length) {
      const linesSheet = XLSX.utils.json_to_sheet(lineRows)
      XLSX.utils.book_append_sheet(wb, linesSheet, 'Journal lines')
    }
    XLSX.writeFile(wb, `club-journal-entry-${Date.now()}.xlsx`)
  }, [filteredHistory])

  const clearHistory = useCallback(() => {
    if (window.confirm('Remove all posted journal entries from this browser?')) {
      setHistory([])
      localStorage.removeItem(HISTORY_KEY)
    }
  }, [])

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="theme-page-title flex items-center gap-2">
          <Calculator className="h-5 w-5" aria-hidden />
          Journal entry
        </h2>
        <p className="theme-section-summary mt-1 max-w-3xl">
          Player payment totals, SAP-style GL mapping, and journal entries for expense recognition and bank payment.
          Posted journal entries are stored in this browser for export to CSV, Excel, JSON, or SQL-style inserts.
        </p>
      </div>

      <div className="space-y-6">
          {/* Dashboard */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {[
              { label: 'Players (active rows)', value: String(dashboard.count), tone: 'text-primary-900' },
              { label: 'Salary (input)', value: formatINRDisplay(dashboard.salary), tone: 'text-primary-800' },
              { label: 'Joining bonus', value: formatINRDisplay(dashboard.joiningBonus), tone: 'text-primary-800' },
              { label: 'Revenue share', value: formatINRDisplay(dashboard.royalty), tone: 'text-primary-800' },
              { label: 'Total payment', value: formatINRDisplay(dashboard.grand), tone: 'font-semibold text-primary' },
            ].map((c) => (
              <Card key={c.label} className="border border-primary/12 bg-primary/[0.03] shadow-sm">
                <CardContent className="p-3">
                  <p className="text-2xs font-medium uppercase tracking-wide text-slate-500">{c.label}</p>
                  <p className={cn('mt-1 text-sm tabular-nums', c.tone)}>{c.value}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <Card className="border-slate-200/90 sm:col-span-1">
              <CardContent className="p-3">
                <p className="text-2xs font-semibold uppercase text-slate-500">Posted expense (history)</p>
                <p className="mt-1 text-xs text-slate-600">
                  Salary {formatINRDisplay(historyExpenseTotals.salary)} · Bonus{' '}
                  {formatINRDisplay(historyExpenseTotals.bonus)} · Revenue share{' '}
                  {formatINRDisplay(historyExpenseTotals.royalty)}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Player grid */}
          <Card className="overflow-hidden border border-slate-200/90 shadow-sm">
            <CardHeader className="border-b border-primary/12 bg-primary/[0.05] py-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-base text-primary-900">
                    <Users className="h-5 w-5 text-primary" />
                    Player payment calculation
                  </CardTitle>
                  <p className="mt-1 text-xs text-slate-600">
                    Total payment = Salary + Joining bonus + Revenue share. Amounts must be zero or positive.
                  </p>
                </div>
                <Button type="button" size="sm" variant="outline" className="border-primary/25" onClick={addPlayerRow}>
                  <Plus className="mr-1 h-4 w-4" />
                  Add player
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px] text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/80">
                      <th className="py-2 px-3 text-left font-semibold">Player name</th>
                      <th className="py-2 px-3 text-right font-semibold">Salary</th>
                      <th className="py-2 px-3 text-right font-semibold">Joining bonus</th>
                      <th className="py-2 px-3 text-right font-semibold">Revenue share</th>
                      <th className="py-2 px-3 text-right font-semibold">Total</th>
                      <th className="w-12 py-2 px-2" />
                    </tr>
                  </thead>
                  <tbody>
                    {players.map((row) => (
                      <tr key={row.id} className="border-b border-slate-100">
                        <td className="p-2">
                          <Input
                            value={row.name}
                            onChange={(e) => updatePlayer(row.id, 'name', e.target.value)}
                            placeholder="Player name"
                            className="h-8 text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <Input
                            inputMode="decimal"
                            value={row.salary}
                            onChange={(e) => updatePlayer(row.id, 'salary', e.target.value)}
                            placeholder="0"
                            className="h-8 text-right font-mono text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <Input
                            inputMode="decimal"
                            value={row.joiningBonus}
                            onChange={(e) => updatePlayer(row.id, 'joiningBonus', e.target.value)}
                            placeholder="0"
                            className="h-8 text-right font-mono text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <Input
                            inputMode="decimal"
                            value={row.royalty}
                            onChange={(e) => updatePlayer(row.id, 'royalty', e.target.value)}
                            placeholder="0"
                            className="h-8 text-right font-mono text-xs"
                          />
                        </td>
                        <td className="p-2 text-right font-mono text-xs font-semibold text-primary-900 tabular-nums">
                          {formatINRDisplay(playerRowTotal(row))}
                        </td>
                        <td className="p-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-slate-400 hover:text-red-600"
                            onClick={() => removePlayerRow(row.id)}
                            aria-label="Remove row"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!validation.ok && (
                <div className="border-t border-amber-200/80 bg-amber-50/80 px-3 py-2">
                  <ul className="list-inside list-disc text-xs text-amber-900">
                    {validation.errors.map((e) => (
                      <li key={e}>{e}</li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>

          {/* COA */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-primary-900">Chart of accounts (SAP-style mapping)</CardTitle>
              <p className="text-xs text-neutral">Posting keys for player costs, liability, and bank.</p>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-lg border border-primary/10">
                <table className="w-full min-w-[560px] text-sm">
                  <thead>
                    <tr className="bg-primary/[0.06]">
                      <th className="py-2 px-3 text-left font-semibold">Payment component</th>
                      <th className="py-2 px-3 text-left font-semibold">GL account</th>
                      <th className="py-2 px-3 text-left font-semibold">Account name</th>
                      <th className="py-2 px-3 text-left font-semibold">Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    {CHART_OF_ACCOUNTS.map((r) => (
                      <tr key={r.glAccount + r.paymentComponent} className="border-t border-slate-100">
                        <td className="py-2 px-3">{r.paymentComponent}</td>
                        <td className="py-2 px-3 font-mono text-xs">{r.glAccount}</td>
                        <td className="py-2 px-3">{r.accountName}</td>
                        <td className="py-2 px-3">{r.type}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Expense recognition */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-primary-900">Journal entry — expense recognition</CardTitle>
              <p className="text-xs text-neutral">
                Debit salary / bonus / revenue share expense (61000 / 61010 / 61020); credit Player Payable (210000). Each expense
                line uses: &quot;Expense recognition for &lt;Player Name&gt;&quot;.
              </p>
            </CardHeader>
            <CardContent className="space-y-3">
              <JournalLinesTable lines={expensePreview.lines} />
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" size="sm" onClick={postExpenseRecognition} disabled={!validation.ok || !expensePreview.lines.length}>
                  Post journal entry — expense recognition
                </Button>
                <span className="text-2xs text-neutral">
                  Document no. assigned on post (JE-YYYYMMDD-#####). Balanced: debit {formatINRDisplay(expensePreview.totalDebit)} =
                  credit {formatINRDisplay(expensePreview.totalCredit)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Payment */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-primary-900">Journal entry — payment to player</CardTitle>
              <p className="text-xs text-neutral">
                Debit Player Payable (210000); credit Bank (110000). Description references players in the grid.
              </p>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex max-w-md flex-col gap-2">
                <Label htmlFor="pay-amt">Payment amount</Label>
                <div className="flex flex-wrap gap-2">
                  <Input
                    id="pay-amt"
                    inputMode="decimal"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    placeholder={payableTotal > 0 ? String(payableTotal) : '0'}
                    className="h-9 max-w-[200px] font-mono text-xs"
                  />
                  <Button type="button" variant="outline" size="sm" className="border-primary/25" onClick={fillPaymentFromPayable}>
                    Use payable total
                  </Button>
                </div>
                {paymentPreview.error ? (
                  <p className="text-xs text-red-600">{paymentPreview.error}</p>
                ) : null}
              </div>
              <JournalLinesTable lines={paymentPreview.lines} />
              <Button
                type="button"
                size="sm"
                onClick={postPayment}
                disabled={!paymentPreview.lines.length || !!paymentPreview.error}
              >
                Post payment journal entry
              </Button>
            </CardContent>
          </Card>

          {/* History */}
          <Card>
            <CardHeader>
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-base text-primary-900">
                    <FileSpreadsheet className="h-5 w-5" />
                    Posted journal entries &amp; export
                  </CardTitle>
                  <p className="text-xs text-neutral">
                    Filter by player name, date, or entry kind. Export journal entries for SAP upload or warehouse loads.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button type="button" variant="outline" size="sm" className="border-primary/25" onClick={exportCsv}>
                    <Download className="mr-1 h-4 w-4" />
                    CSV
                  </Button>
                  <Button type="button" variant="outline" size="sm" className="border-primary/25" onClick={exportExcel}>
                    Excel
                  </Button>
                  <Button type="button" variant="outline" size="sm" className="border-primary/25" onClick={exportJson}>
                    JSON
                  </Button>
                  <Button type="button" variant="outline" size="sm" className="border-primary/25" onClick={exportSql}>
                    SQL
                  </Button>
                  <Button type="button" variant="ghost" size="sm" className="text-red-700 hover:bg-red-50" onClick={clearHistory}>
                    Clear history
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-3">
                <div className="flex flex-col gap-1">
                  <Label className="text-2xs">Player contains</Label>
                  <Input
                    value={filterPlayer}
                    onChange={(e) => setFilterPlayer(e.target.value)}
                    placeholder="Name filter"
                    className="h-8 w-40 text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <Label className="text-2xs">From date</Label>
                  <Input
                    type="date"
                    value={filterDateFrom}
                    onChange={(e) => setFilterDateFrom(e.target.value)}
                    className="h-8 w-36 text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <Label className="text-2xs">To date</Label>
                  <Input
                    type="date"
                    value={filterDateTo}
                    onChange={(e) => setFilterDateTo(e.target.value)}
                    className="h-8 w-36 text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <Label className="text-2xs">Kind</Label>
                  <select
                    value={filterKind}
                    onChange={(e) => setFilterKind(e.target.value)}
                    className="h-8 w-44 rounded-md border border-gray-300 bg-white px-2 text-xs shadow-sm"
                  >
                    <option value="all">All</option>
                    <option value="expense_recognition">Expense recognition</option>
                    <option value="payment">Payment</option>
                  </select>
                </div>
              </div>

              {filteredHistory.length === 0 ? (
                <p className="text-sm text-neutral">No journal entries match filters. Post journal entries above to build history.</p>
              ) : (
                <div className="space-y-6">
                  {filteredHistory.map((doc) => (
                    <div key={doc.id} className="rounded-lg border border-slate-200/90 bg-slate-50/30 p-3">
                      <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2">
                        <div>
                          <span className="font-mono text-sm font-semibold text-primary-900">{doc.documentNumber}</span>
                          <span className="ml-2 text-2xs uppercase text-slate-500">{doc.kind.replace('_', ' ')}</span>
                        </div>
                        <span className="text-2xs text-neutral">{new Date(doc.postedAt).toLocaleString()}</span>
                      </div>
                      <JournalLinesTable lines={doc.lines} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Integration note */}
          <Card className="border-dashed border-primary/20 bg-primary/[0.02]">
            <CardContent className="py-4 text-xs text-slate-600">
              <p className="font-semibold text-primary-900">Backend integration</p>
              <p className="mt-1">
                Journal entry logic lives in{' '}
                <code className="rounded bg-slate-100 px-1">src/modules/sport-business-club/accounting/clubAccountingLogic.js</code>{' '}
                (pure functions). JSON export includes the chart of accounts plus posted journal entries. SQL export assumes a table{' '}
                <code className="rounded bg-slate-100 px-1">journal_entry_lines</code> with columns matching the insert template.
              </p>
            </CardContent>
          </Card>
      </div>
    </div>
  )
}
