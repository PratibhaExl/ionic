import React, { useState, useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { DataTable } from '../../components/tables/DataTable'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Checkbox } from '../../components/ui/checkbox'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Filter } from 'lucide-react'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT, PERFORMANCE_BONUS_PAYROLL_LABEL } from '../../utils/salaryCalculator'

const PAYMENT_TYPES = ['Salary', 'Signing Bonus', 'Royalty'] // stored type; 'Signing Bonus' displayed as Performance Bonus

export function ClubPaymentLedgerPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading payment ledger...', 'Payment ledger loaded')
  const ledger = useMemo(() => getAllByOrganization('paymentLedger', currentOrganizationId), [currentOrganizationId])
  const [selectedTalentIds, setSelectedTalentIds] = useState([])
  const [selectedPaymentTypes, setSelectedPaymentTypes] = useState([])

  const talentOptions = useMemo(() => {
    const names = new Map()
    ;(ledger || []).forEach((row) => {
      if (row.talentId && row.talentName) names.set(row.talentId, row.talentName)
    })
    return Array.from(names.entries()).map(([id, name]) => ({ id, name }))
  }, [ledger])

  const filterByTalent = (talentId) => {
    setSelectedTalentIds((prev) =>
      prev.includes(talentId) ? prev.filter((id) => id !== talentId) : [...prev, talentId]
    )
  }

  const togglePaymentType = (type) => {
    setSelectedPaymentTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    )
  }

  const filteredLedger = useMemo(() => {
    let list = [...(ledger || [])]
    if (selectedTalentIds.length > 0) {
      list = list.filter((row) => selectedTalentIds.includes(row.talentId))
    }
    if (selectedPaymentTypes.length > 0) {
      list = list.filter((row) => selectedPaymentTypes.includes(row.paymentType))
    }
    return list.sort((a, b) => (b.date || '').localeCompare(a.date || ''))
  }, [ledger, selectedTalentIds, selectedPaymentTypes])

  const columns = [
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'transactionId', header: 'Transaction ID', accessorKey: 'transactionId' },
    { id: 'talentName', header: 'Talent Name', accessorKey: 'talentName' },
    {
      id: 'paymentType',
      header: 'Payment Type',
      accessorKey: 'paymentType',
      cell: (info) => {
        const v = info.getValue()
        if (v === 'Signing Bonus') return 'Performance Bonus'
        if (v === 'Royalty') return 'Revenue share'
        return String(v || '—')
      },
    },
    { id: 'amount', header: 'Amount ($)', accessorKey: 'amount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'paymentMethod', header: 'Payment Method', accessorKey: 'paymentMethod', cell: (info) => String(info.getValue() || '').toUpperCase() },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => (
      <span className="rounded-full px-2 py-0.5 text-xs font-medium bg-green-100 text-green-800">{info.getValue() || 'completed'}</span>
    )},
    { id: 'details', header: 'Details', accessorKey: 'details', cell: (info) => (
      <span className="text-xs text-neutral">{info.getValue() || '—'}</span>
    )},
  ]

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="flex gap-6">
      <aside className="w-72 shrink-0 rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral">Filters</span>
        </div>

        <p className="text-2xs text-neutral mb-2 mt-4">Filter by talent (none = all)</p>
        <div className="space-y-2 max-h-[40vh] overflow-y-auto">
          {talentOptions.map((t) => (
            <label key={t.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
              <Checkbox
                checked={selectedTalentIds.includes(t.id)}
                onCheckedChange={() => filterByTalent(t.id)}
              />
              <span className="text-xs truncate">{t.name}</span>
            </label>
          ))}
        </div>

        <p className="text-2xs text-neutral mb-2 mt-4">Filter by type (none = all)</p>
        <div className="space-y-2">
          {PAYMENT_TYPES.map((type) => (
            <label key={type} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
              <Checkbox
                checked={selectedPaymentTypes.includes(type)}
                onCheckedChange={() => togglePaymentType(type)}
              />
              <span className="text-xs">
                {type === 'Signing Bonus' ? 'Performance Bonus' : type === 'Royalty' ? 'Revenue share' : type}
              </span>
            </label>
          ))}
        </div>

        {(selectedTalentIds.length > 0 || selectedPaymentTypes.length > 0) && (
          <Button
            variant="ghost"
            size="sm"
            className="mt-3 text-xs"
            onClick={() => { setSelectedTalentIds([]); setSelectedPaymentTypes([]); }}
          >
            Clear filters
          </Button>
        )}
      </aside>

      <div className="flex-1 min-w-0 space-y-6">
        <h2 className="text-xl font-semibold">Payment Ledger</h2>
        <p className="text-sm text-neutral">
          Talent-wise financial history: Salary, Performance Bonus ({formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/mo, {PERFORMANCE_BONUS_PAYROLL_LABEL}), Revenue share. Use the left panel to filter by talent or payment type.
        </p>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <DataTable columns={columns} data={filteredLedger} searchKey="talentName" searchPlaceholder="Search by talent or transaction ID..." />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
