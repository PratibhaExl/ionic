import React from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { AuditLogViewer } from '../../components/AuditLogViewer'

export function AuditLogsPage() {
  const { currentOrganizationId } = useOrganization()
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Audit & compliance logs</h2>
      <AuditLogViewer organizationId={currentOrganizationId} limit={200} />
    </div>
  )
}
