import React from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { DataTable } from '../../components/tables/DataTable'
import { format } from 'date-fns'

export function OrganizationsPage() {
  const { data: organizations } = useDatabase('organizations')
  const columns = [
    { id: 'name', header: 'Organization', accessorKey: 'name' },
    { id: 'id', header: 'ID', accessorKey: 'id' },
    { id: 'createdAt', header: 'Created', accessorKey: 'createdAt', cell: (info) => info.getValue() ? format(new Date(info.getValue()), 'PP') : '—' },
  ]
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Organizations</h2>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Workspaces</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable columns={columns} data={organizations || []} searchKey="name" searchPlaceholder="Search organizations..." />
        </CardContent>
      </Card>
    </div>
  )
}
