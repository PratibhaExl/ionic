import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getReportingSalesForOrganization } from '../../utils/clubReportingSales'
import { forecastRevenue } from '../../utils/forecastEngine'
import { RevenueForecastChart } from '../../components/RevenueForecastChart'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { StatCard } from '../../components/cards/StatCard'
import { DollarSign, TrendingUp } from 'lucide-react'

export function ForecastPage() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getReportingSalesForOrganization(currentOrganizationId), [currentOrganizationId])

  const forecast3 = useMemo(() => forecastRevenue(sales, 3), [sales])
  const forecast12 = useMemo(() => forecastRevenue(sales, 12), [sales])
  const total3 = forecast3.reduce((a, b) => a + (b.forecast || 0), 0)
  const total12 = forecast12.reduce((a, b) => a + (b.forecast || 0), 0)

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Royalty forecasting</h2>
      <div className="grid gap-4 md:grid-cols-2">
        <StatCard title="Forecasted revenue (next 3 months)" value={`$${total3.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Forecasted revenue (next 12 months)" value={`$${total12.toLocaleString()}`} icon={TrendingUp} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <RevenueForecastChart data={forecast3} title="Next 3 months" description="Moving average + projection" />
        <RevenueForecastChart data={forecast12} title="Next 12 months" description="Revenue forecast" />
      </div>
    </div>
  )
}
