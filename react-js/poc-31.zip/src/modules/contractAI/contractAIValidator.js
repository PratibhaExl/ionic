import { differenceInDays, parseISO } from 'date-fns'

const ROYALTY_THRESHOLD_PCT = 0.5
const REVENUE_SHARE_MAX_PCT = 0.3
const EXPIRY_WARN_DAYS = 30

/**
 * AI-style validation rules for contracts. Detects risky or inconsistent terms.
 */
export function validateContract(contract, options = {}) {
  const warnings = []
  const royaltyPct = Number(contract.royaltyPercent) || 0
  const minGuarantee = Number(contract.minimumGuarantee) || 0
  const endDate = contract.endDate ? (typeof contract.endDate === 'string' ? parseISO(contract.endDate) : contract.endDate) : null

  if (royaltyPct > ROYALTY_THRESHOLD_PCT) {
    warnings.push({ id: 'royalty_high', severity: 'warning', message: `Royalty rate exceeds ${ROYALTY_THRESHOLD_PCT * 100}% threshold (current: ${(royaltyPct * 100).toFixed(1)}%)` })
  }

  if (endDate && differenceInDays(endDate, new Date()) <= EXPIRY_WARN_DAYS && differenceInDays(endDate, new Date()) > 0) {
    warnings.push({ id: 'expiry_soon', severity: 'warning', message: `Contract expires within ${EXPIRY_WARN_DAYS} days (${contract.endDate})` })
  }

  // Only flag as expired when end date is past and contract is still marked active (avoid redundant warning if status already 'expired')
  if (endDate && differenceInDays(endDate, new Date()) < 0 && (contract.status || 'active') !== 'expired') {
    warnings.push({ id: 'expired', severity: 'error', message: 'Contract has expired' })
  }

  if (options.projectedSales != null && minGuarantee > 0 && options.projectedSales > 0 && minGuarantee > options.projectedSales) {
    warnings.push({ id: 'mg_exceeds_sales', severity: 'warning', message: 'Minimum guarantee exceeds projected sales' })
  }

  return warnings
}

export function validateAllContracts(contracts, options = {}) {
  const byContract = {}
  contracts.forEach((c) => {
    byContract[c.id] = validateContract(c, options)
  })
  return byContract
}
