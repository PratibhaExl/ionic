import React, { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { create, getAllByOrganization, update } from '../../database/dbService'
import { useAuth } from '../../context/AuthContext'
import { rebuildTalentMonthPaymentSnapshotsForOrganization } from '../../repositories/talentMonthPaymentSnapshots'
import { UploadZone } from '../../components/forms/UploadZone'
import { parseSalesFile } from '../../utils/parseSalesFile'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Checkbox } from '../../components/ui/checkbox'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Download, Trash2, CheckSquare, Square } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import {
  buildRoyaltyLedger,
  calcNetSales,
  calcPlatformRevenue,
  calcRoyaltyToTalent,
  calcSportsBusinessShare,
  computeSaleDistributionTotals,
} from '../../utils/revenueEngine'
import { getRoyaltyByTalent } from '../../utils/revenueShareEngine'
import { BATCH_APPROVAL_PENDING } from '../../utils/clubReportingSales'

function mapTalentIdsForOrg(talentNamesStr, talents) {
  if (!talentNamesStr) return []
  const names = String(talentNamesStr)
    .split(/[,;]/)
    .map((n) => n.trim())
    .filter(Boolean)
  return names.map((name) => talents.find((t) => t.name === name)?.id).filter(Boolean)
}

/** When several sportsBusiness rows share the same businessName, pick licenseeId from the active contract for a resolved talent. */
function resolveLicenseeIdForSale(rest, talentIds, businesses, contracts) {
  const candidates = businesses.filter((b) => b.businessName === rest.licensee)
  let id = candidates[0]?.id || rest.licenseeId
  if (candidates.length <= 1 || !talentIds?.length) return id
  for (const tid of talentIds) {
    const c = contracts.find((x) => x.talentId === tid && candidates.some((b) => b.id === x.licenseeId))
    if (c?.licenseeId) return c.licenseeId
  }
  return id
}

function saleLikeWithTalentIds(row, talents) {
  const talentIds = row.talentIds?.length ? row.talentIds : mapTalentIdsForOrg(row.talentNames, talents)
  return { ...row, talentIds }
}

/** Drop empty optional fields; coerce numeric overrides for `sales` create. */
function cleanSalesPayload(rest) {
  const p = { ...rest }
  const numericOptional = [
    'talentRoyaltyOverride',
    'clubShareOverride',
    'platformRevenueOverride',
    'manualTalentRoyaltyPercent',
    'manualClubRevenueSharePercent',
  ]
  for (const k of numericOptional) {
    if (p[k] === '' || p[k] === undefined || p[k] === null) {
      delete p[k]
      continue
    }
    const n = Number(p[k])
    if (!Number.isFinite(n)) delete p[k]
    else p[k] = n
  }
  if (p.importContractRef != null && String(p.importContractRef).trim() === '') delete p.importContractRef
  if (p.licenseeId != null && String(p.licenseeId).trim() === '') delete p.licenseeId
  return p
}

export function PartnerUploadSalesPage() {
  const { loading: pageLoad, loadMessage } = usePageLoadAuto('Loading upload...', 'Upload page loaded')
  const { currentOrganizationId } = useOrganization()
  const { user } = useAuth()
  const { bumpDataRevision, dataRevision } = useAppStore()

  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const businesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )

  const [parsing, setParsing] = useState(false)
  const [stagedRows, setStagedRows] = useState([])
  const [selectedIds, setSelectedIds] = useState(() => new Set())
  const [lastBatchId, setLastBatchId] = useState(null)

  const importBatches = useMemo(() => {
    const list = getAllByOrganization('vendorImportBatches', currentOrganizationId) || []
    return [...list].sort((a, b) => String(b.uploadedAt || '').localeCompare(String(a.uploadedAt || '')))
  }, [currentOrganizationId, dataRevision])

  const allSelected = stagedRows.length > 0 && stagedRows.every((r) => selectedIds.has(r._stagedId))
  const setAllSelectedState = (checked) => {
    if (checked === true) setSelectedIds(new Set(stagedRows.map((r) => r._stagedId)))
    else setSelectedIds(new Set())
  }

  const toggleOne = (id, checked) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (checked === true) next.add(id)
      else next.delete(id)
      return next
    })
  }

  const handleFile = async (file) => {
    setParsing(true)
    try {
      const rows = await parseSalesFile(file)
      const withIds = rows.map((r) => ({
        ...r,
        _stagedId: globalThis.crypto?.randomUUID?.() || `st-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
        _fileName: file.name,
      }))
      setStagedRows(withIds)
      setSelectedIds(new Set(withIds.map((x) => x._stagedId)))
      toast.success(`Loaded ${withIds.length} row(s). Review and process.`)
    } catch (err) {
      toast.error(err.message || String(err))
    } finally {
      setParsing(false)
    }
  }

  const deleteRow = (id) => {
    setStagedRows((list) => list.filter((r) => r._stagedId !== id))
    setSelectedIds((prev) => {
      const next = new Set(prev)
      next.delete(id)
      return next
    })
  }

  const deleteSelected = () => {
    setStagedRows((list) => list.filter((r) => !selectedIds.has(r._stagedId)))
    setSelectedIds(new Set())
    toast.success('Removed selected rows')
  }

  const patchStagedRow = (stagedId, patch) => {
    setStagedRows((list) => list.map((r) => (r._stagedId === stagedId ? { ...r, ...patch } : r)))
  }

  const processRecords = () => {
    const toProcess = stagedRows.filter((r) => selectedIds.has(r._stagedId))
    if (toProcess.length === 0) {
      toast.error('Select at least one row to process')
      return
    }
    if (!currentOrganizationId) {
      toast.error('No organization context')
      return
    }
    const sponsors = getAllByOrganization('sponsorshipCompanies', currentOrganizationId) || []
    const vendorCompanyName = user?.name || sponsors[0]?.companyName || 'Partner vendor'
    const batch = create('vendorImportBatches', {
      organizationId: currentOrganizationId,
      fileName: toProcess[0]?._fileName || 'upload',
      uploadedAt: new Date().toISOString(),
      rowCount: toProcess.length,
      processedCount: 0,
      status: 'processing',
      summaryJson: null,
      uploadedByUserId: user?.id,
      uploadedByName: user?.name,
      uploadedByEmail: user?.email,
      vendorCompanyName,
      approvalStatus: BATCH_APPROVAL_PENDING,
    })
    const createdSales = []
    let ok = 0
    for (const row of toProcess) {
      const { _stagedId, _fileName, ...raw } = row
      const { id: _importRowId, ...rest } = raw
      const talentIds = mapTalentIdsForOrg(rest.talentNames, talents)
      const licenseeId =
        (rest.licenseeId && String(rest.licenseeId).trim()) || resolveLicenseeIdForSale(rest, talentIds, businesses, contracts)
      const payload = cleanSalesPayload({
        ...rest,
        talentIds,
        licenseeId: licenseeId || undefined,
      })
      const rec = create('sales', {
        ...payload,
        organizationId: currentOrganizationId,
        vendorImportBatchId: batch?.id,
      })
      if (rec) createdSales.push(rec)
      ok++
    }
    const impact = computeDistributionImpactForSalesSubset(createdSales, currentOrganizationId)
    if (batch?.id) {
      update('vendorImportBatches', batch.id, {
        processedCount: ok,
        status: 'completed',
        summaryJson: JSON.stringify(impact),
      })
    }
    setLastBatchId(batch?.id)
    try {
      rebuildTalentMonthPaymentSnapshotsForOrganization(currentOrganizationId)
    } catch (e) {
      console.warn('Talent month payment snapshot rebuild after vendor import failed', e)
    }
    bumpDataRevision()
    window.dispatchEvent(
      new CustomEvent('sports-pay-vendor-import', { detail: { count: ok, pendingClubApproval: true } })
    )
    toast.success(
      `${ok} sales row(s) submitted. Awaiting Sport Business approval — club dashboards update after approval.`
    )
    setStagedRows([])
    setSelectedIds(new Set())
  }

  if (pageLoad) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-accent-800">Upload revenue share file</h2>
        <p className="mt-1 text-sm text-neutral">
          CSV / Excel → review in the table → process into sales. The central ledger recalculates talent and contract revenue share
          automatically.
        </p>
      </div>

      <Card className="border-accent/20 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">File upload</CardTitle>
              <p className="text-sm text-neutral">
            Columns: SKU, Licensee (exact sports-business line name), ProductDescription, TalentNames, Country, UnitsSold, EffectiveUnitSalesPrice,
            NetSales, Date. Optional: ID, LicenseeId (e.g. sb-1), Currency, TypeOfSales. Sample file includes filled values for every column to test
            the flow. Talent names must match roster exactly; comma or semicolon between multiple names.
          </p>
          <a
            href="/sample/sales.csv"
            download="sales-sample.csv"
            className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
          >
            <Download className="h-4 w-4" /> Download sample sales.csv
          </a>
        </CardHeader>
        <CardContent>
          <UploadZone onFile={handleFile} disabled={parsing} />
          {parsing && <p className="mt-2 text-sm text-neutral">Parsing file…</p>}
        </CardContent>
      </Card>

      {importBatches.length > 0 && (
        <Card className="border-accent/20 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Recent vendor imports</CardTitle>
            <p className="text-2xs text-neutral">
              Batches created when you process a file. Club approval is required before revenue share hits Sport Business dashboards.
            </p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <table className="w-full text-2xs sm:text-xs">
              <thead>
                <tr className="border-b bg-slate-50 text-left">
                  <th className="px-3 py-2 font-semibold">File</th>
                  <th className="px-3 py-2 font-semibold">Uploaded by</th>
                  <th className="px-3 py-2 font-semibold">When</th>
                  <th className="px-3 py-2 text-right font-semibold">Rows</th>
                  <th className="px-3 py-2 font-semibold">Import</th>
                  <th className="px-3 py-2 font-semibold">Club approval</th>
                </tr>
              </thead>
              <tbody>
                {importBatches.slice(0, 8).map((b) => (
                  <tr key={b.id} className="border-b border-slate-100">
                    <td className="px-3 py-2">{b.fileName}</td>
                    <td className="max-w-[140px] px-3 py-2">
                      <span className="font-medium text-slate-800">{b.vendorCompanyName || b.uploadedByName || '—'}</span>
                      {b.uploadedByEmail ? (
                        <span className="block truncate text-3xs text-neutral">{b.uploadedByEmail}</span>
                      ) : null}
                    </td>
                    <td className="px-3 py-2 font-mono text-neutral">
                      {b.uploadedAt ? format(new Date(b.uploadedAt), 'yyyy-MM-dd HH:mm') : '—'}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums">
                      {b.processedCount ?? 0} / {b.rowCount ?? 0}
                    </td>
                    <td className="px-3 py-2 capitalize">{b.status || '—'}</td>
                    <td className="px-3 py-2">
                      {(b.approvalStatus || 'approved') === BATCH_APPROVAL_PENDING ? (
                        <span className="text-amber-800">Pending</span>
                      ) : (
                        <span className="text-emerald-800">Approved</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {stagedRows.length > 0 && (
        <Card className="border-primary/15 shadow-md">
          <CardHeader className="flex flex-col gap-3 border-b border-slate-200/90 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle className="text-base">Data processing</CardTitle>
              <p className="text-2xs text-neutral">
                Edit any cell before processing — including optional contract ref, talent/club % (enter 6 for 6%), dollar overrides for talent
                revenue share, club share, and vendor remainder. Empty % / $ overrides use roster and contract math. Only selected rows are
                saved.
              </p>
              <Link to="/partner/sales" className="mt-1 inline-block text-sm font-medium text-primary hover:underline">
                View committed sales →
              </Link>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setAllSelectedState(!allSelected)}>
                {allSelected ? (
                  <>
                    <Square className="mr-1 h-4 w-4" /> Deselect all
                  </>
                ) : (
                  <>
                    <CheckSquare className="mr-1 h-4 w-4" /> Select all
                  </>
                )}
              </Button>
              <Button type="button" variant="outline" size="sm" className="border-red-200 text-red-600" onClick={deleteSelected}>
                <Trash2 className="mr-1 h-4 w-4" />
                Delete selected
              </Button>
              <Button type="button" variant="accent" size="sm" onClick={processRecords}>
                Process records
              </Button>
            </div>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <table className="w-full min-w-[1680px] text-2xs sm:text-xs">
              <thead>
                <tr className="border-b bg-slate-50 text-left">
                  <th className="sticky left-0 z-10 w-10 bg-slate-50 px-2 py-2">
                    <Checkbox
                      checked={allSelected}
                      onCheckedChange={(v) => setAllSelectedState(v === true)}
                      aria-label="Select all"
                    />
                  </th>
                  <th className="px-2 py-2 font-semibold">External ID</th>
                  <th className="px-2 py-2 font-semibold">SKU</th>
                  <th className="px-2 py-2 font-semibold">Licensee ID</th>
                  <th className="px-2 py-2 font-semibold">Licensee</th>
                  <th className="px-2 py-2 font-semibold">Product</th>
                  <th className="px-2 py-2 font-semibold">Talents</th>
                  <th className="px-2 py-2 font-semibold">Country</th>
                  <th className="min-w-[64px] px-2 py-2 font-semibold">Currency</th>
                  <th className="min-w-[72px] px-2 py-2 font-semibold">Type</th>
                  <th className="min-w-[72px] px-2 py-2 text-right font-semibold">Units</th>
                  <th className="min-w-[72px] px-2 py-2 text-right font-semibold">Unit $</th>
                  <th className="min-w-[80px] px-2 py-2 text-right font-semibold">Net sales</th>
                  <th className="min-w-[110px] px-2 py-2 font-semibold">Date</th>
                  <th className="min-w-[100px] px-2 py-2 font-semibold">Contract ref</th>
                  <th className="min-w-[88px] px-2 py-2 text-right font-semibold">Talent %</th>
                  <th className="min-w-[96px] px-2 py-2 text-right font-semibold">Talent rev $</th>
                  <th className="min-w-[72px] px-2 py-2 text-right font-semibold">Club %</th>
                  <th className="min-w-[88px] px-2 py-2 text-right font-semibold">Club $</th>
                  <th className="min-w-[88px] px-2 py-2 text-right font-semibold">Vendor $</th>
                  <th className="px-2 py-2 font-semibold"> </th>
                </tr>
              </thead>
              <tbody>
                {stagedRows.map((row) => {
                  const saleLike = saleLikeWithTalentIds(row, talents)
                  const econ = computeSaleDistributionTotals(saleLike, contracts, talents, businesses)
                  return (
                    <tr key={row._stagedId} className="border-b border-slate-100 hover:bg-slate-50/80">
                      <td className="sticky left-0 z-10 bg-white px-2 py-1">
                        <Checkbox
                          checked={selectedIds.has(row._stagedId)}
                          onCheckedChange={(v) => toggleOne(row._stagedId, v === true)}
                          aria-label="Select row"
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[88px] font-mono text-2xs"
                          title="From file; a new id is assigned when you process"
                          value={row.id ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { id: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[72px] font-mono text-2xs"
                          value={row.sku ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { sku: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[64px] font-mono text-2xs"
                          placeholder="sb-1"
                          value={row.licenseeId ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { licenseeId: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[120px] text-2xs"
                          value={row.licensee ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { licensee: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[140px] text-2xs"
                          value={row.productDescription ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { productDescription: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[120px] text-2xs"
                          value={row.talentNames ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { talentNames: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[72px] text-2xs"
                          value={row.country ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { country: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 w-14 text-2xs uppercase"
                          value={row.currency ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { currency: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[64px] text-2xs"
                          value={row.typeOfSales ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { typeOfSales: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          className="h-8 w-16 text-right text-2xs tabular-nums"
                          value={row.unitsSold ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { unitsSold: e.target.value === '' ? '' : Number(e.target.value) })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          className="h-8 w-20 text-right text-2xs tabular-nums"
                          value={row.effectiveUnitSalesPrice ?? ''}
                          onChange={(e) =>
                            patchStagedRow(row._stagedId, {
                              effectiveUnitSalesPrice: e.target.value === '' ? '' : Number(e.target.value),
                            })
                          }
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          className="h-8 w-24 text-right text-2xs tabular-nums"
                          value={row.netSales ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { netSales: e.target.value === '' ? '' : Number(e.target.value) })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="date"
                          className="h-8 min-w-[118px] font-mono text-2xs"
                          value={(row.date || '').toString().slice(0, 10)}
                          onChange={(e) => patchStagedRow(row._stagedId, { date: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          className="h-8 min-w-[96px] font-mono text-2xs"
                          placeholder={econ.primaryContract}
                          value={row.importContractRef ?? ''}
                          onChange={(e) => patchStagedRow(row._stagedId, { importContractRef: e.target.value })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          step="0.01"
                          className="h-8 w-[72px] text-right text-2xs tabular-nums"
                          title="Override contract % (enter 6 for 6%). Leave empty to use contract."
                          placeholder={econ.contractRevPctLabel}
                          value={row.manualTalentRoyaltyPercent ?? ''}
                          onChange={(e) =>
                            patchStagedRow(row._stagedId, {
                              manualTalentRoyaltyPercent: e.target.value === '' ? '' : e.target.value,
                            })
                          }
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          step="0.01"
                          className="h-8 w-[88px] text-right text-2xs tabular-nums"
                          title="Override total talent revenue share ($). Leave empty to calculate."
                          placeholder={String(Math.round(econ.talentRoyaltyTotal * 100) / 100)}
                          value={row.talentRoyaltyOverride ?? ''}
                          onChange={(e) =>
                            patchStagedRow(row._stagedId, {
                              talentRoyaltyOverride: e.target.value === '' ? '' : e.target.value,
                            })
                          }
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          step="0.01"
                          className="h-8 w-[64px] text-right text-2xs tabular-nums"
                          title="Override club revenue share % (6 = 6%)"
                          placeholder={econ.clubRevPctLabel}
                          value={row.manualClubRevenueSharePercent ?? ''}
                          onChange={(e) =>
                            patchStagedRow(row._stagedId, {
                              manualClubRevenueSharePercent: e.target.value === '' ? '' : e.target.value,
                            })
                          }
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          step="0.01"
                          className="h-8 w-[84px] text-right text-2xs tabular-nums"
                          title="Override club $ share"
                          placeholder={String(Math.round(econ.clubShare * 100) / 100)}
                          value={row.clubShareOverride ?? ''}
                          onChange={(e) =>
                            patchStagedRow(row._stagedId, { clubShareOverride: e.target.value === '' ? '' : e.target.value })
                          }
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Input
                          type="number"
                          step="0.01"
                          className="h-8 w-[84px] text-right text-2xs tabular-nums"
                          title="Override vendor / platform remainder ($)"
                          placeholder={String(Math.round(econ.vendorEarned * 100) / 100)}
                          value={row.platformRevenueOverride ?? ''}
                          onChange={(e) =>
                            patchStagedRow(row._stagedId, {
                              platformRevenueOverride: e.target.value === '' ? '' : e.target.value,
                            })
                          }
                        />
                      </td>
                      <td className="px-1 py-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-600"
                          onClick={() => deleteRow(row._stagedId)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {lastBatchId && (
        <p className="text-2xs text-neutral">
          Last batch id: <span className="font-mono">{lastBatchId}</span> · stored in vendor import history (see vendor dashboard).
        </p>
      )}
    </div>
  )
}

function computeDistributionImpactForSalesSubset(salesSubset, organizationId) {
  const contracts = getAllByOrganization('contracts', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const ledger = buildRoyaltyLedger(salesSubset, contracts, talents, sportsBusinesses)
  const byTalent = getRoyaltyByTalent(ledger)
  return {
    generatedAt: format(new Date(), "yyyy-MM-dd'T'HH:mm:ss"),
    ledgerLineCount: ledger.length,
    byTalent,
  }
}
