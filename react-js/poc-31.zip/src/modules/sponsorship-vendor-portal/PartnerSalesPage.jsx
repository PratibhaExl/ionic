import React, { useState, useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { getReportingSalesForOrganization } from '../../utils/clubReportingSales'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { DataTable } from '../../components/tables/DataTable'
import { FilterPanel } from '../../components/filters/FilterPanel'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { DollarSign, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import Papa from 'papaparse'

const ALL_VALUE = '__all__'

export function PartnerSalesPage() {
  const { loading: pageLoading, loadMessage } = usePageLoadAuto('Loading sales data...', 'Sales data loaded')
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  /** Club-approved batches only — matches Sport Business / talent portals after approval. */
  const sales = useMemo(
    () => getReportingSalesForOrganization(currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const invoices = useMemo(
    () => getAllByOrganization('invoices', currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const [licenseeFilter, setLicenseeFilter] = useState([])
  const [countryFilter, setCountryFilter] = useState(ALL_VALUE)
  const [productFilter, setProductFilter] = useState('')
  const [monthFilter, setMonthFilter] = useState(ALL_VALUE)

  const licensees = useMemo(() => [...new Set(sales.map((s) => s.licensee).filter(Boolean))], [sales])
  const countries = useMemo(() => [...new Set(sales.map((s) => s.country).filter(Boolean))], [sales])
  const monthOptions = useMemo(() => {
    const set = new Set()
    sales.forEach((s) => {
      const d = s.date
      if (d && typeof d === 'string' && d.length >= 7) set.add(d.slice(0, 7))
    })
    return [...set].sort((a, b) => b.localeCompare(a))
  }, [sales])

  const filtered = useMemo(() => {
    return sales.filter((s) => {
      if (licenseeFilter.length > 0 && !licenseeFilter.includes(s.licensee)) return false
      if (countryFilter && countryFilter !== ALL_VALUE && s.country !== countryFilter) return false
      if (monthFilter && monthFilter !== ALL_VALUE) {
        const m = (s.date || '').toString().slice(0, 7)
        if (m !== monthFilter) return false
      }
      if (productFilter && !(s.productDescription || s.sku || '').toLowerCase().includes(productFilter.toLowerCase())) return false
      return true
    })
  }, [sales, licenseeFilter, countryFilter, monthFilter, productFilter])

  const ledger = useMemo(
    () => buildRoyaltyLedger(filtered, contracts, talents, sportsBusinesses),
    [filtered, contracts, talents, sportsBusinesses]
  )
  const royaltyTotal = ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const royaltyEarned = (invoices || []).reduce((a, i) => a + (Number(i.paidAmount) || 0), 0)
  const royaltyPending = Math.max(0, royaltyTotal - royaltyEarned)

  const monthlyData = useMemo(() => {
    const byMonth = {}
    filtered.forEach((s) => {
      const d = s.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(byMonth)
      .map(([month, revenue]) => ({ month, revenue }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-24)
  }, [filtered])
  const countryData = useMemo(() => {
    const byCountry = {}
    filtered.forEach((s) => {
      const c = s.country || 'Other'
      byCountry[c] = (byCountry[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(byCountry).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [filtered])

  const filters = [
    {
      key: 'licensee',
      label: 'Licensee',
      type: 'multicheckbox',
      value: licenseeFilter,
      onChange: setLicenseeFilter,
      options: licensees.map((l) => ({ value: l, label: l })),
    },
    {
      key: 'country',
      label: 'Country',
      type: 'select',
      value: countryFilter || ALL_VALUE,
      onChange: setCountryFilter,
      options: [{ value: ALL_VALUE, label: 'All' }, ...countries.map((c) => ({ value: c, label: c }))],
      placeholder: 'All',
    },
    {
      key: 'month',
      label: 'Month',
      type: 'select',
      value: monthFilter || ALL_VALUE,
      onChange: setMonthFilter,
      options: [
        { value: ALL_VALUE, label: 'All months' },
        ...monthOptions.map((m) => ({ value: m, label: m })),
      ],
      placeholder: 'All months',
    },
  ]

  const salesGlobalFilterFn = (row, _columnId, filterValue) => {
    const q = String(filterValue ?? '').trim().toLowerCase()
    if (!q) return true
    const r = row.original
    const dateStr = r.date ? String(r.date) : ''
    let monthVariants = []
    if (dateStr.length >= 10) {
      try {
        const parsed = new Date(dateStr.slice(0, 10))
        if (!Number.isNaN(parsed.getTime())) {
          monthVariants = [
            format(parsed, 'yyyy-MM'),
            format(parsed, 'MMMM yyyy'),
            format(parsed, 'MMM yyyy'),
            format(parsed, 'MMMM'),
            format(parsed, 'MMM'),
          ].map((x) => x.toLowerCase())
        }
      } catch {
        /* ignore */
      }
    }
    const blob = [
      r.sku,
      r.licensee,
      r.productDescription,
      r.country,
      r.currency,
      r.talentNames,
      r.typeOfSales,
      dateStr,
      ...monthVariants,
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase()
    return blob.includes(q)
  }

  const columns = [
    { id: 'sku', header: 'SKU', accessorKey: 'sku' },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'productDescription', header: 'Product', accessorKey: 'productDescription' },
    { id: 'country', header: 'Country', accessorKey: 'country' },
    { id: 'currency', header: 'Currency', accessorKey: 'currency' },
    { id: 'unitsSold', header: 'Units', accessorKey: 'unitsSold' },
    { id: 'effectiveUnitSalesPrice', header: 'Unit Price', accessorKey: 'effectiveUnitSalesPrice', cell: (info) => `$${Number(info.getValue()).toFixed(2)}` },
    { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'typeOfSales', header: 'Type', accessorKey: 'typeOfSales' },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  const exportCSV = () => {
    const keys = columns.map((c) => c.accessorKey || c.id).filter(Boolean)
    const rows = filtered.map((row) => keys.map((k) => row[k] ?? ''))
    const csv = Papa.unparse({ fields: keys, data: rows })
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `sales-export-${new Date().toISOString().slice(0, 10)}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  if (pageLoading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">Sales</h2>
          <p className="mt-1 max-w-xl text-2xs text-neutral">
            Net sales and revenue share below include only files the club has approved. Pending uploads appear in Upload sales until approved.
          </p>
        </div>
        <Button variant="outline" onClick={exportCSV}>Export CSV</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Revenue share total" value={`$${royaltyTotal.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Revenue share paid" value={`$${royaltyEarned.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Revenue share pending" value={`$${royaltyPending.toLocaleString()}`} icon={DollarSign} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <CountrySalesChart data={countryData} />
      </div>
    
      <div className="flex gap-6">
        <FilterPanel
          filters={filters}
          onApply={() => {}}
          onReset={() => {
            setLicenseeFilter([])
            setCountryFilter(ALL_VALUE)
            setMonthFilter(ALL_VALUE)
            setProductFilter('')
          }}
        />
        <div className="flex-1 space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Search product..."
              value={productFilter}
              onChange={(e) => setProductFilter(e.target.value)}
              className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
            />
          </div>
          <DataTable
            columns={columns}
            data={filtered}
            searchKey="sku"
            searchPlaceholder="Search SKU, licensee, product, country, month (e.g. 2026-03, Mar 2026)…"
            pageSize={15}
            globalFilterFn={salesGlobalFilterFn}
          />
        </div>
      </div>
    </div>
  )
}
