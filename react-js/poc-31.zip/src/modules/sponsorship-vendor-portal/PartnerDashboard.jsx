import React, { useMemo, useState } from 'react'
import { getAllByOrganization } from '../../database/dbService'
import { getReportingSalesForOrganization } from '../../utils/clubReportingSales'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { DollarSign, Building2, FileText, TrendingUp, Upload, FileX } from 'lucide-react'
import { endOfMonth, format, parseISO, startOfMonth, startOfYear } from 'date-fns'
import { Link } from 'react-router-dom'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
function aggregateByMonth(sales) {
  const byMonth = {}
  sales.forEach((s) => {
    const d = s.date || s.Date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.netSales || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
}

function parseSaleDate(sale) {
  const raw = sale?.date || sale?.Date
  if (!raw) return null
  try {
    const d = typeof raw === 'string' ? parseISO(String(raw).slice(0, 10)) : new Date(raw)
    return Number.isNaN(d.getTime()) ? null : d
  } catch {
    return null
  }
}

function saleInRange(sale, from, to) {
  if (!from && !to) return true
  const d = parseSaleDate(sale)
  if (!d) return false
  if (from && d < from) return false
  if (to) {
    const end = new Date(to)
    end.setHours(23, 59, 59, 999)
    if (d > end) return false
  }
  return true
}

function attributedNetSalesForContract(contract, salesInRange) {
  return salesInRange.reduce((sum, s) => {
    const tids = s.talentIds || []
    if (!tids.includes(contract.talentId)) return sum
    const matchLicensee = s.licenseeId === contract.licenseeId || s.licensee === contract.licensee
    if (!matchLicensee) return sum
    return sum + (Number(s.netSales) || 0)
  }, 0)
}

export function PartnerDashboard() {
  const { loading, loadMessage } = usePageLoadAuto('Loading partner dashboard...', 'Dashboard loaded')
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const [periodMode, setPeriodMode] = useState('ytd')
  const [customFrom, setCustomFrom] = useState('')
  const [customTo, setCustomTo] = useState('')

  const sales = useMemo(
    () => getReportingSalesForOrganization(currentOrganizationId) || [],
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sponsorshipCompanies = useMemo(
    () => getAllByOrganization('sponsorshipCompanies', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const invoices = useMemo(
    () => getAllByOrganization('invoices', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const importBatches = useMemo(
    () =>
      [...(getAllByOrganization('vendorImportBatches', currentOrganizationId) || [])].sort((a, b) =>
        String(b.uploadedAt || '').localeCompare(String(a.uploadedAt || ''))
      ),
    [currentOrganizationId, dataRevision]
  )

  const rangeBounds = useMemo(() => {
    const now = new Date()
    if (periodMode === 'all') return { from: null, to: null, label: 'All time' }
    if (periodMode === 'ytd') {
      const end = new Date()
      end.setHours(23, 59, 59, 999)
      return { from: startOfYear(now), to: end, label: `YTD ${format(now, 'yyyy')}` }
    }
    if (periodMode === 'month') {
      return {
        from: startOfMonth(now),
        to: endOfMonth(now),
        label: `This month (${format(now, 'MMMM yyyy')})`,
      }
    }
    const from = customFrom ? parseISO(customFrom) : null
    const to = customTo ? parseISO(customTo) : null
    return {
      from,
      to,
      label:
        customFrom && customTo
          ? `${customFrom} → ${customTo}`
          : customFrom || customTo
            ? `${customFrom || '…'} → ${customTo || '…'}`
            : 'Custom (set dates)',
    }
  }, [periodMode, customFrom, customTo])

  const filteredSales = useMemo(
    () => sales.filter((s) => saleInRange(s, rangeBounds.from, rangeBounds.to)),
    [sales, rangeBounds.from, rangeBounds.to]
  )

  const activeContracts = useMemo(() => contracts.filter((c) => c.status === 'active'), [contracts])
  const inactiveContracts = useMemo(() => contracts.filter((c) => c.status !== 'active'), [contracts])
  const partnerCompaniesCount = sponsorshipCompanies.length
  const totalSalesInRange = filteredSales.reduce((a, s) => a + (Number(s.netSales) || 0), 0)
  const royaltyContributions = useMemo(() => {
    return (invoices || []).reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0)
  }, [invoices])

  const countryRevenue = useMemo(() => {
    const map = {}
    filteredSales.forEach((s) => {
      const c = s.country || 'Other'
      map[c] = (map[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [filteredSales])

  const monthlyData = useMemo(() => {
    const series = aggregateByMonth(filteredSales)
    return series.length > 24 ? series.slice(-24) : series
  }, [filteredSales])

  const mgByContract = useMemo(() => {
    return contracts.map((c) => {
      const target = Number(c.skuMinimumGuaranteeAnnual ?? c.minimumGuarantee ?? 0) || 0
      const attributed = attributedNetSalesForContract(c, filteredSales)
      const earnedTowardMg = target > 0 ? Math.min(attributed, target) : attributed
      const pendingMg = target > 0 ? Math.max(0, target - attributed) : 0
      return {
        contract: c,
        target,
        attributed,
        earnedTowardMg,
        pendingMg,
      }
    })
  }, [contracts, filteredSales])

  const clubPartners = useMemo(() => {
    const set = new Set()
    contracts.forEach((c) => {
      if (c.licensee) set.add(c.licensee)
    })
    return Array.from(set)
  }, [contracts])

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral">
          Vendor summary for your organization. Charts and net sales use club-approved uploads only so totals stay aligned with Sport Business and talent portals after each approval.
        </p>
        <Button asChild variant="accent" size="sm" className="shrink-0 gap-2">
          <Link to="/partner/upload-sales">
            <Upload className="h-4 w-4" />
            Upload sales file
          </Link>
        </Button>
      </div>

      <Card className="border-accent/20 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Sales report period</CardTitle>
          <p className="text-2xs text-neutral">
            Choose YTD, this month, a custom date range, or all time. Charts and net sales below follow this selection. Minimum guarantee progress uses the same window.
          </p>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'ytd', label: 'YTD' },
              { id: 'month', label: 'This month' },
              { id: 'all', label: 'All time' },
              { id: 'custom', label: 'Custom range' },
            ].map((p) => (
              <Button
                key={p.id}
                type="button"
                size="sm"
                variant={periodMode === p.id ? 'accent' : 'outline'}
                onClick={() => setPeriodMode(p.id)}
              >
                {p.label}
              </Button>
            ))}
          </div>
          {periodMode === 'custom' && (
            <div className="flex flex-wrap items-end gap-3">
              <div>
                <Label className="text-2xs">From</Label>
                <Input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} className="mt-1 w-40" />
              </div>
              <div>
                <Label className="text-2xs">To</Label>
                <Input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} className="mt-1 w-40" />
              </div>
            </div>
          )}
          <p className="text-sm text-primary-900">
            <span className="font-semibold">{rangeBounds.label}</span>
            <span className="text-neutral"> · Net sales in range: </span>
            <span className="font-mono font-semibold tabular-nums">${totalSalesInRange.toLocaleString()}</span>
          </p>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Partner Companies" value={partnerCompaniesCount} icon={Building2} subtitle="Sport / vendor partners" />
        <StatCard title="Active Contracts" value={activeContracts.length} icon={FileText} subtitle="Current agreements" />
        <StatCard title="Inactive Contracts" value={inactiveContracts.length} icon={FileX} subtitle="Expired / non-active" />
        <StatCard title="Total Contracts" value={contracts.length} icon={FileText} subtitle="All statuses" />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Revenue share (invoices)" value={`$${royaltyContributions.toLocaleString()}`} icon={TrendingUp} subtitle="Royalty amounts on file" />
        <StatCard title="Net sales (selected period)" value={`$${totalSalesInRange.toLocaleString()}`} icon={DollarSign} subtitle="Filtered by period above" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <CountrySalesChart data={countryRevenue} />
      </div>

      <Card className="border-accent/20 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">Minimum guarantee vs attributed net sales</CardTitle>
          <p className="text-2xs text-neutral">
            Per contract: annual SKU / contract minimum (when set), net sales attributed to that talent and club in the selected period, amount credited toward the cap, and remaining gap (pending).
          </p>
        </CardHeader>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full min-w-[720px] text-2xs sm:text-xs">
            <thead>
              <tr className="border-b bg-slate-50 text-left">
                <th className="px-3 py-2 font-semibold">Contract</th>
                <th className="px-3 py-2 font-semibold">Club</th>
                <th className="px-3 py-2 text-right font-semibold">MG target</th>
                <th className="px-3 py-2 text-right font-semibold">Attributed sales</th>
                <th className="px-3 py-2 text-right font-semibold">Earned (toward MG)</th>
                <th className="px-3 py-2 text-right font-semibold">Pending (gap)</th>
              </tr>
            </thead>
            <tbody>
              {mgByContract.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-3 py-4 text-neutral">
                    No contracts for this organization.
                  </td>
                </tr>
              ) : (
                mgByContract.map(({ contract: c, target, attributed, earnedTowardMg, pendingMg }) => (
                  <tr key={c.id} className="border-b border-slate-100">
                    <td className="px-3 py-2 font-mono">{c.contractID}</td>
                    <td className="max-w-[200px] truncate px-3 py-2" title={c.licensee}>
                      {c.licensee}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums">{target ? `$${target.toLocaleString()}` : '—'}</td>
                    <td className="px-3 py-2 text-right tabular-nums">${attributed.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-emerald-800">
                      {target ? `$${earnedTowardMg.toLocaleString()}` : `$${attributed.toLocaleString()}`}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums text-amber-800">{target ? `$${pendingMg.toLocaleString()}` : '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
      <Card className="border-accent/20 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">Recent vendor uploads</CardTitle>
          <p className="text-2xs text-neutral">Processed batches notify the Sport Business workspace and rebuild payment snapshots.</p>
        </CardHeader>
        <CardContent>
          {importBatches.length === 0 ? (
            <p className="text-sm text-neutral">No imports yet. Use Upload sales to add revenue share data.</p>
          ) : (
            <ul className="space-y-3">
              {importBatches.slice(0, 6).map((b) => {
                let summary = null
                try {
                  summary = b.summaryJson ? JSON.parse(b.summaryJson) : null
                } catch {
                  summary = null
                }
                return (
                  <li
                    key={b.id}
                    className="flex flex-col gap-1 rounded-lg border border-slate-200/90 bg-slate-50/50 px-3 py-2 text-sm sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <p className="font-medium text-primary-900">{b.fileName || 'Upload'}</p>
                      <p className="text-2xs text-neutral">
                        {b.uploadedAt ? format(new Date(b.uploadedAt), 'PPp') : '—'} · {b.processedCount ?? 0} / {b.rowCount ?? 0}{' '}
                        rows · {b.status}
                      </p>
                    </div>
                    {summary?.byTalent?.length > 0 && (
                      <p className="text-2xs text-slate-600">
                        Top talent: <span className="font-semibold text-accent-700">{summary.byTalent[0]?.name}</span>
                      </p>
                    )}
                  </li>
                )
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Sports Businesses (Clubs) under contract</h3>
        <ul className="space-y-2">
          {clubPartners.length === 0 ? (
            <p className="text-sm text-neutral">No clubs linked yet</p>
          ) : (
            clubPartners.map((name) => (
              <li key={name} className="flex justify-between text-sm">
                <span>{name}</span>
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  )
}
