# Feature modules by portal

Routes still use legacy path prefixes (`/sponsorship/…`, `/talent/…`, `/partner/…`); **this folder layout** matches the three portals in the app shell.

| Folder | Portal (UI) | Typical routes |
|--------|----------------|----------------|
| **`sport-business-club/`** | Sport Business / Club | `/sponsorship/…` routes; page components use **`Club*`** prefix (see `sport-business-club/README.md`) |
| **`talents-players-portal/`** | Talents / Players Portal | `/talent/dashboard`, `/talent/salary`, performance bonus, royalties |
| **`sponsorship-vendor-portal/`** | Sponsorship / Vendor Portal | `/partner/dashboard`, upload sales, sales, contracts |

Shared / cross-cutting modules stay at this level: **`admin/`**, **`auth/`**, **`contracts/`**, **`invoices/`**, **`contractAI/`**.
