import React, { useMemo, useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { getReleaseDateFormatted, getDaysUntilRelease } from '../../utils/signingBonus'
import { downloadSigningBonusCertificatePDF } from '../../utils/pdfGenerator'
import { SigningBonusPDFViewer } from '../../components/forms/SigningBonusPDFViewer'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT, PERFORMANCE_BONUS_PAYROLL_LABEL } from '../../utils/salaryCalculator'

export function TalentSigningBonusPage() {
  const { user } = useAuth()
  const { loading, loadMessage } = usePageLoadAuto('Loading performance bonus...', 'Performance bonus loaded')
  const talentId = user?.talentId
  const talents = getAll('talents')
  const talent = useMemo(() => talents.find((t) => t.id === talentId), [talents, talentId])
  const [viewSigningBonusPdf, setViewSigningBonusPdf] = useState(false)

  const releaseDate = talent?.signingDate ? getReleaseDateFormatted(talent.signingDate) : 'N/A'
  const signingBonusReleased = talent?.signingBonusStatus === 'released' || talent?.signingBonusStatus === 'paid'
  const daysUntil = talent?.signingDate ? getDaysUntilRelease(talent.signingDate) : null

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-accent">Performance Bonus</h2>
      {talent ? (
        <>
          <Card className="border-accent/40 bg-accent/5">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg text-accent">Performance Bonus</CardTitle>
              {signingBonusReleased ? (
                <div className="flex gap-2">
                  <Button className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewSigningBonusPdf(true)}>
                    View Certificate PDF
                  </Button>
                  <Button variant="outline" className="border-accent text-accent hover:bg-accent/10" onClick={() => downloadSigningBonusCertificatePDF({ ...talent, releaseDate })}>
                    Download Certificate PDF
                  </Button>
                </div>
              ) : null}
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm text-neutral">
                {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per month ({PERFORMANCE_BONUS_PAYROLL_LABEL}). Release date: {releaseDate}.
              </p>
              {talent?.signingBonus != null && (
                <p className="text-sm font-medium text-primary">Performance Bonus: {formatINRDisplay(talent.signingBonus)}</p>
              )}
              {signingBonusReleased ? (
                daysUntil !== null && (
                  <p className="text-lg font-semibold text-primary">
                    {daysUntil === 0 ? 'Released' : `${daysUntil} days until release`}
                  </p>
                )
              ) : (
                <p className="text-sm text-amber-600">
                  Your certificate and invoice will be visible here once the platform admin has generated and released your performance bonus (on or after the release date).
                </p>
              )}
            </CardContent>
          </Card>
          {signingBonusReleased && (
            <SigningBonusPDFViewer
              open={viewSigningBonusPdf}
              onOpenChange={setViewSigningBonusPdf}
              talent={{ ...talent, releaseDate }}
              onDownloadPDF={(t) => downloadSigningBonusCertificatePDF(t)}
            />
          )}
        </>
      ) : (
        <p className="text-sm text-neutral">No talent profile found.</p>
      )}
    </div>
  )
}
