import React, { useState, useMemo } from 'react'
import { useAuth } from '../../context/AuthContext'
import { useAppStore } from '../../context/AppStore'
import { getAll } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getReportingSalesForOrganization } from '../../utils/clubReportingSales'
import { DataTable } from '../../components/tables/DataTable'
import { FilterPanel } from '../../components/filters/FilterPanel'
import { StatCard } from '../../components/cards/StatCard'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { DollarSign, TrendingUp } from 'lucide-react'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

export function TalentRoyaltiesPage() {
  const { user } = useAuth()
  const { dataRevision } = useAppStore()
  const { loading, loadMessage } = usePageLoadAuto('Calculating your revenue share...', 'Revenue share data loaded')
  const talentId = user?.talentId
  const sales = useMemo(() => getReportingSalesForOrganization(user?.organizationId), [user?.organizationId, dataRevision])
  const contracts = useMemo(() => getAll('contracts'), [dataRevision])
  const talents = useMemo(() => getAll('talents'), [dataRevision])
  const sportsBusinesses = useMemo(() => getAll('sportsBusinesses'), [dataRevision])
  const invoices = useMemo(() => getAll('invoices'), [dataRevision])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses).filter((r) => r.talentId === talentId),
    [sales, contracts, talents, sportsBusinesses, talentId, dataRevision]
  )

  const royaltyTotal = useMemo(
    () => (invoices || []).filter((inv) => inv.talentId === talentId).reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0),
    [invoices, talentId, dataRevision]
  )
  const royaltyPaid = useMemo(
    () => (invoices || []).filter((inv) => inv.talentId === talentId).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0),
    [invoices, talentId, dataRevision]
  )
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const [licenseeFilter, setLicenseeFilter] = useState('')
  const [countryFilter, setCountryFilter] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  const filtered = useMemo(() => {
    const list = ledger.filter((r) => {
      if (licenseeFilter && r.licensee !== licenseeFilter) return false
      if (countryFilter && r.country !== countryFilter) return false
      if (dateFrom && r.date && r.date < dateFrom) return false
      if (dateTo && r.date && r.date > dateTo) return false
      return true
    })
    let paidRemaining = royaltyPaid
    return list
      .sort((a, b) => (a.date || '').localeCompare(b.date || ''))
      .map((r) => {
        const earned = Number(r.royaltyEarned) || 0
        const rowPaid = Math.min(earned, Math.max(0, paidRemaining))
        paidRemaining -= rowPaid
        const rowPending = earned - rowPaid
        return { ...r, royaltyEarnedPaid: rowPaid, royaltyPending: rowPending }
      })
  }, [ledger, licenseeFilter, countryFilter, dateFrom, dateTo, royaltyPaid])

  const licensees = [...new Set(ledger.map((r) => r.licensee).filter(Boolean))]
  const countries = [...new Set(sales.map((s) => s.country).filter(Boolean))]

  const columns = [
    { id: 'product', header: 'Product', accessorKey: 'product' },
    { id: 'licensee', header: 'Licensee', accessorKey: 'licensee' },
    { id: 'royaltyPercent', header: 'Revenue share %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue()) * 100).toFixed(2)}%` },
    { id: 'royaltyTotal', header: 'Revenue share', accessorKey: 'royaltyEarned', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyEarned', header: 'Revenue share earned', accessorKey: 'royaltyEarnedPaid', cell: (info) => formatINRDisplay(info.getValue() ?? 0) },
    { id: 'royaltyPending', header: 'Revenue share pending', accessorKey: 'royaltyPending', cell: (info) => formatINRDisplay(info.getValue() ?? 0) },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  const filters = [
    { key: 'licensee', label: 'Licensee', type: 'select', value: licenseeFilter, onChange: setLicenseeFilter, options: [{ value: '', label: 'All' }, ...licensees.map((l) => ({ value: l, label: l }))], placeholder: 'All' },
    { key: 'country', label: 'Country', type: 'select', value: countryFilter, onChange: setCountryFilter, options: [{ value: '', label: 'All' }, ...countries.map((c) => ({ value: c, label: c }))], placeholder: 'All' },
    { key: 'dateFrom', label: 'From Date', type: 'date', value: dateFrom, onChange: setDateFrom },
    { key: 'dateTo', label: 'To Date', type: 'date', value: dateTo, onChange: setDateTo },
  ]

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Revenue share</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Revenue share total" value={formatINRDisplay(royaltyTotal)} icon={DollarSign} />
        <StatCard title="Revenue share earned" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
        <StatCard title="Revenue share pending" value={formatINRDisplay(royaltyPending)} icon={DollarSign} />
      </div>
      <div className="flex gap-6">
        <FilterPanel
          filters={filters}
          onApply={() => {}}
          onReset={() => { setLicenseeFilter(''); setCountryFilter(''); setDateFrom(''); setDateTo(''); }}
        />
        <div className="flex-1">
          <DataTable columns={columns} data={filtered} searchKey="product" searchPlaceholder="Search by product..." />
        </div>
      </div>
    </div>
  )
}
