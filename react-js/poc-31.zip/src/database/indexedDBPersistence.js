/**
 * Persist sql.js database binary to IndexedDB so data survives refresh.
 */

const DB_NAME = 'sports_pay_pro_sqlite'
const STORE_NAME = 'db'
const KEY = 'main'

export function saveToIndexedDB(binary) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1)
    req.onerror = () => reject(req.error)
    req.onsuccess = () => {
      const tx = req.result.transaction(STORE_NAME, 'readwrite')
      const store = tx.objectStore(STORE_NAME)
      store.put(binary, KEY)
      tx.oncomplete = () => {
        req.result.close()
        resolve()
      }
      tx.onerror = () => reject(tx.error)
    }
    req.onupgradeneeded = (e) => {
      e.target.result.createObjectStore(STORE_NAME)
    }
  })
}

export function loadFromIndexedDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1)
    req.onerror = () => reject(req.error)
    req.onsuccess = () => {
      const tx = req.result.transaction(STORE_NAME, 'readonly')
      const store = tx.objectStore(STORE_NAME)
      const getReq = store.get(KEY)
      getReq.onsuccess = () => {
        req.result.close()
        resolve(getReq.result ?? null)
      }
      getReq.onerror = () => reject(getReq.error)
    }
    req.onupgradeneeded = (e) => {
      e.target.result.createObjectStore(STORE_NAME)
    }
  })
}
