/**
 * SQLite schema for Sports Pay Pro — shared across Sport Business, Talent, and Partner portals.
 * Run once when DB is created.
 */

export const SCHEMA_SQL = `
-- Organizations (all portals)
CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  name TEXT,
  createdAt TEXT
);

-- Users (login; all portals)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT,
  password TEXT,
  role TEXT,
  name TEXT,
  talentId TEXT,
  organizationId TEXT
);

-- Talents (Sport Business + Talent portal)
CREATE TABLE IF NOT EXISTS talents (
  id TEXT PRIMARY KEY,
  name TEXT,
  employeeId TEXT,
  signingDate TEXT,
  signingBonus REAL DEFAULT 0,
  releaseDate TEXT,
  signingBonusStatus TEXT,
  organizationId TEXT
);

-- Sports businesses (Sport Business portal)
CREATE TABLE IF NOT EXISTS sportsBusinesses (
  id TEXT PRIMARY KEY,
  businessName TEXT,
  revenueRecognized REAL,
  revenueSharePercent REAL,
  minimumGuarantee REAL,
  talentsAssociated TEXT,
  organizationId TEXT
);

-- Sport / partner companies (Partner portal)
CREATE TABLE IF NOT EXISTS sponsorshipCompanies (
  id TEXT PRIMARY KEY,
  companyName TEXT,
  country TEXT,
  contractValue REAL,
  royaltyRate REAL,
  minimumGuarantee REAL,
  organizationId TEXT
);

-- Contracts (Sport Business + Talent)
CREATE TABLE IF NOT EXISTS contracts (
  id TEXT PRIMARY KEY,
  contractID TEXT,
  talentId TEXT,
  talentName TEXT,
  licenseeId TEXT,
  licensee TEXT,
  sponsorId TEXT,
  productType TEXT,
  annualSalary REAL,
  basicSalary2026_27 REAL,
  basicSalary2027_28 REAL,
  royaltyPercent REAL,
  signingBonus REAL,
  minimumGuarantee REAL,
  skuMinimumGuaranteeAnnual REAL,
  startDate TEXT,
  endDate TEXT,
  status TEXT,
  contractSummary TEXT,
  contractSigningDate TEXT,
  organizationId TEXT
);

-- Revenue-share agreements used by the calculation engine (per talent / product)
CREATE TABLE IF NOT EXISTS revenueShareContracts (
  id TEXT PRIMARY KEY,
  organizationId TEXT,
  talentId TEXT,
  talentName TEXT,
  linkedContractId TEXT,
  title TEXT,
  summary TEXT,
  signingDate TEXT,
  startDate TEXT,
  endDate TEXT,
  productType TEXT,
  revenueSharePercent REAL,
  status TEXT
);

-- Vendor / partner import batches (audit + summary after processing uploads)
CREATE TABLE IF NOT EXISTS vendorImportBatches (
  id TEXT PRIMARY KEY,
  organizationId TEXT,
  fileName TEXT,
  uploadedAt TEXT,
  rowCount INTEGER,
  processedCount INTEGER,
  status TEXT,
  summaryJson TEXT,
  uploadedByUserId TEXT,
  uploadedByName TEXT,
  uploadedByEmail TEXT,
  vendorCompanyName TEXT,
  approvalStatus TEXT,
  approvedAt TEXT
);

-- Miscellaneous talent payments (appearance fees, stipends, etc.)
CREATE TABLE IF NOT EXISTS miscellaneousPayments (
  id TEXT PRIMARY KEY,
  organizationId TEXT,
  talentId TEXT,
  talentName TEXT,
  category TEXT,
  amount REAL,
  paymentStatus TEXT,
  periodMonth TEXT,
  description TEXT
);

-- Salary payments (Sport Business + Talent)
CREATE TABLE IF NOT EXISTS salaryPayments (
  id TEXT PRIMARY KEY,
  talentId TEXT,
  talentName TEXT,
  month TEXT,
  salaryAmount REAL,
  paymentStatus TEXT,
  organizationId TEXT
);

-- Signing bonuses (Sport Business + Talent)
CREATE TABLE IF NOT EXISTS signingBonuses (
  id TEXT PRIMARY KEY,
  talentId TEXT,
  talentName TEXT,
  amount REAL,
  signingDate TEXT,
  releaseDate TEXT,
  status TEXT,
  organizationId TEXT
);

-- Sales (Sport Business + Partner; royalty calc)
CREATE TABLE IF NOT EXISTS sales (
  id TEXT PRIMARY KEY,
  sku TEXT,
  licensee TEXT,
  licenseeId TEXT,
  productDescription TEXT,
  talentNames TEXT,
  talentIds TEXT,
  country TEXT,
  currency TEXT,
  typeOfSales TEXT,
  unitsSold INTEGER,
  effectiveUnitSalesPrice REAL,
  netSales REAL,
  date TEXT,
  organizationId TEXT,
  vendorImportBatchId TEXT,
  talentRoyaltyOverride REAL,
  clubShareOverride REAL,
  platformRevenueOverride REAL,
  manualTalentRoyaltyPercent REAL,
  manualClubRevenueSharePercent REAL,
  importContractRef TEXT
);

-- Invoices (royalty tracking)
CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  invoiceID TEXT,
  talentId TEXT,
  talentName TEXT,
  royaltyAmount REAL,
  netSales REAL,
  date TEXT,
  status TEXT,
  paidAmount REAL,
  organizationId TEXT
);

-- Payment ledger (all portals)
CREATE TABLE IF NOT EXISTS paymentLedger (
  id TEXT PRIMARY KEY,
  date TEXT,
  transactionId TEXT,
  talentId TEXT,
  talentName TEXT,
  paymentType TEXT,
  amount REAL,
  paymentMethod TEXT,
  status TEXT,
  details TEXT,
  organizationId TEXT
);

-- Month-wise salary / bonus / royalty aggregates per talent (derived from salaryPayments, signingBonuses, invoices)
CREATE TABLE IF NOT EXISTS talentMonthPayments (
  id TEXT PRIMARY KEY,
  organizationId TEXT,
  talentId TEXT,
  talentName TEXT,
  month TEXT,
  salaryPayable REAL,
  salaryPaid REAL,
  salaryOutstanding REAL,
  bonusPayable REAL,
  bonusPaid REAL,
  bonusOutstanding REAL,
  royaltyPayable REAL,
  royaltyPaid REAL,
  royaltyOutstanding REAL
);

-- Legacy/optional (flexible JSON blob)
CREATE TABLE IF NOT EXISTS royaltyPayments (
  id TEXT PRIMARY KEY,
  data TEXT
);
`

/** Table name -> list of columns (for INSERT/SELECT) */
export const TABLE_COLUMNS = {
  organizations: ['id', 'name', 'createdAt'],
  users: ['id', 'email', 'password', 'role', 'name', 'talentId', 'organizationId'],
  talents: ['id', 'name', 'employeeId', 'signingDate', 'signingBonus', 'releaseDate', 'signingBonusStatus', 'organizationId'],
  sportsBusinesses: ['id', 'businessName', 'revenueRecognized', 'revenueSharePercent', 'minimumGuarantee', 'talentsAssociated', 'organizationId'],
  sponsorshipCompanies: ['id', 'companyName', 'country', 'contractValue', 'royaltyRate', 'minimumGuarantee', 'organizationId'],
  contracts: [
    'id',
    'contractID',
    'talentId',
    'talentName',
    'licenseeId',
    'licensee',
    'sponsorId',
    'productType',
    'annualSalary',
    'basicSalary2026_27',
    'basicSalary2027_28',
    'royaltyPercent',
    'signingBonus',
    'minimumGuarantee',
    'skuMinimumGuaranteeAnnual',
    'startDate',
    'endDate',
    'status',
    'contractSummary',
    'contractSigningDate',
    'organizationId',
  ],
  revenueShareContracts: [
    'id',
    'organizationId',
    'talentId',
    'talentName',
    'linkedContractId',
    'title',
    'summary',
    'signingDate',
    'startDate',
    'endDate',
    'productType',
    'revenueSharePercent',
    'status',
  ],
  vendorImportBatches: [
    'id',
    'organizationId',
    'fileName',
    'uploadedAt',
    'rowCount',
    'processedCount',
    'status',
    'summaryJson',
    'uploadedByUserId',
    'uploadedByName',
    'uploadedByEmail',
    'vendorCompanyName',
    'approvalStatus',
    'approvedAt',
  ],
  miscellaneousPayments: [
    'id',
    'organizationId',
    'talentId',
    'talentName',
    'category',
    'amount',
    'paymentStatus',
    'periodMonth',
    'description',
  ],
  salaryPayments: ['id', 'talentId', 'talentName', 'month', 'salaryAmount', 'paymentStatus', 'organizationId'],
  signingBonuses: ['id', 'talentId', 'talentName', 'amount', 'signingDate', 'releaseDate', 'status', 'organizationId'],
  sales: [
    'id',
    'sku',
    'licensee',
    'licenseeId',
    'productDescription',
    'talentNames',
    'talentIds',
    'country',
    'currency',
    'typeOfSales',
    'unitsSold',
    'effectiveUnitSalesPrice',
    'netSales',
    'date',
    'organizationId',
    'vendorImportBatchId',
    'talentRoyaltyOverride',
    'clubShareOverride',
    'platformRevenueOverride',
    'manualTalentRoyaltyPercent',
    'manualClubRevenueSharePercent',
    'importContractRef',
  ],
  invoices: ['id', 'invoiceID', 'talentId', 'talentName', 'royaltyAmount', 'netSales', 'date', 'status', 'paidAmount', 'organizationId'],
  paymentLedger: ['id', 'date', 'transactionId', 'talentId', 'talentName', 'paymentType', 'amount', 'paymentMethod', 'status', 'details', 'organizationId'],
  talentMonthPayments: [
    'id',
    'organizationId',
    'talentId',
    'talentName',
    'month',
    'salaryPayable',
    'salaryPaid',
    'salaryOutstanding',
    'bonusPayable',
    'bonusPaid',
    'bonusOutstanding',
    'royaltyPayable',
    'royaltyPaid',
    'royaltyOutstanding',
  ],
  royaltyPayments: ['id', 'data'],
}
