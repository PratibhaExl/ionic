import React from 'react'
import { Card, CardContent } from '../ui/card'
import { cn } from '../../utils/cn'

export function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  className,
  valueClassName,
  onClick,
  /** Orange-accent icon chip (dark blue + orange dashboards) */
  accentIcon = false,
  /** Lift / border emphasis on hover without requiring onClick (e.g. dashboard KPI tiles). */
  hoverable = false,
}) {
  return (
    <Card
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      className={cn(
        'overflow-hidden',
        onClick &&
          cn(
            'cursor-pointer transition-all duration-200 hover:shadow-md active:scale-[0.99]',
            accentIcon ? 'hover:border-accent/35' : 'hover:border-primary/40'
          ),
        hoverable &&
          !onClick &&
          cn(
            'cursor-default transition-all duration-200 hover:shadow-lg active:scale-[0.99]',
            accentIcon ? 'hover:border-accent/40 active:border-accent/45' : 'hover:border-primary/40 active:border-primary/45'
          ),
        className
      )}
      onClick={onClick}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                onClick(e)
              }
            }
          : undefined
      }
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-xs font-medium uppercase tracking-wide text-primary-800/80">{title}</p>
            <p className={cn('mt-1.5 text-lg font-bold tabular-nums text-primary-900', valueClassName)}>{value}</p>
            {subtitle && <p className="mt-1 text-2xs text-primary-700/70">{subtitle}</p>}
            {trend && (
              <p className={cn('mt-1 text-xs font-medium', trend > 0 ? 'text-accent-600' : 'text-primary-600')}>
                {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}% vs last period
              </p>
            )}
          </div>
          {Icon && (
            <div
              className={cn(
                'shrink-0 rounded-lg border p-2.5',
                accentIcon
                  ? 'border-accent/35 bg-accent/12 text-accent-700'
                  : 'border-primary/15 bg-primary/10 text-primary'
              )}
            >
              <Icon className="h-5 w-5" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
