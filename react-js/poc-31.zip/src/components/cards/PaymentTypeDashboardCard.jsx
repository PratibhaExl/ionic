import React from 'react'
import { Card, CardContent } from '../ui/card'
import { Button } from '../ui/button'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { cn } from '../../utils/cn'
import { ArrowRight } from 'lucide-react'

/** Selectable KPI card for payment category (dashboard & talent detail). */
export function PaymentTypeDashboardCard({
  title,
  icon: Icon,
  payableRowLabel,
  paidRowLabel,
  outstandingRowLabel,
  payable,
  paid,
  outstanding,
  isSelected,
  onSelect,
  onViewMore,
  /** Extra block between KPI rows and footer (e.g. compact pie on club dashboard). */
  children,
  /** Subtitle under title; talent detail uses tap-to-focus hint. */
  subtitle = 'Tap card to show charts below',
  /** When false, card is display-only (no selection / keyboard focus). */
  interactive = true,
}) {
  return (
    <Card
      className={cn(
        'flex overflow-hidden rounded-xl border border-primary/15 bg-white shadow-md transition-all duration-200',
        interactive && 'cursor-pointer hover:border-accent/40 hover:shadow-lg hover:shadow-accent/5',
        interactive && isSelected && 'ring-2 ring-accent ring-offset-2 ring-offset-[#f3f7fb]',
        !interactive &&
          'cursor-default hover:border-accent/40 hover:shadow-lg hover:shadow-accent/5 active:border-accent/55 active:shadow-md'
      )}
      onClick={interactive ? onSelect : undefined}
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      onKeyDown={
        interactive
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                onSelect()
              }
            }
          : undefined
      }
    >
      <div
        className="w-1.5 shrink-0 bg-gradient-to-b from-accent-300 via-accent-500 to-accent-700 sm:w-2"
        aria-hidden
      />
      <CardContent
        className={cn(
          'relative flex min-h-[240px] flex-1 flex-col space-y-3 bg-gradient-to-r from-accent/[0.04] to-white p-4 pb-14 sm:min-h-[230px] sm:p-5 sm:pb-14',
          children && 'min-h-[320px] sm:min-h-[340px]'
        )}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 pr-2">
            <p className="text-2xs font-bold uppercase tracking-wide text-primary-900">{title}</p>
            {subtitle ? <p className="mt-1 text-2xs text-primary-700/75">{subtitle}</p> : null}
          </div>
          {Icon && (
            <div className="rounded-lg border border-accent/35 bg-accent/12 p-2 shadow-sm">
              <Icon className="h-4 w-4 text-accent-700" />
            </div>
          )}
        </div>
        <div className="space-y-0 divide-y divide-primary/10 rounded-md border border-primary/12 bg-white/95 px-3 py-0.5 shadow-inner">
          <div className="flex w-full flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2.5 text-xs sm:text-sm">
            <span className="min-w-0 text-primary-800/90">{payableRowLabel}:</span>
            <span className="shrink-0 text-right font-bold tabular-nums text-primary-900">{formatINRDisplay(payable)}</span>
          </div>
          <div className="flex w-full flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2.5 text-xs sm:text-sm">
            <span className="min-w-0 text-primary-800/90">{paidRowLabel}:</span>
            <span className="shrink-0 text-right font-bold tabular-nums text-primary-600">{formatINRDisplay(paid)}</span>
          </div>
          <div className="flex w-full flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2.5 text-xs sm:text-sm">
            <span className="min-w-0 text-primary-800/90">{outstandingRowLabel}:</span>
            <span className="shrink-0 text-right font-bold tabular-nums text-accent-700">{formatINRDisplay(outstanding)}</span>
          </div>
        </div>
        {children ? (
          <div className="min-h-0 flex-1 rounded-lg border border-slate-200/90 bg-slate-50/40 px-1 py-2">{children}</div>
        ) : null}
        <div className="pointer-events-none absolute bottom-3 right-3 flex justify-end">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="pointer-events-auto h-8 border-accent/40 text-2xs font-semibold text-accent-800 hover:bg-accent/12"
            onClick={(e) => {
              e.stopPropagation()
              onViewMore()
            }}
          >
            View more <ArrowRight className="ml-1 h-3.5 w-3.5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
