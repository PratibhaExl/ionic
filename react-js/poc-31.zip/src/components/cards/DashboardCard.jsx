import React from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { cn } from '../../utils/cn'

export function DashboardCard({ title, description, children, className, action }) {
  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="text-base font-medium">{title}</CardTitle>
          {description && <p className="text-sm text-neutral">{description}</p>}
        </div>
        {action}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  )
}
