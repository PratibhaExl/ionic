import React from 'react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LabelList,
} from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { chartTheme } from '../../theme/chartTheme'
import { formatINRDisplay } from '../../utils/currencyFormat'

const monthTickFormatter = (v) => {
  if (!v || typeof v !== 'string') return v
  if (v.length >= 7) return `${v.slice(5, 7)}/${v.slice(0, 4)}`
  return v
}

const monthLabelFormatter = (l) => {
  if (!l || typeof l !== 'string') return l
  if (l.length >= 7) {
    const m = l.slice(5, 7)
    const y = l.slice(0, 4)
    const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    const idx = parseInt(m, 10) - 1
    const monthName = idx >= 0 && idx < 12 ? names[idx] : m
    return `${monthName} ${y}`
  }
  return l
}

const SALARY_FILL = chartTheme.primary[500]
const BONUS_FILL = chartTheme.accent[500]
const ROYALTY_FILL = chartTheme.primary[300]

/** Y-axis ticks — same scale as bar height (single axis = honest proportions). */
const yAxisTickFormatter = (v) =>
  v >= 1_000_000 ? `$${(v / 1_000_000).toFixed(1)}M` : v >= 1000 ? `$${(v / 1000).toFixed(0)}k` : `$${v}`

/** Compact label above each bar (esp. small revenue share) so amounts stay legible. */
function barValueLabelFormatter(raw) {
  const n = Number(raw)
  if (!Number.isFinite(n) || n <= 0) return ''
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`
  if (n >= 100_000) return `$${(n / 1000).toFixed(0)}k`
  if (n >= 1000) return `$${(n / 1000).toFixed(1)}k`
  return `$${Math.round(n)}`
}

const labelListProps = {
  position: 'top',
  formatter: barValueLabelFormatter,
  style: { fontSize: 9, fontWeight: 600, fill: '#475569' },
}

/**
 * One row: grouped bars per month — salary, performance bonus, revenue share (distinct colors).
 * Single Y-axis so bar height matches dollar ratios; labels show exact payable on hover and above bars.
 * `data` items: { month: 'yyyy-MM', salary: number, bonus: number, royalty: number }
 */
export function GroupedMonthlyPaymentChart({
  data = [],
  title,
  description,
  year,
  talentLabel = '',
  chartContentClassName = 'h-[340px]',
}) {
  return (
    <ChartCard
      title={title || `Payable by month${year ? ` — ${year}` : ''}`}
      description={
        description ||
        `Month-wise payable (salary, performance bonus, revenue share) — bar height uses one scale; labels show amounts${talentLabel ? ` · ${talentLabel}` : ''}.`
      }
      className="w-full"
      contentClassName={chartContentClassName}
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 22, right: 8, left: 4, bottom: 4 }} barCategoryGap="18%">
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="month" tick={{ fontSize: 11 }} tickFormatter={monthTickFormatter} />
          <YAxis tick={{ fontSize: 11 }} tickFormatter={yAxisTickFormatter} width={44} />
          <Tooltip
            formatter={(value, name) => [formatINRDisplay(value), name]}
            labelFormatter={monthLabelFormatter}
          />
          <Legend
            wrapperStyle={{ fontSize: 12 }}
            formatter={(value) => <span className="text-slate-700">{value}</span>}
          />
          <Bar dataKey="salary" name="Salary" fill={SALARY_FILL} radius={[2, 2, 0, 0]} maxBarSize={28}>
            <LabelList {...labelListProps} />
          </Bar>
          <Bar dataKey="bonus" name="Performance bonus" fill={BONUS_FILL} radius={[2, 2, 0, 0]} maxBarSize={28}>
            <LabelList {...labelListProps} />
          </Bar>
          <Bar dataKey="royalty" name="Revenue share" fill={ROYALTY_FILL} radius={[2, 2, 0, 0]} maxBarSize={28}>
            <LabelList {...labelListProps} />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
