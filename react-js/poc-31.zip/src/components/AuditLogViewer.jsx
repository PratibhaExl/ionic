import React, { useState, useMemo } from 'react'
import { getAll } from '../database/dbService'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Input } from './ui/input'
import { Label } from './ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select'
import { format } from 'date-fns'

const ACTION_OPTIONS = ['All', 'Sales Upload', 'Settlement Calculation', 'Payment Approval', 'Payment Execution', 'Contract Modification', 'Invoice Generated', 'Reconciliation Run']

export function AuditLogViewer({ organizationId, limit = 100 }) {
  const [userFilter, setUserFilter] = useState('')
  const [actionFilter, setActionFilter] = useState('All')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  const allLogs = useMemo(() => {
    const logs = getAll('auditLogs')
    return Array.isArray(logs) ? logs : []
  }, [])

  const filtered = useMemo(() => {
    let list = allLogs
    if (organizationId) list = list.filter((l) => l.organizationId === organizationId)
    if (userFilter.trim()) list = list.filter((l) => (l.userId || '').toLowerCase().includes(userFilter.toLowerCase()))
    if (actionFilter && actionFilter !== 'All') list = list.filter((l) => l.action === actionFilter)
    if (dateFrom) list = list.filter((l) => (l.timestamp || '') >= dateFrom)
    if (dateTo) list = list.filter((l) => (l.timestamp || '').slice(0, 10) <= dateTo)
    return list.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || '')).slice(0, limit)
  }, [allLogs, organizationId, userFilter, actionFilter, dateFrom, dateTo, limit])

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
        <CardTitle className="text-base">Audit log</CardTitle>
        <div className="flex flex-wrap gap-3 items-end">
          <div className="space-y-1">
            <Label className="text-xs">User</Label>
            <Input placeholder="User ID" value={userFilter} onChange={(e) => setUserFilter(e.target.value)} className="h-8 w-40 text-sm" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Action</Label>
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger className="h-8 w-44 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ACTION_OPTIONS.map((a) => (
                  <SelectItem key={a} value={a} className="text-sm">{a}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">From date</Label>
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="h-8 w-36 text-sm" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">To date</Label>
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="h-8 w-36 text-sm" />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="px-4 py-2 text-left font-medium">Timestamp</th>
                <th className="px-4 py-2 text-left font-medium">User</th>
                <th className="px-4 py-2 text-left font-medium">Action</th>
                <th className="px-4 py-2 text-left font-medium">Entity</th>
                <th className="px-4 py-2 text-left font-medium">Entity ID</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={5} className="px-4 py-4 text-neutral">No audit entries match filters.</td></tr>
              ) : (
                filtered.map((log) => (
                  <tr key={log.id} className="border-b border-gray-100">
                    <td className="px-4 py-2">{log.timestamp ? format(new Date(log.timestamp), 'PPp') : '—'}</td>
                    <td className="px-4 py-2">{log.userId || '—'}</td>
                    <td className="px-4 py-2 font-medium">{log.action || '—'}</td>
                    <td className="px-4 py-2">{log.entityType || '—'}</td>
                    <td className="px-4 py-2">{log.entityId || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
