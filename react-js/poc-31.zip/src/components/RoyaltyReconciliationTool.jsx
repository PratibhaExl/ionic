import React, { useState } from 'react'
import * as XLSX from 'xlsx'
import { buildRoyaltyLedger } from '../utils/revenueEngine'
import { create } from '../database/dbService'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { format } from 'date-fns'
import { Upload, FileSpreadsheet, AlertCircle } from 'lucide-react'
import toast from 'react-hot-toast'

export function RoyaltyReconciliationTool({ sales = [], contracts = [], talents = [], sportsBusinesses = [], organizationId, onReportCreated }) {
  const [file, setFile] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleFile = (e) => {
    const f = e.target.files?.[0]
    if (!f) return
    setFile(f)
    setResult(null)
  }

  const runReconciliation = () => {
    if (!file) {
      toast.error('Select an Excel file first')
      return
    }
    setLoading(true)
    const reader = new FileReader()
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target.result)
        const wb = XLSX.read(data, { type: 'array' })
        const first = wb.SheetNames[0]
        const ws = wb.Sheets[first]
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1 })
        const headers = (rows[0] || []).map((h) => String(h).toLowerCase())
        const skuIdx = headers.findIndex((h) => h.includes('sku') || h === 'sku')
        const netSalesIdx = headers.findIndex((h) => h.includes('netsales') || h.includes('net sales') || h === 'netsales')
        const royaltyIdx = headers.findIndex((h) => h.includes('royalty') || h.includes('reported'))
        const talentIdx = headers.findIndex((h) => h.includes('talent') || h.includes('name'))

        const expectedLedger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
        const byKey = {}
        expectedLedger.forEach((r) => {
          const key = `${r.product || ''}-${r.talentName || ''}-${r.date || ''}`
          byKey[key] = (byKey[key] || 0) + (r.royaltyEarned || 0)
        })

        const reported = []
        for (let i = 1; i < rows.length; i++) {
          const row = rows[i]
          if (!Array.isArray(row)) continue
          const sku = skuIdx >= 0 ? String(row[skuIdx] ?? '') : ''
          const netSales = netSalesIdx >= 0 ? Number(row[netSalesIdx]) || 0 : 0
          const reportedRoyalty = royaltyIdx >= 0 ? Number(row[royaltyIdx]) || 0 : 0
          const talentName = talentIdx >= 0 ? String(row[talentIdx] ?? '') : ''
          const key = `${sku}-${talentName}-`
          const matching = Object.entries(byKey).filter(([k]) => k.startsWith(key))
          const expectedRoyalty = matching.length ? matching.reduce((a, [, v]) => a + v, 0) : 0
          const difference = reportedRoyalty - expectedRoyalty
          reported.push({ sku, talent: talentName, reportedSales: netSales, expectedRoyalty, actualRoyalty: reportedRoyalty, difference })
        }

        const totalExpected = reported.reduce((a, r) => a + r.expectedRoyalty, 0)
        const totalActual = reported.reduce((a, r) => a + r.actualRoyalty, 0)
        const totalDiff = totalActual - totalExpected
        const mismatches = reported.filter((r) => Math.abs(r.difference) > 0.01)

        const report = {
          id: `recon-${Date.now()}`,
          organizationId,
          runAt: new Date().toISOString(),
          expectedRoyalty: totalExpected,
          reportedRoyalty: totalActual,
          difference: totalDiff,
          totalDifferencesDetected: mismatches.length,
          rows: reported,
        }
        create('reconciliationReports', report)
        onReportCreated?.()
        setResult(report)
        toast.success('Reconciliation complete')
      } catch (err) {
        toast.error(err.message || 'Failed to parse Excel')
      }
      setLoading(false)
    }
    reader.readAsArrayBuffer(file)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5" />
          Excel revenue share reconciliation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-neutral">Upload an Excel file with columns: SKU, Net Sales, Reported revenue share, Talent. System will compare with calculated revenue share from contracts.</p>
        <div className="flex flex-wrap gap-3 items-center">
          <input type="file" accept=".xlsx,.xls" onChange={handleFile} className="text-sm" />
          <Button onClick={runReconciliation} disabled={!file || loading}>
            <Upload className="mr-2 h-4 w-4" />
            {loading ? 'Running...' : 'Run reconciliation'}
          </Button>
        </div>
        {result && (
          <div className="space-y-3 border-t pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div><span className="text-neutral">Expected revenue share</span><p className="font-semibold">${Number(result.expectedRoyalty).toLocaleString()}</p></div>
              <div><span className="text-neutral">Reported revenue share</span><p className="font-semibold">${Number(result.reportedRoyalty).toLocaleString()}</p></div>
              <div><span className="text-neutral">Difference</span><p className={`font-semibold ${result.difference !== 0 ? 'text-amber-600' : ''}`}>${Number(result.difference).toLocaleString()}</p></div>
              <div><span className="text-neutral">Mismatches</span><p className="font-semibold">{result.totalDifferencesDetected}</p></div>
            </div>
            <div className="overflow-x-auto max-h-60 overflow-y-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="px-2 py-1 text-left">SKU</th>
                    <th className="px-2 py-1 text-left">Talent</th>
                    <th className="px-2 py-1 text-right">Reported sales</th>
                    <th className="px-2 py-1 text-right">Expected revenue share</th>
                    <th className="px-2 py-1 text-right">Actual revenue share</th>
                    <th className="px-2 py-1 text-right">Difference</th>
                  </tr>
                </thead>
                <tbody>
                  {(result.rows || []).slice(0, 50).map((r, i) => (
                    <tr key={i} className={Math.abs(r.difference) > 0.01 ? 'bg-amber-50' : ''}>
                      <td className="px-2 py-1">{r.sku}</td>
                      <td className="px-2 py-1">{r.talent}</td>
                      <td className="px-2 py-1 text-right">${Number(r.reportedSales).toLocaleString()}</td>
                      <td className="px-2 py-1 text-right">${Number(r.expectedRoyalty).toLocaleString()}</td>
                      <td className="px-2 py-1 text-right">${Number(r.actualRoyalty).toLocaleString()}</td>
                      <td className="px-2 py-1 text-right">{r.difference !== 0 ? <span className="text-amber-700">${Number(r.difference).toLocaleString()}</span> : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
