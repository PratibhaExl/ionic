import React, { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { PaymentTimeline } from './PaymentTimeline'
import { CreditCard, Smartphone, X, CheckCircle2 } from 'lucide-react'
import { ThemedSpinner } from './ui/ThemedSpinner'
import { formatINRDisplay } from '../utils/currencyFormat'

const DUMMY_CARD = '4111 1111 1111 1111'
const DUMMY_HOLDER = 'Metropolis Meteors'
const DUMMY_EXPIRY = '12/28'
const DUMMY_CVV = '123'
const DUMMY_UPI = 'club@upi'

export function PaymentModal({ open, onOpenChange, invoice, amount: amountProp, title: titleProp, onSuccess }) {
  const [step, setStep] = useState('form') // 'form' | 'initiated' | 'processing' | 'completed'
  const [method, setMethod] = useState('card')
  const [cardNumber, setCardNumber] = useState(DUMMY_CARD)
  const [cardHolder, setCardHolder] = useState(DUMMY_HOLDER)
  const [expiry, setExpiry] = useState(DUMMY_EXPIRY)
  const [cvv, setCvv] = useState(DUMMY_CVV)
  const [upiId, setUpiId] = useState(DUMMY_UPI)

  const isInvoice = !!invoice
  const totalDue = isInvoice ? (Number(invoice?.royaltyAmount) || 0) + (Number(invoice?.minimumGuarantee) || 0) : (Number(amountProp) || 0)
  const paidAmount = isInvoice ? (Number(invoice?.paidAmount) || 0) : 0
  const remaining = Math.max(0, totalDue - paidAmount)
  const displayTitle = titleProp || (invoice ? `Invoice — ${invoice.invoiceID}` : 'Payment')

  // Autofill dummy data when modal opens (Card: 4111..., Metropolis Meteors, 12/28, 123; UPI: club@upi, metropolis@okaxis)
  useEffect(() => {
    if (open) {
      setStep('form')
      setCardNumber(DUMMY_CARD)
      setCardHolder(DUMMY_HOLDER)
      setExpiry(DUMMY_EXPIRY)
      setCvv(DUMMY_CVV)
      setUpiId(DUMMY_UPI)
    }
  }, [open])

  const handleClose = () => {
    setStep('form')
    onOpenChange(false)
  }

  const handlePay = async () => {
    if (remaining <= 0) return
    const payAmount = remaining
    setStep('initiated')
    await new Promise((r) => setTimeout(r, 400))
    setStep('processing')
    await new Promise((r) => setTimeout(r, 2000))
    const paymentMethod = method === 'card' ? 'card' : 'upi'
    onSuccess?.({
      invoice,
      amount: payAmount,
      paymentMethod,
      transactionId: `TXN-${Date.now()}`,
      cardLast4: method === 'card' && cardNumber.replace(/\s/g, '').slice(-4),
      upiId: method === 'upi' ? upiId : undefined,
    })
    setStep('completed')
  }

  if (!open) return null
  if (isInvoice && !invoice) return null
  if (!isInvoice && (amountProp == null || remaining <= 0)) return null

  const showForm = step === 'form'
  const showProgress = step === 'initiated' || step === 'processing' || step === 'completed'
  const timelineStatus = step === 'initiated' ? 'initiated' : step === 'processing' ? 'processing' : 'completed'

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-w-xl min-w-[480px] min-h-[480px] max-h-[90vh] overflow-y-auto p-6 sm:p-8 flex flex-col">
        <button
          type="button"
          onClick={handleClose}
          className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:pointer-events-none"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>
        <DialogHeader>
          <DialogTitle className="text-base pr-8">
            {showForm ? `Pay — ${displayTitle}` : step === 'completed' ? 'Payment complete' : 'Payment in progress'}
          </DialogTitle>
        </DialogHeader>

        {showForm && (
          <div className="space-y-4 text-xs text-gray-800">
            <div className="theme-card-muted rounded-lg border border-primary/12 p-3">
              <p className="text-2xs font-medium uppercase tracking-wide text-neutral">Amount due</p>
              <p className="mt-1 text-lg font-semibold tabular-nums text-primary">{formatINRDisplay(remaining)}</p>
              {paidAmount > 0 && (
                <p className="mt-1 text-2xs text-neutral">Paid: {formatINRDisplay(paidAmount)}</p>
              )}
            </div>

            <Tabs value={method} onValueChange={setMethod} className="w-full">
              <TabsList className="grid h-auto min-h-11 w-full grid-cols-2 gap-1 p-1.5">
                <TabsTrigger value="card" className="gap-1.5 py-2.5">
                  <CreditCard className="h-3.5 w-3.5 shrink-0" /> Card
                </TabsTrigger>
                <TabsTrigger value="upi" className="gap-1.5 py-2.5">
                  <Smartphone className="h-3.5 w-3.5 shrink-0" /> UPI
                </TabsTrigger>
              </TabsList>
              <p className="theme-section-summary mt-2">
                Select a method. Fields are prefilled for demo checkout.
              </p>
              <TabsContent value="card" className="space-y-3 !mt-3">
                <div>
                  <Label className="text-2xs">Card number</Label>
                  <Input
                    placeholder="4111 1111 1111 1111"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="mt-1 font-mono text-xs"
                  />
                </div>
                <div>
                  <Label className="text-2xs">Card holder</Label>
                  <Input placeholder="Name on card" value={cardHolder} onChange={(e) => setCardHolder(e.target.value)} className="mt-1 text-xs" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-2xs">Expiry (MM/YY)</Label>
                    <Input placeholder="12/28" value={expiry} onChange={(e) => setExpiry(e.target.value)} className="mt-1 text-xs" />
                  </div>
                  <div>
                    <Label className="text-2xs">CVV</Label>
                    <Input placeholder="123" type="password" value={cvv} onChange={(e) => setCvv(e.target.value)} className="mt-1 text-xs" />
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="upi" className="space-y-3 !mt-3">
                <div>
                  <Label className="text-2xs">UPI ID</Label>
                  <Input
                    placeholder="name@upi"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    className="mt-1 text-xs"
                  />
                </div>
                <div className="flex h-24 items-center justify-center rounded-lg border border-dashed border-primary/20 bg-primary/[0.04]">
                  <span className="text-2xs text-neutral">QR (demo)</span>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {showProgress && (
          <div className="space-y-6 py-4">
            {step === 'initiated' && (
              <div className="flex flex-col items-center justify-center py-6 space-y-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-accent bg-accent/10">
                  <CreditCard className="h-6 w-6 text-accent" />
                </div>
                <p className="text-sm font-semibold text-gray-900">Payment initiated</p>
                <p className="text-xs text-neutral">Preparing your payment...</p>
              </div>
            )}
            {step === 'processing' && (
              <div className="theme-card-muted flex flex-col items-center justify-center rounded-lg border border-primary/12 py-6">
                <ThemedSpinner message="Processing payment" size="lg" />
                <p className="mt-1 text-2xs text-neutral">Secure demo — please wait</p>
              </div>
            )}
            {step === 'completed' && (
              <div className="flex flex-col items-center justify-center py-6 space-y-3">
                <CheckCircle2 className="h-14 w-14 text-green-600" />
                <p className="text-sm font-semibold text-gray-900">Payment completed</p>
                <p className="text-xs text-neutral">
                  {formatINRDisplay(remaining)} has been paid. {isInvoice && invoice?.invoiceID && `Invoice ${invoice.invoiceID}.`}
                </p>
              </div>
            )}
            <div className="theme-card-muted rounded-lg border border-primary/10 p-4">
              <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">Timeline</p>
              <PaymentTimeline status={timelineStatus} />
            </div>
          </div>
        )}

        <DialogFooter>
          {showForm && (
            <>
              <Button variant="outline" onClick={handleClose}>Cancel</Button>
              <Button
                className="bg-accent text-white hover:bg-accent/90"
                onClick={handlePay}
                disabled={remaining <= 0 || (method === 'card' && !cardNumber.trim()) || (method === 'upi' && !upiId.trim())}
              >
                Pay {formatINRDisplay(remaining)}
              </Button>
            </>
          )}
          {step === 'completed' && (
            <Button className="bg-primary text-white hover:bg-primary/90" onClick={handleClose}>
              Done
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
