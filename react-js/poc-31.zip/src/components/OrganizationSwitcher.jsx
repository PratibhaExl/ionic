import React from 'react'
import { useOrganization } from '../context/OrganizationContext'
import { useAuth } from '../context/AuthContext'
import { Button } from './ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu'
import { ChevronDown, Building2 } from 'lucide-react'
import { cn } from '../utils/cn'

export function OrganizationSwitcher() {
  const { currentOrganizationId, setCurrentOrganizationId, organizations } = useOrganization()
  const { user } = useAuth()
  const currentOrg = organizations.find((o) => o.id === currentOrganizationId)
  const canSwitch = user?.role === 'platform_admin' || user?.role === 'finance_manager' || (user?.organizationId && organizations.some((o) => o.id === user.organizationId))

  if (!canSwitch || organizations.length === 0) return null

  const visibleOrgs = user?.role === 'platform_admin' || user?.role === 'finance_manager'
    ? organizations
    : organizations.filter((o) => o.id === user.organizationId)

  if (visibleOrgs.length <= 1) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 px-3 py-1.5 text-sm">
        <Building2 className="h-4 w-4 text-primary" />
        <span className="font-medium text-gray-700">{currentOrg?.name || 'Select organization'}</span>
      </div>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 min-w-[180px] justify-between">
          <Building2 className="h-4 w-4 text-primary shrink-0" />
          <span className="truncate text-sm font-medium">{currentOrg?.name || 'Select Organization'}</span>
          <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[220px]">
        {visibleOrgs.map((org) => (
          <DropdownMenuItem
            key={org.id}
            onClick={() => setCurrentOrganizationId(org.id)}
            className={cn(org.id === currentOrganizationId && 'bg-primary/10 font-medium')}
          >
            {org.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
