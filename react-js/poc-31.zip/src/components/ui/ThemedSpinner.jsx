import React from 'react'
import { cn } from '../../utils/cn'

/**
 * Circular spinner with caption — theme primary.
 */
export function ThemedSpinner({
  message = 'Loading…',
  size = 'md',
  className,
  messageClassName,
}) {
  const dim = size === 'lg' ? 'h-14 w-14' : size === 'sm' ? 'h-8 w-8' : 'h-11 w-11'

  return (
    <div className={cn('flex flex-col items-center justify-center gap-3', className)}>
      <div className={cn('relative', dim)} role="status" aria-label={message || 'Loading'}>
        <div
          className="absolute inset-0 rounded-full border-2 border-solid border-primary/20"
          aria-hidden
        />
        <div className="absolute inset-0 animate-spin rounded-full border-2 border-solid border-primary border-t-transparent" />
      </div>
      {message ? (
        <p
          className={cn(
            'max-w-[260px] text-center text-xs font-medium leading-snug text-primary-800',
            messageClassName
          )}
        >
          {message}
        </p>
      ) : null}
    </div>
  )
}
