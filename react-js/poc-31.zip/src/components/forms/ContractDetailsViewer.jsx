import React, { useState, useEffect } from 'react'
import Papa from 'papaparse'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog'
import { Button } from '../ui/button'
import { Loader } from '../ui/Loader'

const SAMPLE_CSV_URL = '/sample/contract-details.csv'

export function ContractDetailsViewer({ open, onOpenChange, contract }) {
  const [rows, setRows] = useState([])
  const [headers, setHeaders] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!open) {
      setRows([])
      setHeaders([])
      setError(null)
      return
    }
    setLoading(true)
    setError(null)
    fetch(SAMPLE_CSV_URL)
      .then((res) => {
        if (!res.ok) throw new Error('Failed to load contract details')
        return res.text()
      })
      .then((text) => {
        const parsed = Papa.parse(text, {
          header: false,
          skipEmptyLines: true,
          transformHeader: (h) => h?.trim() || '',
          transform: (v) => (typeof v === 'string' ? v.trim() : v),
        })
        const data = parsed.data || []
        if (data.length === 0) {
          setHeaders([])
          setRows([])
          return
        }
        const head = Array.isArray(data[0]) ? data[0].map((c) => String(c ?? '').trim()) : []
        const numCols = head.length
        const body = data.slice(1).map((r) => {
          const arr = Array.isArray(r) ? [...r] : []
          while (arr.length < numCols) arr.push('')
          return arr.slice(0, numCols).map((c) => (c != null ? String(c) : ''))
        })
        setHeaders(head)
        setRows(body)
      })
      .catch((err) => setError(err.message || 'Failed to load'))
      .finally(() => setLoading(false))
  }, [open])

  const highlightContractId = contract?.contractID

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl w-full max-h-[85vh] flex flex-col p-0 bg-gray-100">
        <DialogHeader className="px-6 pt-6 pb-2 shrink-0 bg-gray-100">
          <DialogTitle className="text-base font-semibold text-gray-800">
            Contract detailed info {contract ? `— ${contract.contractID || contract.talentName}` : ''}
          </DialogTitle>
        </DialogHeader>
        <div className="flex-1 min-h-0 p-4 overflow-auto">
          {loading && <Loader className="min-h-[200px]" />}
          {error && (
            <p className="text-sm text-red-600 py-4">{error}</p>
          )}
          {!loading && !error && headers.length > 0 && (
            <div
              className="mx-auto w-full max-w-4xl bg-[#fafaf9] text-gray-800 shadow-lg rounded-sm border border-gray-300"
              style={{ fontFamily: 'Georgia, "Times New Roman", serif', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
            >
              {/* PDF-style header */}
              <div className="bg-white border-b border-gray-300 px-6 py-5">
                <h2 className="text-lg font-semibold text-[#0B3C5D] tracking-tight" style={{ fontFamily: 'Georgia, serif' }}>
                  CONTRACT DETAILS — SCHEDULE
                </h2>
                <p className="text-xs text-gray-500 mt-1">Official record. All contract data from schedule.</p>
              </div>

              {/* Document body: full table with horizontal scroll so all columns visible */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-xs" style={{ fontFamily: 'Georgia, serif', minWidth: '800px' }}>
                  <thead>
                    <tr className="border-b-2 border-gray-400">
                      {headers.map((h, i) => (
                        <th key={i} className="text-left py-2.5 px-3 font-semibold text-gray-800 whitespace-nowrap bg-white/90">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, ri) => {
                      const contractId = (row[0] ?? '').toString().trim()
                      const isHighlight = highlightContractId && contractId === highlightContractId
                      return (
                        <tr
                          key={ri}
                          className={`border-b border-gray-200 ${isHighlight ? 'bg-[#0B3C5D]/10' : 'bg-white'}`}
                        >
                          {headers.map((_, ci) => (
                            <td key={ci} className="py-2 px-3 whitespace-nowrap text-gray-800">
                              {row[ci] !== undefined && row[ci] !== '' ? String(row[ci]) : '—'}
                            </td>
                          ))}
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              {/* PDF-style footer */}
              <div className="bg-white border-t border-gray-300 px-6 py-3 text-[11px] text-gray-500">
                Contract details — Confidential. For internal use only. Total {rows.length} contract(s).
              </div>
            </div>
          )}
        </div>
        <DialogFooter className="px-6 py-4 border-t border-gray-200 shrink-0 bg-gray-100">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
