import React, { useCallback } from 'react'
import { Upload } from 'lucide-react'
import { cn } from '../../utils/cn'

export function UploadZone({ onFile, accept = '.csv,.xlsx,.xls', className, disabled }) {
  const handleDrop = useCallback(
    (e) => {
      e.preventDefault()
      if (disabled) return
      const file = e.dataTransfer?.files?.[0]
      if (file) onFile(file)
    },
    [onFile, disabled]
  )
  const handleChange = useCallback(
    (e) => {
      const file = e.target?.files?.[0]
      if (file) onFile(file)
    },
    [onFile]
  )

  return (
    <label
      className={cn(
        'flex min-h-[200px] cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 p-8 transition-colors hover:border-primary hover:bg-primary/5',
        disabled && 'cursor-not-allowed opacity-50',
        className
      )}
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
    >
      <Upload className="mb-2 h-10 w-10 text-neutral" />
      <p className="mb-1 text-sm font-medium text-gray-700">Drop CSV or Excel here, or click to browse</p>
      <p className="text-xs text-neutral">Accepted: {accept}</p>
      <input
        type="file"
        accept={accept}
        onChange={handleChange}
        className="hidden"
        disabled={disabled}
      />
    </label>
  )
}
