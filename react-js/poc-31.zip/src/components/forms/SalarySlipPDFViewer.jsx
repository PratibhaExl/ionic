import React, { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog'
import { Button } from '../ui/button'
import { getSalarySlipPDFBlobURL } from '../../utils/pdfGenerator'
import { X, Download } from 'lucide-react'

export function SalarySlipPDFViewer({ open, onOpenChange, salaryRecord, businessName }) {
  const [pdfUrl, setPdfUrl] = useState(null)

  useEffect(() => {
    if (!open || !salaryRecord) return
    const url = getSalarySlipPDFBlobURL(salaryRecord, businessName)
    setPdfUrl(url)
    return () => {
      if (url) URL.revokeObjectURL(url)
    }
  }, [open, salaryRecord, businessName])

  const handleDownload = () => {
    if (!pdfUrl) return
    const a = document.createElement('a')
    a.href = pdfUrl
    a.download = `salary-slip-${(salaryRecord?.talentName || 'talent').replace(/\s/g, '-')}-${salaryRecord?.month || 'month'}.pdf`
    a.click()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col p-0">
        <DialogHeader className="flex flex-row items-center justify-between p-4 border-b">
          <DialogTitle className="text-base">Salary Slip — {salaryRecord?.talentName} ({salaryRecord?.month})</DialogTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleDownload} disabled={!pdfUrl}>
              <Download className="h-4 w-4 mr-1" /> Download PDF
            </Button>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} aria-label="Close">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        <div className="flex-1 overflow-auto min-h-[480px]">
          {pdfUrl && (
            <iframe
              src={pdfUrl}
              title="Salary slip PDF"
              className="w-full h-full min-h-[480px] border-0"
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
