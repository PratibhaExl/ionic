import React from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog'
import { Button } from '../ui/button'
import { formatDisplayDate } from '../../utils/dateFormat'

export function InvoiceModal({ open, onOpenChange, invoice, onDownloadPDF }) {
  if (!invoice) return null
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Invoice {invoice.invoiceID || invoice.id}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-2 text-sm">
          <p><span className="font-medium text-neutral">Sponsor:</span> {invoice.sponsorCompany}</p>
          <p><span className="font-medium text-neutral">Sports Business:</span> {invoice.sportsBusiness}</p>
          <p><span className="font-medium text-neutral">Talent:</span> {invoice.talentName}</p>
          <p><span className="font-medium text-neutral">Revenue share:</span> ${Number(invoice.royaltyAmount || 0).toLocaleString()}</p>
          <p><span className="font-medium text-neutral">Min. Guarantee:</span> ${Number(invoice.minimumGuarantee || 0).toLocaleString()}</p>
          <p><span className="font-medium text-neutral">Net Sales:</span> ${Number(invoice.netSales || 0).toLocaleString()}</p>
          <p><span className="font-medium text-neutral">Date:</span> {formatDisplayDate(invoice.date)}</p>
          <p><span className="font-medium text-neutral">Period:</span> {invoice.period || 'Monthly'}</p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          <Button onClick={() => { onDownloadPDF?.(invoice); onOpenChange(false); }}>Download PDF</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
