import React from 'react'
import { CheckCircle2, Circle, FileText, CreditCard, Loader2 } from 'lucide-react'
import { cn } from '../utils/cn'

const EVENTS = [
  { id: 'created', label: 'Invoice Created', icon: FileText },
  { id: 'initiated', label: 'Payment Initiated', icon: CreditCard },
  { id: 'processing', label: 'Payment Processing', icon: Loader2 },
  { id: 'completed', label: 'Payment Completed', icon: CheckCircle2 },
]

export function PaymentTimeline({ status = 'completed', className }) {
  const statusOrder = { created: 0, initiated: 1, processing: 2, completed: 3 }
  const current = statusOrder[status] ?? 3

  return (
    <div className={cn('space-y-0', className)}>
      {EVENTS.map((event, i) => {
        const step = statusOrder[event.id]
        const isDone = step <= current
        const isCurrent = step === current
        const Icon = event.icon
        const showLine = i < EVENTS.length - 1
        return (
          <div key={event.id} className="flex gap-3">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2',
                  isDone ? 'border-accent bg-accent text-white' : 'border-gray-200 bg-white text-gray-400'
                )}
              >
                {isDone && event.id !== 'processing' ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : isCurrent && event.id === 'processing' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Icon className="h-4 w-4" />
                )}
              </div>
              {showLine && <div className={cn('w-0.5 min-h-[24px] flex-1', isDone ? 'bg-accent' : 'bg-gray-200')} />}
            </div>
            <div className={cn('pb-4', !showLine && 'pb-0')}>
              <p className={cn('text-xs font-medium', isDone ? 'text-gray-900' : 'text-gray-500')}>{event.label}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}
