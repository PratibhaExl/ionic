import { create } from '../database/dbService'

export function logAudit({ userId, organizationId, action, entityType, entityId }) {
  try {
    create('auditLogs', {
      userId: userId || 'system',
      organizationId: organizationId || null,
      action,
      entityType: entityType || null,
      entityId: entityId || null,
      timestamp: new Date().toISOString(),
    })
  } catch (_) {}
}
