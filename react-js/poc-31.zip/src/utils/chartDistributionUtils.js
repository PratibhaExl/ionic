/**
 * Collapse long per-talent series into top N + an "Others" bucket (for bar charts).
 * @param {{ name: string, value: number }[]} data
 * @param {number} topN
 */
export function capDistributionForBarChart(data, topN = 10) {
  if (!Array.isArray(data) || data.length === 0) return []
  const normalized = data
    .map((d) => ({ name: String(d.name ?? '—'), value: Math.max(0, Number(d.value) || 0) }))
    .filter((d) => d.value > 0)
    .sort((a, b) => b.value - a.value)
  if (normalized.length === 0) return []
  if (normalized.length <= topN) return normalized
  const top = normalized.slice(0, topN)
  const rest = normalized.slice(topN)
  const othersSum = rest.reduce((s, d) => s + d.value, 0)
  if (othersSum <= 0) return top
  return [...top, { name: `Others (${rest.length} talents)`, value: othersSum }]
}
