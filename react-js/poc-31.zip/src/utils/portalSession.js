/**
 * Demo: map a route to the role used by AuthContext.loginAsFirstUserForRole.
 * Same rules as the landing page portal cards.
 */
export function portalRoleForTargetPath(to) {
  if (!to || typeof to !== 'string') return null
  if (to.startsWith('/sponsorship')) return 'sponsorship_admin'
  if (to.startsWith('/talent')) return 'talent'
  if (to.startsWith('/partner')) return 'vendor_partner'
  return null
}

/** Whether the current session already matches that portal (no switch needed). */
export function userMatchesPortalRole(user, portalLoginRole) {
  if (!user || !portalLoginRole) return false
  if (portalLoginRole === 'sponsorship_admin') {
    return ['sponsorship_admin', 'sponsor_manager', 'platform_admin', 'finance_manager'].includes(user.role)
  }
  if (portalLoginRole === 'talent') return user.role === 'talent'
  if (portalLoginRole === 'vendor_partner') return user.role === 'vendor_partner' || user.role === 'partner'
  return false
}
