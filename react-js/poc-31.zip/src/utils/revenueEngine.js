/**
 * Revenue calculations
 * NetSales = UnitsSold * EffectiveUnitSalesPrice
 * RoyaltyToTalent = NetSales * RoyaltyPercent
 * SportsBusinessShare = NetSales * RevenueSharePercent
 * PlatformRevenue = NetSales - RoyaltyToTalent - SportsBusinessShare
 *
 * All amounts are coerced with Number() so string values from CSV/DB do not break math.
 *
 * Optional per-sale overrides (vendor upload / manual adjustments):
 * manualTalentRoyaltyPercent, manualClubRevenueSharePercent (0–1 or 0–100),
 * talentRoyaltyOverride, clubShareOverride, platformRevenueOverride (dollar amounts).
 */

export function calcNetSales(unitsSold, effectiveUnitSalesPrice) {
  const u = Number(unitsSold) || 0
  const p = Number(effectiveUnitSalesPrice) || 0
  return u * p
}

export function calcRoyaltyToTalent(netSales, royaltyPercent) {
  const net = Number(netSales) || 0
  const pct = Number(royaltyPercent) || 0
  return net * pct
}

export function calcSportsBusinessShare(netSales, revenueSharePercent) {
  const net = Number(netSales) || 0
  const pct = Number(revenueSharePercent) || 0
  return net * pct
}

export function calcPlatformRevenue(netSales, royaltyToTalent, sportsBusinessShare) {
  const net = Number(netSales) || 0
  return net - (Number(royaltyToTalent) || 0) - (Number(sportsBusinessShare) || 0)
}

/** Accept 0.06 or 6 for 6% */
export function normalizeRateField(val) {
  if (val == null || val === '') return null
  const m = Number(val)
  if (!Number.isFinite(m)) return null
  return m > 1 ? m / 100 : m
}

/** Prefer licenseeId so multiple sports businesses with the same display name resolve correctly. */
export function resolveSportsBusinessForSale(sale, sportsBusinesses) {
  const list = sportsBusinesses || []
  if (sale?.licenseeId) {
    const byId = list.find((b) => b.id === sale.licenseeId)
    if (byId) return byId
  }
  if (sale?.licensee) {
    return list.find((b) => b.businessName === sale.licensee)
  }
  return undefined
}

/**
 * Ledger rows for one sale (one row per talent on the line).
 * @returns {{ rows: object[], perTalent: object[], clubPctUsed: number, sumFinalTalent: number, bizShare: number, platform: number }}
 */
function getLedgerRowsForOneSale(sale, contracts, talents, sportsBusinesses) {
  const netSales = Number(sale.netSales ?? calcNetSales(sale.unitsSold, sale.effectiveUnitSalesPrice)) || 0
  const talentIds = sale.talentIds || []
  const biz = resolveSportsBusinessForSale(sale, sportsBusinesses)
  const manualClubPct = normalizeRateField(sale.manualClubRevenueSharePercent)
  const clubPctUsed = manualClubPct != null ? manualClubPct : (biz?.revenueSharePercent ?? 0)
  let bizShare =
    sale.clubShareOverride != null && sale.clubShareOverride !== ''
      ? Number(sale.clubShareOverride)
      : calcSportsBusinessShare(netSales, clubPctUsed)

  const perTalent = []
  let R = 0
  for (const tid of talentIds) {
    const contract = contracts.find(
      (c) => c.talentId === tid && (c.licenseeId === sale.licenseeId || c.licensee === sale.licensee)
    )
    const manualTpct = normalizeRateField(sale.manualTalentRoyaltyPercent)
    const royaltyPercent = manualTpct != null ? manualTpct : (contract?.royaltyPercent ?? 0)
    const earned = calcRoyaltyToTalent(netSales, royaltyPercent)
    perTalent.push({ tid, contract, royaltyPercent, earned })
    R += earned
  }

  const T =
    sale.talentRoyaltyOverride != null && sale.talentRoyaltyOverride !== ''
      ? Number(sale.talentRoyaltyOverride)
      : null

  const finalEarned = perTalent.map(({ earned }) => {
    if (T != null && Number.isFinite(T)) {
      if (R > 0) return T * (earned / R)
      return T / Math.max(talentIds.length, 1)
    }
    return earned
  })
  const sumFinalTalent = finalEarned.reduce((a, b) => a + b, 0)
  const platform =
    sale.platformRevenueOverride != null && sale.platformRevenueOverride !== ''
      ? Number(sale.platformRevenueOverride)
      : calcPlatformRevenue(netSales, sumFinalTalent, bizShare)

  const rows = []
  for (let i = 0; i < talentIds.length; i++) {
    const { tid, contract, royaltyPercent } = perTalent[i]
    const talent = talents.find((t) => t.id === tid)
    rows.push({
      saleId: sale.id,
      product: sale.productDescription || sale.sku,
      licensee: sale.licensee,
      country: sale.country,
      talentId: tid,
      talentName: talent?.name ?? 'Unknown',
      unitsSold: sale.unitsSold,
      netSales,
      royaltyPercent,
      royaltyEarned: finalEarned[i],
      revenueSharePercent: clubPctUsed,
      sportsBusinessShare: bizShare,
      platformRevenue: platform,
      date: sale.date,
    })
  }
  return { rows, perTalent, clubPctUsed, sumFinalTalent, bizShare, platform }
}

export function buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses) {
  const ledger = []
  for (const sale of sales) {
    const { rows } = getLedgerRowsForOneSale(sale, contracts, talents, sportsBusinesses)
    ledger.push(...rows)
  }
  return ledger
}

/**
 * Aggregates for vendor upload preview — matches {@link buildRoyaltyLedger} for the same sale shape.
 */
export function computeSaleDistributionTotals(sale, contracts, talents, sportsBusinesses) {
  const { perTalent, clubPctUsed, sumFinalTalent, bizShare, platform } = getLedgerRowsForOneSale(
    sale,
    contracts,
    talents,
    sportsBusinesses
  )
  const ref = String(sale.importContractRef || '').trim()
  let primaryContract = ref || '—'
  if (!ref && perTalent[0]?.contract?.contractID) primaryContract = perTalent[0].contract.contractID

  let contractRevPctLabel = '—'
  const manualTpct = normalizeRateField(sale.manualTalentRoyaltyPercent)
  if (manualTpct != null) {
    contractRevPctLabel = `${(manualTpct * 100).toFixed(2)}%`
  } else if (perTalent.length === 1) {
    const c = perTalent[0]?.contract
    contractRevPctLabel = c?.royaltyPercent != null ? `${(Number(c.royaltyPercent) * 100).toFixed(1)}%` : '—'
  } else if (perTalent.length > 1) {
    contractRevPctLabel = 'Multi'
  }

  const clubRevPctLabel = clubPctUsed ? `${(Number(clubPctUsed) * 100).toFixed(1)}%` : '—'

  return {
    primaryContract,
    contractRevPctLabel,
    talentRoyaltyTotal: sumFinalTalent,
    clubRevPctLabel,
    clubShare: bizShare,
    vendorEarned: platform,
  }
}

/** Per-talent royalty totals from ledger (same source as Royalty Total stat). For charts. */
export function getRoyaltyByTalent(ledger) {
  const map = {}
  ;(ledger || []).forEach((r) => {
    const name = r.talentName || 'Unknown'
    map[name] = (map[name] || 0) + Number(r.royaltyEarned || 0)
  })
  return Object.entries(map)
    .map(([name, value]) => ({ name, value: Number(value) }))
    .sort((a, b) => b.value - a.value)
}
