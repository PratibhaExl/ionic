/**
 * Club / talent dashboards and payment snapshots only include vendor-upload sales
 * after the Sport Business approves the import batch.
 */
import { getAllByOrganization } from '../database/dbService'
import {
  calcNetSales,
  calcPlatformRevenue,
  calcRoyaltyToTalent,
  calcSportsBusinessShare,
  resolveSportsBusinessForSale,
} from './revenueEngine'

export const BATCH_APPROVAL_PENDING = 'pending_approval'
export const BATCH_APPROVAL_APPROVED = 'approved'

export function isVendorBatchApprovedForReporting(batch) {
  if (!batch) return true
  const s = batch.approvalStatus || BATCH_APPROVAL_APPROVED
  return s !== BATCH_APPROVAL_PENDING
}

export function buildVendorBatchMap(batches) {
  const m = new Map()
  for (const b of batches || []) m.set(b.id, b)
  return m
}

export function filterSalesApprovedForReporting(sales, batches) {
  const map = buildVendorBatchMap(batches)
  return (sales || []).filter((s) => {
    if (!s.vendorImportBatchId) return true
    const b = map.get(s.vendorImportBatchId)
    if (!b) return true
    return isVendorBatchApprovedForReporting(b)
  })
}

export function getReportingSalesForOrganization(organizationId) {
  if (!organizationId) return []
  const sales = getAllByOrganization('sales', organizationId) || []
  const batches = getAllByOrganization('vendorImportBatches', organizationId) || []
  return filterSalesApprovedForReporting(sales, batches)
}

/**
 * Per-batch economics: one club revenue share per sale line; talent royalties summed per talent;
 * vendor remainder = net − talent − club (matches vendor upload preview).
 */
export function summarizeSalesEconomicsForBatch(batchSales, contracts, talents, sportsBusinesses) {
  let totalNet = 0
  let talentRoyalty = 0
  let clubShare = 0
  let vendorEarned = 0

  for (const sale of batchSales || []) {
    const net = Number(sale.netSales ?? calcNetSales(sale.unitsSold, sale.effectiveUnitSalesPrice)) || 0
    totalNet += net
    const talentIds = sale.talentIds || []
    const biz = resolveSportsBusinessForSale(sale, sportsBusinesses)
    const clubPct = biz?.revenueSharePercent ?? 0
    const rowClub = calcSportsBusinessShare(net, clubPct)
    clubShare += rowClub
    let rowTalent = 0
    for (const tid of talentIds) {
      const c = contracts.find(
        (x) => x.talentId === tid && (x.licenseeId === sale.licenseeId || x.licensee === sale.licensee)
      )
      rowTalent += calcRoyaltyToTalent(net, c?.royaltyPercent ?? 0)
    }
    talentRoyalty += rowTalent
    vendorEarned += calcPlatformRevenue(net, rowTalent, rowClub)
  }

  return { totalNet, talentRoyalty, clubShare, vendorEarned }
}
