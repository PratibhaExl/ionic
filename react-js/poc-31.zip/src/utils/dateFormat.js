/**
 * Display date as DD-MM-YYYY across the app
 */
export function formatDisplayDate(value) {
  if (value == null || value === '') return '—'
  try {
    const d = typeof value === 'string' ? new Date(value) : value
    if (isNaN(d.getTime())) return String(value)
    const day = String(d.getDate()).padStart(2, '0')
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const year = d.getFullYear()
    return `${day}-${month}-${year}`
  } catch {
    return String(value)
  }
}

/** Parse DD-MM-YYYY to Date or return null */
export function parseDisplayDate(str) {
  if (!str || typeof str !== 'string') return null
  const [d, m, y] = str.split('-').map(Number)
  if (!d || !m || !y) return null
  const date = new Date(y, m - 1, d)
  return isNaN(date.getTime()) ? null : date
}
