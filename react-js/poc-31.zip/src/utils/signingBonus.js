import { addBusinessDays, format, differenceInDays, isAfter } from 'date-fns'

/**
 * Release date = Signing date + 10 working days
 */
export function getReleaseDate(signingDate) {
  if (!signingDate) return null
  const d = typeof signingDate === 'string' ? new Date(signingDate) : signingDate
  return addBusinessDays(d, 10)
}

export function getReleaseDateFormatted(signingDate) {
  const release = getReleaseDate(signingDate)
  return release ? format(release, 'yyyy-MM-dd') : 'N/A'
}

export function getDaysUntilRelease(signingDate) {
  const release = getReleaseDate(signingDate)
  if (!release) return null
  const now = new Date()
  if (isAfter(now, release)) return 0
  return differenceInDays(release, now)
}
