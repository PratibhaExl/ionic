/**
 * US Dollar number formatting (comma every 3 digits).
 * e.g. 18000000 → "18,000,000"
 */
export function formatDollar(num) {
  if (num == null || Number.isNaN(Number(num))) return '—'
  const n = Math.round(Number(num))
  return n.toLocaleString('en-US')
}

/** Display as "$18,000,000" */
export function formatDollarDisplay(num) {
  return `$${formatDollar(num)}`
}

/** @deprecated Use formatDollar for display */
export function formatINR(num) {
  return formatDollar(num)
}

/** @deprecated Use formatDollarDisplay for display */
export function formatINRDisplay(num) {
  return formatDollarDisplay(num)
}

import {
  MONTHLY_PERFORMANCE_BONUS_AMOUNT,
  ANNUAL_PERFORMANCE_BONUS_AMOUNT,
  STANDARD_ANNUAL_SALARY,
  PERFORMANCE_BONUS_PERCENT_OF_ANNUAL,
  PERFORMANCE_BONUS_PAYROLL_LABEL,
} from './salaryCalculator'

/** Default basic salary and performance bonus text for contracts */
export const DEFAULT_SALARY_2026_27 = STANDARD_ANNUAL_SALARY
export const DEFAULT_SALARY_2027_28 = STANDARD_ANNUAL_SALARY
/** Annual performance bonus pool (12 × monthly payroll line). */
export const DEFAULT_SIGNING_BONUS_INR = ANNUAL_PERFORMANCE_BONUS_AMOUNT
export const SIGNING_BONUS_DESCRIPTION = `${PERFORMANCE_BONUS_PERCENT_OF_ANNUAL * 100}% of annual salary ($${formatDollar(STANDARD_ANNUAL_SALARY)}) = $${formatDollar(ANNUAL_PERFORMANCE_BONUS_AMOUNT)} per year; $${formatDollar(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/mo on payroll (${PERFORMANCE_BONUS_PAYROLL_LABEL}).`
