/**
 * Royalty calculations (net sales × royalty %).
 * Used with revenueEngine for ledger; here for totals and pending/paid.
 */

export function calcRoyaltyFromNetSales(netSales, royaltyPercent) {
  return (Number(netSales) || 0) * (Number(royaltyPercent) || 0)
}

export function getRoyaltyTotalFromLedger(ledger) {
  return (ledger || []).reduce((sum, r) => sum + (Number(r.royaltyEarned) || 0), 0)
}

export function getRoyaltyPaidFromInvoices(invoices) {
  return (invoices || []).reduce((sum, inv) => sum + (Number(inv.paidAmount) || 0), 0)
}

export function getRoyaltyPending(ledger, invoices) {
  const total = getRoyaltyTotalFromLedger(ledger)
  const paid = getRoyaltyPaidFromInvoices(invoices)
  return Math.max(0, total - paid)
}
