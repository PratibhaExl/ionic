/**
 * Persisted month-wise salary / bonus / royalty aggregates per talent (`talentMonthPayments` table).
 * Rebuilt from salaryPayments, signingBonuses, and invoices — not from JSON files.
 */
import { getAll, getAllByOrganization, create, remove } from '../database/dbService'
import { getReportingSalesForOrganization } from '../utils/clubReportingSales'
import { buildRoyaltyLedger } from '../utils/revenueEngine'
import {
  computeTalentMonthWiseBreakdown,
  collectYearsFromPaymentSources,
} from './talentMonthPaymentSnapshotEngine'

const COLLECTION = 'talentMonthPayments'

const debouncers = new Map()

export function scheduleRebuildTalentMonthPaymentSnapshots(organizationId) {
  if (!organizationId) return
  const prev = debouncers.get(organizationId)
  if (prev) clearTimeout(prev)
  const t = setTimeout(() => {
    debouncers.delete(organizationId)
    rebuildTalentMonthPaymentSnapshotsForOrganization(organizationId)
  }, 200)
  debouncers.set(organizationId, t)
}

export function rebuildTalentMonthPaymentSnapshotsForOrganization(organizationId) {
  const existing = getAll(COLLECTION).filter((r) => r.organizationId === organizationId)
  existing.forEach((r) => remove(COLLECTION, r.id))

  const talents = getAllByOrganization('talents', organizationId)
  const salaryPayments = getAllByOrganization('salaryPayments', organizationId)
  const signingBonuses = getAllByOrganization('signingBonuses', organizationId)
  const invoices = getAllByOrganization('invoices', organizationId)
  const sales = getReportingSalesForOrganization(organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)

  const fullLedger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)

  const years = collectYearsFromPaymentSources(salaryPayments, signingBonuses, invoices, sales)

  for (const talent of talents) {
    const ledgerRows = fullLedger.filter((row) => row.talentId === talent.id)
    for (const year of years) {
      const computed = computeTalentMonthWiseBreakdown(
        talent.id,
        talent.name,
        organizationId,
        year,
        salaryPayments,
        signingBonuses,
        invoices,
        ledgerRows
      )
      for (const row of computed) {
        create(COLLECTION, row._flat)
      }
    }
  }
}

export function rebuildAllTalentMonthPaymentSnapshots() {
  const orgs = getAll('organizations')
  for (const org of orgs) {
    rebuildTalentMonthPaymentSnapshotsForOrganization(org.id)
  }
}

/** Rows for one talent + calendar year (12 months), sorted. */
export function getTalentMonthPaymentSnapshotRows(talentId, organizationId, year) {
  const y = String(year)
  return getAllByOrganization(COLLECTION, organizationId)
    .filter((r) => r.talentId === talentId && String(r.month || '').startsWith(y))
    .sort((a, b) => String(a.month).localeCompare(String(b.month)))
}

export function snapshotRowsToMonthWiseApiShape(rows) {
  return rows.map((r) => ({
    month: r.month,
    salary: {
      payable: Number(r.salaryPayable) || 0,
      paid: Number(r.salaryPaid) || 0,
      outstanding: Number(r.salaryOutstanding) || 0,
    },
    bonus: {
      payable: Number(r.bonusPayable) || 0,
      paid: Number(r.bonusPaid) || 0,
      outstanding: Number(r.bonusOutstanding) || 0,
    },
    royalty: {
      payable: Number(r.royaltyPayable) || 0,
      paid: Number(r.royaltyPaid) || 0,
      outstanding: Number(r.royaltyOutstanding) || 0,
    },
  }))
}
