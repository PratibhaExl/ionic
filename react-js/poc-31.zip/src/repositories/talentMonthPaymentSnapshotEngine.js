/**
 * Pure computation of month-wise salary / bonus / royalty buckets for one talent and year.
 * Used to populate `talentMonthPayments` snapshots (SQLite / localStorage).
 *
 * Bonus: fixed monthly performance bonus per salary row in payroll window (2025-01–2026-03),
 * same paid/pending status as that salary row (aligned with salary slips).
 * Royalty: payable uses max(ledger earned from sales, invoice royalty) per month; paid/outstanding from invoices.
 */

import {
  MONTHLY_PERFORMANCE_BONUS_AMOUNT,
  isPayrollPerformanceBonusMonth,
} from '../utils/salaryCalculator'

const emptyMonthBucket = () => ({
  salary: { payable: 0, paid: 0, outstanding: 0 },
  bonus: { payable: 0, paid: 0, outstanding: 0 },
  royalty: { payable: 0, paid: 0, outstanding: 0 },
})

/** @returns {string|null} yyyy-MM */
export function toYearMonth(dateStr) {
  if (!dateStr || typeof dateStr !== 'string' || dateStr.length < 7) return null
  return dateStr.slice(0, 7)
}

/** Booking month for royalty invoice (date | issueDate | invoiceDate). */
export function invoiceBookingMonth(inv) {
  const d = inv?.date || inv?.issueDate || inv?.invoiceDate
  if (!d) return null
  return String(d).slice(0, 7)
}

function addOneCalendarMonth(ym) {
  const [y, m] = ym.split('-').map(Number)
  const d = new Date(Date.UTC(y, m - 1 + 1, 1))
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`
}

/** Inclusive list of yyyy-MM from start through end (string compare safe for chronological months). */
export function enumerateMonthsInclusive(startYm, endYm) {
  if (!startYm) return []
  const end = endYm || startYm
  let a = startYm
  let b = end
  if (a > b) [a, b] = [b, a]
  const out = []
  let cur = a
  let guard = 0
  while (cur <= b && guard++ < 240) {
    out.push(cur)
    const next = addOneCalendarMonth(cur)
    if (next === cur) break
    cur = next
  }
  return out
}

/**
 * @param {string} talentId
 * @param {string} talentName
 * @param {string} organizationId
 * @param {string|number} year
 * @param {object[]} salaryPayments - org-filtered
 * @param {object[]} signingBonuses - org-filtered
 * @param {object[]} invoices - org-filtered
 * @param {{ date?: string, royaltyEarned?: number }[]} royaltyLedgerRows - ledger lines for this talent only (e.g. from sales)
 */
export function computeTalentMonthWiseBreakdown(
  talentId,
  talentName,
  organizationId,
  year,
  salaryPayments,
  signingBonuses,
  invoices,
  royaltyLedgerRows = []
) {
  void signingBonuses // retained for API compat; monthly perf. bonus comes from salary rows (payroll window)
  const y = String(year)
  const monthKeys = []
  for (let m = 1; m <= 12; m++) {
    monthKeys.push(`${y}-${String(m).padStart(2, '0')}`)
  }

  const byMonth = {}
  monthKeys.forEach((k) => {
    byMonth[k] = emptyMonthBucket()
  })

  const ledgerByMonth = {}
  monthKeys.forEach((k) => {
    ledgerByMonth[k] = 0
  })
  ;(royaltyLedgerRows || []).forEach((row) => {
    const key = String(row.date || '').slice(0, 7)
    if (ledgerByMonth[key] !== undefined) {
      ledgerByMonth[key] += Number(row.royaltyEarned) || 0
    }
  })

  ;(salaryPayments || [])
    .filter((s) => s.talentId === talentId)
    .forEach((s) => {
      const key = String(s.month || '').slice(0, 7)
      if (!byMonth[key]) return
      const amt = Number(s.salaryAmount) || 0
      byMonth[key].salary.payable += amt
      if (s.paymentStatus === 'paid') byMonth[key].salary.paid += amt
      if (s.paymentStatus === 'pending') byMonth[key].salary.outstanding += amt
      if (isPayrollPerformanceBonusMonth(key)) {
        const per = MONTHLY_PERFORMANCE_BONUS_AMOUNT
        byMonth[key].bonus.payable += per
        if (s.paymentStatus === 'paid') byMonth[key].bonus.paid += per
        if (s.paymentStatus === 'pending') byMonth[key].bonus.outstanding += per
      }
    })

  const invoiceAgg = {}
  monthKeys.forEach((k) => {
    invoiceAgg[k] = { payable: 0, paid: 0 }
  })
  ;(invoices || [])
    .filter((inv) => inv.talentId === talentId)
    .forEach((inv) => {
      const key = invoiceBookingMonth(inv)
      if (!key || invoiceAgg[key] === undefined) return
      const roy = Number(inv.royaltyAmount) || 0
      const pd = Number(inv.paidAmount) || 0
      invoiceAgg[key].payable += roy
      invoiceAgg[key].paid += pd
    })

  monthKeys.forEach((key) => {
    const L = ledgerByMonth[key] || 0
    const invP = invoiceAgg[key].payable
    const invPaid = invoiceAgg[key].paid
    const payable = Math.max(L, invP)
    const paid = invPaid
    const outstanding = Math.max(0, payable - paid)
    byMonth[key].royalty = { payable, paid, outstanding }
  })

  return monthKeys.map((month) => {
    const b = byMonth[month]
    return {
      month,
      salary: { ...b.salary },
      bonus: { ...b.bonus },
      royalty: { ...b.royalty },
      _flat: {
        id: `${organizationId}::${talentId}::${month}`,
        organizationId,
        talentId,
        talentName: talentName || '',
        month,
        salaryPayable: b.salary.payable,
        salaryPaid: b.salary.paid,
        salaryOutstanding: b.salary.outstanding,
        bonusPayable: b.bonus.payable,
        bonusPaid: b.bonus.paid,
        bonusOutstanding: b.bonus.outstanding,
        royaltyPayable: b.royalty.payable,
        royaltyPaid: b.royalty.paid,
        royaltyOutstanding: b.royalty.outstanding,
      },
    }
  })
}

export function collectYearsFromPaymentSources(salaryPayments, signingBonuses, invoices, sales = []) {
  const ys = new Set()
  const add = (s) => {
    if (s && typeof s === 'string' && s.length >= 4) ys.add(s.slice(0, 4))
  }
  ;(salaryPayments || []).forEach((s) => add(s.month))
  ;(signingBonuses || []).forEach((b) => {
    add(b.signingDate)
    add(b.releaseDate)
  })
  ;(invoices || []).forEach((inv) => add(inv.date || inv.issueDate || inv.invoiceDate))
  ;(sales || []).forEach((sale) => add(sale.date))
  ys.add(String(new Date().getFullYear()))
  if (ys.size === 0) ys.add('2025')
  return [...ys].sort()
}
