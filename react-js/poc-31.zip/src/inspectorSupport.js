/**
 * Keep browser / embedded WebView developer tooling usable on every target.
 * This app does not register context-menu or keyboard blocks. If a host or script
 * marks the React DevTools hook as disabled, we clear that so the inspector can attach.
 *
 * Native wrappers should also allow debugging, e.g.:
 * - iOS WKWebView: isInspectable / Safari Web Inspector
 * - Android: WebView.setWebContentsDebuggingEnabled(true)
 */
export function applyInspectorFriendlyPolicy() {
  if (typeof window === 'undefined') return
  try {
    const hook = window.__REACT_DEVTOOLS_GLOBAL_HOOK__
    if (hook && hook.isDisabled === true) {
      hook.isDisabled = false
    }
  } catch {
    /* ignore */
  }
}
