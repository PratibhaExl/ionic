import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const roleBasePaths = {
  platform_admin: '/admin',
  finance_manager: '/admin',
  sponsorship_admin: '/sponsorship',
  sponsor_manager: '/sponsorship',
  talent: '/talent',
  vendor_partner: '/partner',
  partner: '/partner',
}

export function ProtectedRoute({ children, allowedRoles }) {
  const { user, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/sponsorship/dashboard" state={{ from: location }} replace />
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    const base = roleBasePaths[user.role] || '/'
    return <Navigate to={`${base}/dashboard`} replace />
  }

  return children
}
