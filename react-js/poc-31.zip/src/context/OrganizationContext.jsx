import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { getAll } from '../database/dbService'

const ORG_STORAGE_KEY = 'sports_platform_current_org'
const OrganizationContext = createContext(null)

export function OrganizationProvider({ children }) {
  const [currentOrganizationId, setCurrentOrganizationIdState] = useState(null)
  const [organizations, setOrganizations] = useState([])

  useEffect(() => {
    const orgs = getAll('organizations')
    setOrganizations(Array.isArray(orgs) ? orgs : [])
  }, [])

  useEffect(() => {
    try {
      const saved = localStorage.getItem(ORG_STORAGE_KEY)
      if (saved) setCurrentOrganizationIdState(saved)
      else if (organizations.length > 0) setCurrentOrganizationIdState(organizations[0].id)
    } catch (_) {}
  }, [organizations.length])

  const setCurrentOrganizationId = useCallback((id) => {
    setCurrentOrganizationIdState(id)
    try {
      if (id) localStorage.setItem(ORG_STORAGE_KEY, id)
      else localStorage.removeItem(ORG_STORAGE_KEY)
    } catch (_) {}
  }, [])

  const value = {
    currentOrganizationId,
    setCurrentOrganizationId,
    organizations,
  }
  return <OrganizationContext.Provider value={value}>{children}</OrganizationContext.Provider>
}

export function useOrganization() {
  const ctx = useContext(OrganizationContext)
  if (!ctx) throw new Error('useOrganization must be used within OrganizationProvider')
  return ctx
}
