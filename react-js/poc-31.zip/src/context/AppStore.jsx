import React, { createContext, useContext, useState, useCallback } from 'react'

const AppStoreContext = createContext(null)

export function AppStoreProvider({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [globalFilters, setGlobalFilters] = useState({})
  /** Increment to force screens to re-read local DB after vendor uploads / contract edits. */
  const [dataRevision, setDataRevision] = useState(0)

  const toggleSidebar = useCallback(() => setSidebarOpen((v) => !v), [])
  const setFilter = useCallback((key, value) => {
    setGlobalFilters((f) => ({ ...f, [key]: value }))
  }, [])
  const bumpDataRevision = useCallback(() => setDataRevision((n) => n + 1), [])

  const value = {
    sidebarOpen,
    toggleSidebar,
    globalFilters,
    setGlobalFilters,
    setFilter,
    dataRevision,
    bumpDataRevision,
  }
  return <AppStoreContext.Provider value={value}>{children}</AppStoreContext.Provider>
}

export function useAppStore() {
  const ctx = useContext(AppStoreContext)
  if (!ctx) throw new Error('useAppStore must be used within AppStoreProvider')
  return ctx
}
