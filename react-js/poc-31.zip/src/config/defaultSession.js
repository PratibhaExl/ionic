/**
 * Default demo session — Sport Business (club) operator.
 * No login UI; AuthProvider applies this when no saved session exists.
 */
export const DEFAULT_PORTAL_ROLE_PRIORITY = [
  'sponsorship_admin',
  'sponsor_manager',
  'platform_admin',
  'finance_manager',
]

/** Roles that may open Talent and Vendor portals in demo (same session). */
export const CROSS_PORTAL_ROLES = [
  'sponsorship_admin',
  'sponsor_manager',
  'platform_admin',
  'finance_manager',
  'talent',
  'vendor_partner',
  'partner',
]
