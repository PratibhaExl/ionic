# Royalty Payment Engine – Enterprise SaaS Platform

A full **enterprise royalty management platform** (multi-tenant, audit, reconciliation, forecasting)—**100% client-side** with a **local JSON/localStorage "database"** (no backend). Similar to large financial SaaS (Stripe, HubSpot, Linear).

## Tech Stack

- **React 18** + **Vite**
- **React Router v6**
- **Context API** (Auth + App Store)
- **TailwindCSS** + **ShadCN-style (Radix)** + **Lucide Icons**
- **TanStack Table**, **Recharts**, **React Hook Form** + **Zod**
- **PapaParse** (CSV), **XLSX** (Excel), **jsPDF** + **html2canvas**
- **date-fns**, **uuid**

## Run the app

```bash
npm install
npm run dev
```

Open **http://localhost:5173**. Use the login page; **choosing a role auto-fills demo credentials**.

### Demo logins (autofill when you select role)

| Role             | Email                      | Password   |
|------------------|----------------------------|------------|
| Platform Admin   | admin@sponsorship.com      | admin123   |
| Finance Manager  | finance@sponsorship.com    | admin123   |
| Sponsor Manager  | sponsor@sponsorship.com    | admin123   |
| Talent User      | talent@sports.com          | talent123  |
| Vendor Partner   | partner@vendor.com         | partner123 |

## Features

### Portal 1 – Sponsorship & loyalties (admin)

- **Dashboard**: Total revenue, royalty paid, active guarantees, top talents, top sponsors; monthly revenue, royalty distribution, country sales, licensee sales.
- **Sports businesses**: CRUD (name, revenue recognized, revenue share %, minimum guarantee, talents).
- **Sponsorship companies**: CRUD (name, country, contract value, royalty rate, minimum guarantee).
- **Contracts**: Create/edit contracts (talent, licensee, sponsor, royalty %, dates, status); generate contract PDF.
- **Invoices**: List; generate monthly invoices from ledger; view and download invoice PDF; export.
- **Revenue engine**: Net sales, royalty to talent, sports business share, platform revenue; royalty ledger.
- **Export**: Royalty report CSV, contract PDFs, invoice PDFs.

### Portal 2 – Talent

- **Dashboard**: Total/monthly earnings, pending royalty, minimum guarantee, signing bonus; signing bonus countdown (release = signing + 10 working days); download signing bonus certificate PDF; monthly royalty and country revenue charts.
- **Royalties**: Table (product, licensee, units, net sales, royalty %, royalty earned) with filters (licensee, country, date range).
- **Invoices**: List and download PDFs for the logged-in talent.

### Portal 3 – Partner

- **Dashboard**: Total sales, top products/talents, country revenue; monthly revenue, country sales, royalty distribution; **revenue forecast** (next 3 months, moving average).
- **Upload sales**: CSV or Excel with columns: ID, SKU, Licensee, ProductDescription, TalentNames, Country, Currency, UnitsSold, EffectiveUnitSalesPrice, NetSales, TypeOfSales, Date. Parsed and stored locally.
- **Sales**: TanStack Table with search, sort, pagination, checkbox filters (e.g. licensee), export sales CSV.
- **Contracts**: List and generate contract PDFs.

## Enterprise features

- **Multi-tenant organizations**: Nike Sponsorship, Adidas Global Licensing, Puma Talent Marketing. Each entity has `organizationId`; data isolated per org. **Organization switcher** in top navbar (Platform Admin / Finance Manager).
- **Role-based access**: Platform Admin, Finance Manager, Sponsor Manager, Talent User, Vendor Partner.
- **Contract AI validation**: Warnings for royalty % above threshold, contract expiry soon, min guarantee vs projected sales.
- **Excel royalty reconciliation**: Upload Excel; compare reported vs calculated royalty; mismatch table (Expected / Reported / Difference).
- **Audit & compliance logs**: Key actions logged; **Audit log viewer** with filters (user, date, action type).
- **Financial compliance alerts**: Large payment detection, multiple partial payments.
- **Royalty forecasting**: Moving average + growth; forecast next 3 and 12 months; **Revenue forecast** line charts.
- **AI insights panel**: e.g. projected royalty increase, revenue drop, min guarantee risk.
- **Loader & toasts**: Loading spinners; **react-hot-toast** for success/error (login, payment, contract, etc.).

## Data & "database"

- **Persistence**: `localStorage` key `sports_platform_db`. Seed data is applied on first load if the key is missing.
- **Collections**: `organizations`, `users`, `talents`, `sponsorshipCompanies`, `sportsBusinesses`, `contracts`, `sales`, `invoices`, `payments`, `auditLogs`, `reconciliationReports`, `forecastReports`.
- **API**: `database/dbService.js` – `getAll(collection)`, `getAllByOrganization(collection, organizationId)`, `getById(collection, id)`, `create(collection, data)`, `update(collection, id, data)`, `remove(collection, id)`.

## Theme

- Primary: **#0B3C5D**
- Accent: **#F97316**
- Background: **#FFFFFF**
- Neutral: **#6B7280**

## Routes

- `/login` – Role selection + email/password (autofill for demo).
- **Admin** (Platform Admin, Finance Manager): `/admin/dashboard`, `/admin/organizations`, `/admin/contracts`, `/admin/reconciliation`, `/admin/audit-logs`, `/admin/forecast`, plus **Sponsorship portal** link to `/sponsorship/dashboard`.
- **Sponsorship**: `/sponsorship/dashboard`, `/sponsorship/businesses`, `/sponsorship/companies`, `/sponsorship/contracts`, `/sponsorship/invoices`, `/sponsorship/payments`, `/sponsorship/signing-bonus`.
- **Talent**: `/talent/dashboard`, `/talent/sales`, `/talent/royalties`, `/talent/invoices`, `/talent/signing-bonus`.
- **Partner**: `/partner/dashboard`, `/partner/upload-sales`, `/partner/sales`, `/partner/contracts`.

Sidebar and top bar adapt by role and path; organization switcher in header; routes are protected by role.
