import React from 'react';
import DynamicFormField, { FieldConfig } from './DynamicFormField';

const fieldConfigs: FieldConfig[] = [
  {
    type: 'text',
    name: 'firstName',
    label: 'First Name',
    rules: { 
      required: 'First Name is required',
      pattern: {
        value: /^[A-Za-z]+$/,
        message: 'First Name should contain only letters'
      }
    },
    defaultValue: ''
  },
  {
    type: 'select',
    name: 'country',
    label: 'Country',
    options: [
      { value: 'usa', label: 'USA' },
      { value: 'canada', label: 'Canada' },
      { value: 'uk', label: 'UK' }
    ],
    rules: {
      required: 'Country is required',
      pattern: {
        value: /^(usa|canada|uk)$/,
        message: 'Invalid country selection'
      }
    },
    defaultValue: ''
  },
  {
    type: 'radio',
    name: 'gender',
    label: 'Gender',
    options: [
      { value: 'male', label: 'Male' },
      { value: 'female', label: 'Female' }
    ],
    rules: {
      required: 'Gender is required',
      pattern: {
        value: /^(male|female)$/,
        message: 'Invalid gender selection'
      }
    },
    defaultValue: ''
  }
];

const Plan = () => (
  <form>
    {fieldConfigs.map((config, index) => (
      <DynamicFormField key={index} fieldConfig={config} />
    ))}
  </form>
);

export default Plan;
